# Sync DB

npm run db:sync

# Run Application

npm run start
