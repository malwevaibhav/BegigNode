import { request, Router } from 'express';
import InvoiceController from '../controllers/InvoiceController';
import TransactionController from '../controllers/TransactionController';
const varifyToken = require('../helper/varifyToken');
const pdfGenrator = require('../helper/pdfGenrator');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const router = Router();

// create super admin invoice for commision
router.post('/superadmin/commision/invoice',varifyToken, InvoiceController.superadminCommisionInvoice);

// create super admin invoice for commision
router.post('/create/superadmin/wallet',varifyToken, InvoiceController.createEmployerWallet);

// create super admin milestone invoice
router.post('/superadmin/milestone/invoice',varifyToken, InvoiceController.superAdminMilestoneInvoie);

// freelancer dashboard invoice count
router.get('/freelancer/dashboard/invoice/count',varifyToken, InvoiceController.dashboardGigStatusCountFL);

// Create api to get list of invoices by freelancer id (fl zoho account id), also give filter option like 
// (all, not paid, over due , paid)
router.post('/invoices/list/byfreelancerid',varifyToken, InvoiceController.invoiceListByFlId);

//Create api to give list of invoices for freelancer by passing the gig id (just give invoice for fls not the 12% commission invoice 
//which was raised for enterprises)
router.post('/invoices/list/bygigid',varifyToken, InvoiceController.invoiceListByGigId);

//Create api for list of invoice by enterprise id (it will give all the invoices 12% commission + fls invoices as well) 
router.post('/invoices/list/byenterpriseid',varifyToken, InvoiceController.invoiceListByEnterpriseId);

//siteadmin invoice view without pass id
router.post('/siteadmin/invoice/view',varifyToken, InvoiceController.siteadminInvoiceView);

// 12% invoice by company id 
router.post('/twelvepercent/invoice/list/bycompanyid',varifyToken, InvoiceController.invoiceListByCompanyid);

// 12% invoice by company id --> for site admin
router.post('/siteadmin/twelvepercent/invoice/list',varifyToken, InvoiceController.siteadminInvoiceListByCompanyid);

// invoice pdf genrator
router.get('/view/invoice/:invoice_id', varifyToken,InvoiceController.viewInvoice);

// freelnacer count by id
router.post('/freelancer/invoice/count', varifyToken,InvoiceController.flInvoiceCountById);

// enterprises count by id
router.post('/enterprises/invoice/count', varifyToken,InvoiceController.enterprisesCountApiById);

// super admin fl invoice count by id our without id 
router.post('/siteadmin/freelancer/invoice/count',InvoiceController.siteAdminflInvoiceCountFor);

// super admin enterprises count by id our without id 
router.get('/siteadmin/enterprises/invoice/count', varifyToken,InvoiceController.siteAdminEnterprisesInvoiceCount);

// 12% commission invoice count api for enterprises 
router.post('/enterprises/commission/invoice/count', varifyToken,InvoiceController.CommissionInvoiceEnterprise);

// 12% commission invoice count api for enterprises (site admin view):- 
router.post('/siteadmin/enterprises/commission/invoice/count', varifyToken,InvoiceController.siteadminCommissionInvoiceEnterprise);


// create super admin invoice for commision
router.post('/webhook/get', TransactionController.transactionCreated);

router.get('/pdf/genrator', (req:any, res:any)=>{
    const stream = res.writeHead(200, {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment;filename=invoice.pdf`,
    });
    pdfGenrator.buildPDF(
        (chunk:any) => stream.write(chunk),
        () => stream.end()
    );
});


export default router;
