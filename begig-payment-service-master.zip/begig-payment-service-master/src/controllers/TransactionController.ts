import { Request, response, Response } from 'express';
import { TransactionService } from '../services/TransactionService';
const invoiceService = new TransactionService();
class TransactionController {
     
    // list of over due invoices for freelancer
    public static transactionCreated = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.transactionCreated(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Transaction created successfully."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }
    
    
}

export default TransactionController;