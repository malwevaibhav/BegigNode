import { Request, response, Response } from 'express';
import { InvoiceService } from '../services/InvoiceService';
const invoiceService = new InvoiceService();
class InvoiceController {

    // list of over due invoices for freelancer
    public static superadminCommisionInvoice = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.superadminCommisionInvoice(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice created successfully."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    // list of over due invoices for freelancer
    public static createEmployerWallet = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.createEmployerWallet(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Employer wallet created successfully."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static superAdminMilestoneInvoie = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.superAdminMilestoneInvoie(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice created successfully."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static dashboardGigStatusCountFL = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.dashboardGigStatusCountFL(req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Freelancers dashboard invoice count.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static invoiceListByFlId = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.invoiceListByFlId(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice list by freelancer id.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static invoiceListByGigId = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.invoiceListByGigId(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice list by gig id.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static invoiceListByEnterpriseId = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.invoiceListByEnterpriseId(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice list by enterprise id.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static siteadminInvoiceView = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.siteadminInvoiceView(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Site admin invoice view.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }


    public static invoiceListByCompanyid = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.invoiceListByCompanyid(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"12 % Invoice list by Company id.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static siteadminInvoiceListByCompanyid = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.siteadminInvoiceListByCompanyid(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"12 % Invoice list",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static viewInvoice = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.viewInvoice(req.params.invoice_id);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice view.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }   

    public static flInvoiceCountById = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.flInvoiceCountById(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Invoice count by fl id.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    } 
    
    public static enterprisesCountApiById = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.enterprisesCountApiById(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Enterprise count by fl id.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }  
    
    public static siteAdminflInvoiceCountFor = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.siteAdminflInvoiceCountFor(req.body);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Fl invoice count for site admin.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }  

    public static siteAdminEnterprisesInvoiceCount = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.siteAdminEnterprisesInvoiceCount(req.body);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Enterprises invoice count for site admin.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }  

    public static CommissionInvoiceEnterprise = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.CommissionInvoiceEnterprise(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"12% commission invoice count api for enterprises.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    } 

    public static siteadminCommissionInvoiceEnterprise = async(req:any,res:Response,next:any) => {
      let result = await invoiceService.siteadminCommissionInvoiceEnterprise(req.body,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"12% commission invoice count api for enterprises site admin.",data:result.data});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    } 


    

    


}

export default InvoiceController;
