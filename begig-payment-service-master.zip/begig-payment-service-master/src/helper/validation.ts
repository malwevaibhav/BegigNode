// const {check,body} = require('express-validator');


// const employerSingnupValidation = () => {    
//     return [  
//         check('email', "Please provide a valid email address").isEmail().trim(),
//         check('password', 'Please enter at least 6 characters').isLength({ min: 6}).trim(),
//         check('first_name','More than one letter required').isLength({ min: 2}).matches(/^[A-Za-z\s]+$/).withMessage('Please enter only alphabets').custom((value: any)  => !/\s/.test(value)).withMessage('No space allowed'),
//         check('last_name', 'More than one letter required').trim().isLength({ min: 2}).matches(/^[A-Za-z\s]+$/).withMessage('Please enter only alphabets').custom((value: any)  => !/\s/.test(value)).withMessage('No space allowed'),
//         check('company_name', 'Please provide a valid company name').isLength({ min: 1})
//     ]           
// }


// module.exports = {
//     employerSingnupValidation,

// }

