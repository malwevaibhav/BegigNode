var axios = require('axios');
var FormData = require('form-data');
var {rollbar} = require('./rollbar');

async function zohoCreateAccessToekn(){

	var data = new FormData();
	data.append('client_id', process.env.ZOHO_CLIENT_ID);
	data.append('client_secret', process.env.ZOHO_CLIENT_SECRET);
	data.append('refresh_token', process.env.ZOHO_REFRESH_TOEKN);
	data.append('grant_type', process.env.ZOHO_GRANT_TYPE);

	var config = {
        method: 'post',
        url: 'https://accounts.zoho.in/oauth/v2/token',
		    timeout:50000,
        headers: {
            ...data.getHeaders()
        },
        data : data
	};
	let res = await axios(config);
	return res.data;
}

const updateGigOnZoho = (token:any,gig_id:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });
        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Gigs/'+gig_id,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in update gig on zoho", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const updateMilestoneOnZoho = (token:any,milestone_id:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });
        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Milestones/'+milestone_id,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in update milestone on zoho", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

// Create api to get list of invoices by freelancer id (fl zoho account id), also give filter option like
// ("All,Not Paid,Paid,Over Due) with pagination option.
const listOfInvoicesByFlId = (token:any,vendor_id:any,payment_status:any,page:any,per_page:any) =>
    new Promise(function (resolve, reject) {
        const page_number = page || 1;
        const number_of_record = per_page || 20;
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/search?criteria=(Freelancer:equals:'+vendor_id+')&page='+page_number+'&per_page='+number_of_record
        }else{
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/search?criteria=((Freelancer:equals:'+vendor_id+')and(Payment_Status:equals:'+payment_status+'))&page='+page_number+'&per_page='+number_of_record
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in list of invoice by fl id", vendor_id:vendor_id,error:error,payment_status:payment_status}
            rollbar.error(err);
            reject(error);
        });
});

//Create api to give list of invoices for freelancer by passing the gig id (just give invoice for fls not the 12% commission invoice
//which was raised for enterprises), also give filter option like (all, not paid, over due , paid) with pagination option.
const listOfInvoicesForFlByGigId = (token:any,gig_id:any,payment_status:any,page:any,per_page:any) =>
    new Promise(function (resolve, reject) {
        const page_number = page || 1;
        const number_of_record = per_page || 20;
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/search?criteria=(Gig_Name:equals:'+gig_id+')&page='+page_number+'&per_page='+number_of_record
        }else{
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/search?criteria=((Gig_Name:equals:'+gig_id+')and(Payment_Status:equals:'+payment_status+'))&page='+page_number+'&per_page='+number_of_record
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in list of invoice for fl by gig id", gig_id:gig_id,error:error,payment_status:payment_status}
            rollbar.error(err);
            reject(error);
        });
});

//Create api for list of invoice by enterprise id (it will give all the invoices 12% commission + fls invoices as well)
//also give filter option like (all, not paid, over due , paid) with pagination option.
const listOfInvoicesEnterpriseId = (token:any,account_id:any,payment_status:any,page:any,per_page:any) =>
    new Promise(function (resolve, reject) {
        const page_number = page || 1;
        const number_of_record = per_page || 20;
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/search?criteria=(Account_Name:equals:'+account_id+')&page='+page_number+'&per_page='+number_of_record
        }else{
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/search?criteria=((Account_Name:equals:'+account_id+')and(Payment_Status:equals:'+payment_status+'))&page='+page_number+'&per_page='+number_of_record
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in list of invoice by enterprise id", account_id:account_id,error:error,payment_status:payment_status}
            rollbar.error(err);
            reject(error);
        });
});

//Commission Invoices
const commissionInvoices = (token:any,account_id:any,payment_status:any,page:any,per_page:any) =>
    new Promise(function (resolve, reject) {
        const page_number = page || 1;
        const number_of_record = per_page || 20;
        var config = {
            method: 'get',
            url: 'https://books.zoho.in/api/v3/invoices?organization_id=60011259151&zcrm_account_id='+account_id+'&status='+payment_status+'&page='+page_number+'&per_page='+number_of_record,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in commission invoices", account_id:account_id,error:error,payment_status:payment_status}
            rollbar.error(err);
            reject(error);
        });
});

//URL for invoice without passing ids
const invoiceForAdmin = (token:any,payment_status:any,page:any,per_page:any) =>
    new Promise(function (resolve, reject) {
        const page_number = page || 1;
        const number_of_record = per_page || 20;
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices?age='+page_number+'&per_page='+number_of_record
        }else{
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices?criteria=(Payment_Status:equals:'+payment_status+')page='+page_number+'&per_page='+number_of_record
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in invoices without passing ids",error:error,payment_status:payment_status}
            rollbar.error(err);
            reject(error);
        });
});

//Total Commission Invoices without id or with id
const totalCommissionInvoices = (token:any,account_id:any,payment_status:any,page:any,per_page:any) =>
    new Promise(function (resolve, reject) {
        const page_number = page || 1;
        const number_of_record = per_page || 20;
        var urls:any = "";
        if(account_id != 0 && payment_status != "All"){
            urls =  'https://books.zoho.in/api/v3/invoices?organization_id=60011259151&zcrm_account_id='+account_id+'&status='+payment_status+'&page='+page_number+'&per_page='+number_of_record
        }else if(account_id != 0 && payment_status == "All"){
            urls =  'https://books.zoho.in/api/v3/invoices?organization_id=60011259151&zcrm_account_id='+account_id+'&page='+page_number+'&per_page='+number_of_record
        }else if(account_id == 0 && payment_status != "All"){
            urls =  'https://books.zoho.in/api/v3/invoices?organization_id=60011259151&status='+payment_status+'&page='+page_number+'&per_page='+number_of_record
        }else if(account_id == 0 && payment_status == "All"){
            urls = 'https://books.zoho.in/api/v3/invoices?organization_id=60011259151&page='+page_number+'&per_page='+number_of_record  
        }    
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in total commision invoices ",account_id:account_id,error:error,payment_status:payment_status}
            rollbar.error(err);
            reject(error);
        });
});

//PDF of the invoice of FL to enterprise by passing id of the Invoice
const pdfOfInvoice = (token:any,invoice_id:any,) =>
    new Promise(function (resolve, reject) {
        var config = {
            method: 'get',
            url: 'https://www.zohoapis.in/crm/v2.1/settings/inventory_templates/209189000000196871/actions/print_preview?record_id=209189000000791143&print_type=pdf&view_type=landscape',
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in PDF of the invoice of FL to enterprise by passing id of the Invoice",invoice_id:invoice_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

//invoice count api for freelancer 
const flInvoiceCount = (token:any,vendor_id:any,payment_status:any) =>
    new Promise(function (resolve, reject) {
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=(Freelancer:equals:'+vendor_id+')'
        }else{
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=((Freelancer:equals:'+vendor_id+')and(Payment_Status:equals:'+payment_status+'))'
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in invoice count api for freelancer",vendor_id:vendor_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

// invoice count api for enterprises
const enterprisesCountApi = (token:any,account_id:any,payment_status:any) =>
    new Promise(function (resolve, reject) {
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=(Account_Name:equals:'+account_id+')'
        }else{
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=((Account_Name:equals:'+account_id+')and(Payment_Status:equals:'+payment_status+'))'
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in invoice count api for enterprises",account_id:account_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

//invoice count api for freelancer , freelancer id (optional) (site admin view)
const flInvoiceCountForSiteAdmin = (token:any,vendor_id:any,payment_status:any) =>
    new Promise(function (resolve, reject) {  
        var urls:any = "";
        if(vendor_id != 0 && payment_status != "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=((Freelancer:equals:'+vendor_id+')and(Payment_Status:equals:'+payment_status+'))'
        }else if(vendor_id != 0 && payment_status == "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=(Freelancer:equals:'+vendor_id+')'
        }else if(vendor_id == 0 && payment_status != "All"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=(Payment_Status:equals:'+payment_status+')'     
        }    
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {            
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in invoice count api for freelancer , freelancer id (optional)",vendor_id:vendor_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

//invoice count api for enterprises (site admin view):-
const enterprisesInvoiceCountForSiteAdmin = (token:any,account_id:any,payment_status:any) =>
    new Promise(function (resolve, reject) {
        var urls:any = "";
        if(account_id != 0 && payment_status != "ALL"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=((Account_Name:equals:'+account_id+')and(Payment_Status:equals:'+payment_status+'))'
        }else if(account_id != 0 && payment_status == "ALL"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=((Account_Name:equals:'+account_id+')'
        }else if(account_id == 0 && payment_status != "ALL"){
            urls = 'https://www.zohoapis.in/crm/v2.1/Invoices/actions/count?criteria=(Payment_Status:equals:'+payment_status+')'     
        }         
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {            
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in invoice count api for enterprises (site admin view)",account_id:account_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

//12% commission invoice count api for enterprises 
const enterpriseCommissionInvoice = (token:any,account_id:any,payment_status:any) =>
    new Promise(function (resolve, reject) {
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://books.zoho.in/api/v3/invoices?response_option=2&organization_id=60011259151&&zcrm_account_id='+account_id+''
        }else{
            urls = 'https://books.zoho.in/api/v3/invoices?response_option=2&organization_id=60011259151&&status='+payment_status+'&zcrm_account_id='+account_id+''
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in 12% commission invoice count api for enterprises",account_id:account_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

//12% commission invoice count api for enterprises (site admin view):-
const siteAdminenterpriseCommissionInvoice = (token:any,account_id:any,payment_status:any) =>
    new Promise(function (resolve, reject) {
        var urls:any = "";
        if(payment_status == "All"){
            urls = 'https://books.zoho.in/api/v3/invoices?response_option=2&organization_id=60011259151&&zcrm_account_id='+account_id+')'
        }else{
            urls = 'https://books.zoho.in/api/v3/invoices?response_option=2&organization_id=60011259151&&status='+payment_status+'&zcrm_account_id='+account_id+')'
        }
        var config = {
            method: 'get',
            url: urls,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in 12% commission invoice count api for enterprises (site admin view)",account_id:account_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});


module.exports = {
    zohoCreateAccessToekn,
    updateGigOnZoho,
    updateMilestoneOnZoho,
    listOfInvoicesByFlId,
    listOfInvoicesForFlByGigId,
    listOfInvoicesEnterpriseId,
    commissionInvoices,
    invoiceForAdmin,
    totalCommissionInvoices,
    pdfOfInvoice,
    flInvoiceCount,
    enterprisesCountApi,
    flInvoiceCountForSiteAdmin,
    enterprisesInvoiceCountForSiteAdmin,
    enterpriseCommissionInvoice,
    siteAdminenterpriseCommissionInvoice
}
