import { Invoice } from "../models/Invoice";
import { getRepository } from 'typeorm';
import { UsersAccounts } from "../models/UsersAccounts";
const axios = require('axios');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
import { ZohoInfo } from "../models/ZohoInfo";
const {zohoCreateAccessToekn,listOfInvoicesByFlId,listOfInvoicesForFlByGigId,listOfInvoicesEnterpriseId,commissionInvoices,pdfOfInvoice,flInvoiceCount,enterprisesCountApi,flInvoiceCountForSiteAdmin,enterprisesInvoiceCountForSiteAdmin,totalCommissionInvoices,invoiceForAdmin,enterpriseCommissionInvoice,siteAdminenterpriseCommissionInvoice} = require('../helper/zohoApi');
require('dotenv').config();
const {rollbar} = require('../helper/rollbar');

export class InvoiceService {

    async createEmployerWallet(body:any,user:any): Promise<any>{
        try{
            const userAccRepo = getRepository(UsersAccounts);
            var balance = 0;
            var virtual_account_id = body.virtual_account_id
            var user_id = user.id;
            var userAccount = new UsersAccounts();
                userAccount.user_id = user_id;
                userAccount.virtual_account_id = virtual_account_id;
                userAccount.balance = balance;
            await userAccRepo.save(userAccount);
            return {statuscode:200};
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    // list of over due invoices for freelancer
    async superadminCommisionInvoice(body: any, user: any): Promise<any> {
        try{
            const invoiceRepository = getRepository(Invoice);
            var acc_no = body.owner_account;
            var time = Date.now()/1000;
            let invoieData = new Invoice();
                invoieData.invoice_type = 0;
                invoieData.messages = body.messages;
                invoieData.item_id = body.item_id;
                invoieData.user_id = body.user_id;
                invoieData.year = new Date().getFullYear();
                invoieData.amount = body.amount;
                invoieData.account_number = acc_no;
                invoieData.paid_at = 0;
                invoieData.created_at = time;
                invoieData.zoho_item_id = body.zoho_item_id;
                invoieData.due_on = time + (15*24*60*60)
            const savedDetails = await invoiceRepository.save(invoieData);
        return {statuscode:200};
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async superAdminMilestoneInvoie(body: any, user: any): Promise<any> {
        try{
            const invoiceRepository = getRepository(Invoice);
            var acc_no = body.owner_account;
            var time = Date.now()/1000;
            let invoieData = new Invoice();
                invoieData.invoice_type = 1;
                invoieData.messages = body.messages;
                invoieData.item_id = body.item_id;
                invoieData.user_id = body.user_id;
                invoieData.year = new Date().getFullYear();
                invoieData.amount = body.amount;
                invoieData.account_number = acc_no;
                invoieData.paid_at = 0;
                invoieData.created_at = time;
                invoieData.zoho_item_id = body.zoho_item_id;
                invoieData.due_on = time + (15*24*60*60)
            const savedDetails = await invoiceRepository.save(invoieData);
        return {statuscode:200};
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }
    
    async dashboardGigStatusCountFL(user:any): Promise<any> {
      try {
          var total_invoice = 0;
          var due_invoice = 0;
          var overdue_invoice = 0;
          var paid_invoice = 0;
          var time = Date.now()/1000;
          total_invoice = await getRepository(Invoice)
          .createQueryBuilder("invoice")
          .where("invoice.user_id = "+user.id+" AND invoice.invoice_type = 2")
          .getCount();

          due_invoice = await getRepository(Invoice)
          .createQueryBuilder("invoice")
          .where("invoice.user_id = "+user.id+" AND invoice.invoice_type = 2 AND invoice.is_paid = 0 AND invoice.due_on > "+time)
          .getCount();

          overdue_invoice = await getRepository(Invoice)
          .createQueryBuilder("invoice")
          .where("invoice.user_id = "+user.id+" AND invoice.invoice_type = 2 AND invoice.is_paid = 0 AND invoice.due_on < "+time)
          .getCount();

          paid_invoice = await getRepository(Invoice)
          .createQueryBuilder("invoice")
          .where("invoice.user_id = "+user.id+" AND invoice.invoice_type = 2 AND invoice.is_paid = 1")
          .getCount();

          return {statuscode:200,data:{total_invoice:total_invoice, due_invoice:due_invoice, overdue_invoice:overdue_invoice,paid_invoice:paid_invoice}};

      }
      catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
          return {statuscode:500};
      }
    }

    async invoiceListByFlId(body:any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let page = body.page;
            let per_page = body.per_page;
            var zohoToken :any = await zohoInfoRepo.findOne();
            var listOfInvoice = await listOfInvoicesByFlId(zohoToken.accesstoken,user.zoho_user_id,payment_status,page,per_page);          
            return {statuscode:200,data:listOfInvoice};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async invoiceListByGigId(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            const userInvoiceRepo = getRepository(Invoice);
            let payment_status = body.payment_status;
            let page = body.page;
            let per_page = body.per_page;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await listOfInvoicesForFlByGigId(zohoToken.accesstoken,body.zoho_gigs_id,payment_status,page,per_page);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async invoiceListByEnterpriseId(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let page = body.page;
            let per_page = body.per_page;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await listOfInvoicesEnterpriseId(zohoToken.accesstoken,user.zoho_enterprise_id,payment_status,page,per_page);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async siteadminInvoiceView(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let page = body.page;
            let per_page = body.per_page;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await invoiceForAdmin(zohoToken.accesstoken,payment_status,page,per_page);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    

    async viewInvoice(invoice_id:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await pdfOfInvoice(zohoToken.accesstoken,invoice_id);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async invoiceListByCompanyid(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let page = body.page;
            let per_page = body.per_page;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await commissionInvoices(zohoToken.accesstoken,user.zoho_enterprise_id,payment_status,page,per_page);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async siteadminInvoiceListByCompanyid(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let page = body.page;
            let per_page = body.per_page;
            let account_id = body.zoho_enterprise_id || 0;       
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await totalCommissionInvoices(zohoToken.accesstoken,account_id,payment_status,page,per_page);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async flInvoiceCountById(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await flInvoiceCount(zohoToken.accesstoken,user.zoho_user_id,payment_status);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async enterprisesCountApiById(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await enterprisesCountApi(zohoToken.accesstoken,user.zoho_enterprise_id,payment_status);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async siteAdminflInvoiceCountFor(body: any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let vendor_id = body.zoho_fl_id || 0;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await flInvoiceCountForSiteAdmin(zohoToken.accesstoken,vendor_id,payment_status);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async siteAdminEnterprisesInvoiceCount(body: any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let account_id = body.zoho_enterprise_id || 0;       
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await enterprisesInvoiceCountForSiteAdmin(zohoToken.accesstoken,account_id,payment_status);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async CommissionInvoiceEnterprise(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await enterpriseCommissionInvoice(zohoToken.accesstoken,user.zoho_enterprise_id,payment_status);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async siteadminCommissionInvoiceEnterprise(body: any,user:any): Promise<any> {
        try {
            const zohoInfoRepo = getRepository(ZohoInfo);
            let payment_status = body.payment_status;
            let account_id = body.zoho_enterprise_id || 0;     
            var zohoToken:any = await zohoInfoRepo.findOne();
            var listOfInvoiceByGigId = await siteAdminenterpriseCommissionInvoice(zohoToken.accesstoken,account_id,payment_status);          
            return {statuscode:200,data:listOfInvoiceByGigId};
        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    } 

    async testCron(){
        const zohoInfoRepo = getRepository(ZohoInfo);
        try{
            var zohoToken :any = await zohoInfoRepo.findOne();
            var time = Date.now()/1000;
            if(zohoToken){
                if(time > zohoToken.expire_time){
                    var createNewAcceessToken =  await zohoCreateAccessToekn();
                    await zohoInfoRepo.update({ accesstoken:zohoToken.accesstoken }, {accesstoken:createNewAcceessToken.access_token, expire_time:time+3500});
                }
            }else{
                var createNewAcceessToken =  await zohoCreateAccessToekn();
                const zohoInfo = new ZohoInfo();
                    zohoInfo.accesstoken = createNewAcceessToken.access_token;
                    zohoInfo.expire_time = time+3500;
                const savedfreelancer:any = await zohoInfoRepo.save(zohoInfo);
            }
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log(error);
        }
    }


}
