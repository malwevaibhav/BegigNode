import { Transaction } from "../models/Transaction";
import { getRepository } from 'typeorm';
import { UsersAccounts } from "../models/UsersAccounts";
import { Invoice } from "../models/Invoice";
import { ZohoInfo } from "../models/ZohoInfo";
const {updateGigOnZoho,updateMilestoneOnZoho} = require('../helper/zohoApi');
const axios = require('axios');
const {rollbar} = require('../helper/rollbar');

require('dotenv').config()

export class TransactionService {

    // list of over due invoices for freelancer
    async transactionCreated(body: any, user: any) {
        try{
          const userAccountRepo = getRepository(UsersAccounts);
          const userInvoiceRepo = getRepository(Invoice);
          const zohoInfoRepo = getRepository(ZohoInfo);
          var zohoToken :any = await zohoInfoRepo.findOne();
          let payment_data = body;
          let amount = payment_data.payload.virtual_account.amount_paid;
          let virtual_account_id = payment_data.payload.virtual_account.entity.id;
          let wallet_data:any = await userAccountRepo.findOne({where:{virtual_account_id:virtual_account_id}});
          if(wallet_data){
            var total_amount = parseFloat(amount) + parseFloat(wallet_data.balance);
            let user_id = wallet_data.user_id;
            let due_amount = 0;
            let all_pending_invoices:any = await userInvoiceRepo.find({where:{user_id:user_id,is_paid:0}});
            function updatePaymentStatus(index:number){
              let invoice_amount = all_pending_invoices[index].amount;
              let invoice_id = all_pending_invoices[index].id;
              let type = all_pending_invoices[index].invoice_type;
              let item_id = all_pending_invoices[index].item_id;
              let zoho_item_id = all_pending_invoices[index].zoho_item_id;
              total_amount = total_amount - parseFloat(invoice_amount);
              userInvoiceRepo.update({id:invoice_id},{is_paid:1,paid_at:Date.now()/1000});
              userAccountRepo.update({user_id:user_id},{balance:total_amount});
              let obj = "";
              if(type == 0){
                obj = JSON.stringify({item_id:item_id,type:"gigs_payment"});
                //Update gig status on zoho
                try{
                  var updateGigData =  {
                    Gig_Status: "inprogress",
                  }                       
                  updateGigOnZoho(zohoToken.accesstoken,zoho_item_id,updateGigData);
                }catch(error){
                  console.log(error);
                } 
              }else{
                obj = JSON.stringify({item_id:item_id,type:"milestones_payment"});
                //update milestone on zoho
                var updateData = {
                  Payment_done_by_admin: "true"
                }
                updateMilestoneOnZoho(zohoToken.accesstoken,zoho_item_id,updateData);
              }
              const bigigJobUrl = process.env.Begig_payment_url+'api/v1/jobs/update/gigs/milestone/payment/status';
              axios.post(bigigJobUrl, obj ,{
                  headers: {
                      'Content-Type': 'application/json',
                  }
              });
            }
            for(let i=0;i<all_pending_invoices.length;i++){
              due_amount = due_amount + parseFloat(all_pending_invoices[i].amount);
            }
            if(due_amount == 0){
              userAccountRepo.update({user_id:user_id},{balance:total_amount});
            }else if(due_amount == total_amount){
              userInvoiceRepo.update({user_id:user_id},{is_paid:1,paid_at:Date.now()/1000});
              userAccountRepo.update({user_id:user_id},{balance:0});
              for(let i=0;i<all_pending_invoices.length;i++){
                let obj = "";
                if(all_pending_invoices[i].invoice_type == 0){
                  obj = JSON.stringify({item_id:all_pending_invoices[i].item_id,type:"gigs_payment"})
                  //Update gig status on zoho
                  try{
                    var updateGigData =  {
                      Gig_Status: "inprogress",
                    }                       
                    updateGigOnZoho(zohoToken.accesstoken,all_pending_invoices[i].zoho_item_id,updateGigData);
                  }catch(error){
                    console.log(error);
                  } 
                }else{
                  obj = JSON.stringify({item_id:all_pending_invoices[i].item_id,type:"milestones_payment"})
                  //update milestone on zoho
                  try{
                    var updateData = {
                      Payment_done_by_admin: "true"
                    }
                    updateMilestoneOnZoho(zohoToken.accesstoken,all_pending_invoices[i].zoho_item_id,updateData);
                  }catch(error){
                    console.log(error);
                  } 
                }
                const bigigJobUrl = process.env.Begig_payment_url+'api/v1/jobs/update/gigs/milestone/payment/status';
                axios.post(bigigJobUrl, obj ,{
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
              }
            }else if(due_amount < total_amount){
              userInvoiceRepo.update({user_id:user_id},{is_paid:1,paid_at:Date.now()/1000});
              userAccountRepo.update({user_id:user_id},{balance:total_amount-due_amount});
              for(let i=0;i<all_pending_invoices.length;i++){
                let obj = "";
                if(all_pending_invoices[i].invoice_type == 0){
                  obj = JSON.stringify({item_id:all_pending_invoices[i].item_id,type:"gigs_payment"})
                   //Update gig status on zoho
                   try{
                    var updateGigData =  {
                      Gig_Status: "inprogress",
                    }                       
                    updateGigOnZoho(zohoToken.accesstoken,all_pending_invoices[i].zoho_item_id,updateGigData);
                  }catch(error){
                    console.log(error);
                  } 
                }else{
                  obj = JSON.stringify({item_id:all_pending_invoices[i].item_id,type:"milestones_payment"})
                  //update milestone on zoho
                  try{
                    var updateData = {
                      Payment_done_by_admin: "true"
                    }
                    updateMilestoneOnZoho(zohoToken.accesstoken,all_pending_invoices[i].zoho_item_id,updateData);
                  }catch(error){
                    console.log(error);
                  } 
                }
                const bigigJobUrl = process.env.Begig_payment_url+'api/v1/jobs/update/gigs/milestone/payment/status';
                axios.post(bigigJobUrl, obj ,{
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
              }
            }else{ // total_amount < due_amount
              for(let i=0;i<all_pending_invoices.length;i++){
                let invoice_amount = all_pending_invoices[i].amount;
                if(invoice_amount <= total_amount){
                  updatePaymentStatus(i);
                }
              }
            }
            const transactionRepository = getRepository(Transaction);
            var time = Date.now()/1000;
            let transactionData = new Transaction();
            transactionData.user_id = body.user_id;
            transactionData.transaction_id = body.transaction_id;
            transactionData.messages = body.messages;
            transactionData.transaction_type = body.transaction_type;
            transactionData.transaction_date = time;
            const savedDetails = await transactionRepository.save(transactionData);
            return {statuscode:200};
          }else{
            return {statuscode:201};
          }
        }catch(err){
            if(process.env.ENV != "development"){
              rollbar.error(err);
            }  
            return {statuscode:500};
        }
    }


}
