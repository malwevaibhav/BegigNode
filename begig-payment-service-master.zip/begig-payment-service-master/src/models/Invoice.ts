import {
  Column,
  Entity,
  PrimaryGeneratedColumn
} from 'typeorm';

@Entity('invoice')
export class Invoice {

  @PrimaryGeneratedColumn()
  public id!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
  public amount!: number;

  // 0 = commision paid to begig, 1 = milestone payment paid to begig
  @Column({type:"tinyint", default: 0 })
  public invoice_type!: number;

  // gigId/milestoneId
  @Column({type :"int" })
  public item_id!: number;

  @Column({type:"bigint", default:0 })
  public zoho_item_id!: number;

  @Column("varchar", { length: 255 , default: "" })
  public messages!: string;

  @Column({type :"int" })
  public user_id!: number;

  @Column({type :"int" })
  public year!: number;

  @Column("varchar", { length: 255 , default: "" })
  public account_number!: string;

  @Column({type:"bigint", default: 0 })
  public paid_at!: number;

  @Column({type:"tinyint", default: 0 })
  public is_paid!: number;

  @Column({type:"bigint", default: 0 })
  public due_on!: number;

  @Column({type:"bigint", default: 0 })
  public created_at!: number;

}
