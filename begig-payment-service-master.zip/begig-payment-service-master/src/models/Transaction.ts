import {
    Column,
    Entity,
    PrimaryGeneratedColumn
  } from 'typeorm';
  
  @Entity('transaction')
  export class Transaction {
  
    @PrimaryGeneratedColumn()     
    public id!: number;

    @Column({type :"int" })
    public user_id!: number; 

    @Column({type :"int" })
    public transaction_id!: number; 

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public amount!: number;
    
    @Column("varchar", { length: 255 , default: "" })
    public messages!: string;

    // Debit, credit
    @Column({type:"tinyint", default: 0 })
    public transaction_type!: string;

    @Column({type:"bigint", default: 0 })
    public transaction_date!: number;
  
  }