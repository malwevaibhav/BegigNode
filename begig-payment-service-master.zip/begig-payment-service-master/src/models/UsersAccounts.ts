import {
  Column,
  Entity,
  PrimaryGeneratedColumn
} from 'typeorm';

@Entity('users_accounts')
export class UsersAccounts {

  @PrimaryGeneratedColumn()
  public id!: number;

  @Column({type :"int" })
  public user_id!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
  public balance!: number;

  @Column("varchar", { length: 255 , default: "" })
  public virtual_account_id!: string;

}
