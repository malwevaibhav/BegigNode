
import { Request, Response } from 'express';
import { CompanyService } from '../services/CompanyService';
const { validationResult } = require('express-validator');
const service = new CompanyService();
class CompanyController {

    public static companyTaxDetails = async (req: any, res: Response, next: any) => {
      let usercode = await service.companyTaxDetails(req.user,req.body) 
      if( usercode.statuscode == 200){
        return res.status(200).json({ message: "Company tax details added successfully."})
      }else if(usercode.statuscode == 201 ){
        return res.status(201).json({message: "Data not updated."});
      }else{
        return res.status(500).json({message: "Something went wrong"})
      }
    }

    public static companyBankDetails = async (req: any, res: Response, next: any) => {  
      let usercode = await service.companyBankDetails(req.user,req.body) 
      if( usercode.statuscode == 200){
        return res.status(200).json({ message: "Company bank details added successfully."})
      }else if(usercode.statuscode == 201 ){
        return res.status(201).json({message: "Data not updated."});
      }else{
        return res.status(500).json({message: "Something went wrong"})
      }
    }

    public static companyUpdateAddress = async (req: any, res: Response, next: any) => {
      let usercode = await service.companyUpdateAddress(req.user,req.body); 
      if( usercode.statuscode == 200){
          return res.status(200).json({ message: "Company address updated successfully."});
      }else if(usercode.statuscode == 201 ){
          return res.status(201).json({message: "Data not updated."});
      }else{
          return res.status(500).json({message: "Something went wrong"});
      }
    }

    public static getCompanyTaxDetilas = async (req: any, res: Response, next: any) => {     
      let usercode = await service.getCompanyTaxDetilas(req.user,req.body); 
      if( usercode.statuscode == 200){
        return res.status(200).json({reelancerData: usercode.data, message: "Company tax details."});
      }else if( usercode.statuscode == 201){
        return res.status(201).json({message: "Data not found."});
      }else{
        return res.status(500).json({message: "Something went wroung."});
      }
    }

    
    public static getCompanyAddress = async (req: any, res: Response, next: any) => {     
      let usercode = await service.getCompanyAddress(req.user,req.body); 
      if( usercode.statuscode == 200){
        return res.status(200).json({reelancerData: usercode.data, message: "Company address."});
      }else if( usercode.statuscode == 201){
        return res.status(201).json({message: "Data not found."});
      }else{
        return res.status(500).json({message: "Something went wroung."});
      }
    }

    public static getCompanyBankDetails = async (req: any, res: Response, next: any) => {     
      let usercode = await service.getCompanyBankDetails(req.user,req.body); 
      if( usercode.statuscode == 200){
        return res.status(200).json({reelancerData: usercode.data, message: "Company bank details."});
      }else if( usercode.statuscode == 201){
        return res.status(201).json({message: "Data not found."});
      }else{
        return res.status(500).json({message: "Something went wroung."});
      }
    }
    
}

export default CompanyController;
