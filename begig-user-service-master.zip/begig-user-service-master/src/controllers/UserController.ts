
import { Request, Response } from 'express';
import { AuthService } from '../services/AuthService';
const {check, validationResult } = require('express-validator');

const {
  licenseValidation
} = require('../helper/validation.ts');

const service = new AuthService();
class UserController {

  public static async test(){
    await service.test();
  }

  static getAllDesignation(arg0: string, varifyToken: any, getAllDesignation: any) {
      throw new Error('Method not implemented.');
  }

  public static signupEmployer = async (req:Request,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await service.signupEmployer(req.body);
    if(result.statuscode == 200){
      return res.status(200).json({token:  result.token, message: "Signup successfully"})
    }else if(result.statuscode == 201){
      return res.status(201).json({message: "This email is already taken"})
    }else if(result.statuscode == 203){
      return res.status(203).json({message: "Please enter your verify company domain name."})
    }else{
      return res.status(500).json({message: "Something  went wrong"})
    }
  }

  public static createEmployerAdmin = async (req:any,res:Response,next:any) => {
    let result = await service.createEmployerAdmin(req.body , req.user);console.log(result);
    if(result.statuscode == 200){
      return res.status(200).json({message: "Admin account created successfully"})
    }else if(result.statuscode == 201){
      return res.status(201).json({message: "This email is already taken"})
    }else{
      return res.status(500).json({message: "Something  went wrong"})
    }
  }

  public static loginEmployer = async (req:Request,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await service.checkEmployerLogin(req.body);
    if( result.statuscode == 500){
      return res.status(500).json({message: "Something  went wrong"})
    }else if(result.statuscode == 201 ){
      return res.status(201).json({message: "Invalid email or password"})
    } else if (result.statuscode == 202) {
      return res.status(202).json({token:result.token,message: "Your email verification is pending"})
    }else if(result.statuscode == 203){
      return res.status(203).json({message: "You are temporary block"})
    } else if(result.statuscode == 206){
      return res.status(206).json({message: "Your profile is not approved."})
    } else {
      return res.status(200).json({ token: result.token, message: "Login successfully"});
    }
  }

  public static siteAdinLogin = async (req:Request,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await service.siteAdinLogin(req.body);
    if( result.statuscode == 500){
      return res.status(500).json({message: "Something went wrong"})
    }else if(result.statuscode == 201 ){
      return res.status(201).json({message: "Invalid username or password"})
    }else {
      return res.status(200).json({ token: result.token, message: "Login successfully"});
    }
  }


  public static employerOTPVerify = async (req: any, res: Response, next: any) => {
    if (!req.body.otp) {
      return res.status(400).json({message: "Otp is required"})
    }
    let usercode = await service.employerVerifyOtp(req.body , req.user)
    if( usercode.statuscode == 200){
      return res.status(200).json({token:usercode.token,message: "Otp verified successfully"})
    }else if( usercode.statuscode == 500){
      return res.status(500).json({message: "Something went wrong"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid Otp"})
    }
  }


  public static employerOTPResend = async (req: any, res: Response, next: any) => {
    let usercode = await service.employerResendOtp(req.user)
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Otp resend successfully"})
    }else if( usercode.statuscode == 500){
      return res.status(500).json({message: "Something went wrong"})
    }
  }

  public static freelancerSignup = async (req: Request, res: Response, next: any) => {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json(({errors: errors.array()}));
      }
      let usercode = await service.freelancerSignup(req.body)
      if(usercode.statuscode == 201){
        return res.status(201).json({message: "This email is already taken"})
      }else if( usercode.statuscode == 500){
        return res.status(500).json({message: "Something  went wrong"})
      }else{
        return res.status(200).json({token:  usercode.token, message: "Signup successfully"})
      }
  }

  public static freelancerLogin = async (req: Request, res: Response, next: any) => {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json(({errors: errors.array()}));
      }
    let usercode = await service.freelancerLogin(req.body)
      if( usercode.statuscode == 500){
        return res.status(500).json({message: "Something  went wrong"})
      } else if(usercode.statuscode == 201 ){
        return res.status(201).json({message: "Invalid email or password"})
      } else if (usercode.statuscode == 202) {
        return res.status(202).json({token:usercode.token,message: "Your email verification is pending"})
      } else if (usercode.statuscode == 207) {
        return res.status(207).json({token:usercode.token,message: "Your profile is incomplete"})
      } else if(usercode.statuscode == 203){
        return res.status(203).json({message: "You are temporary block"})
      } else if(usercode.statuscode == 206){
        return res.status(206).json({message: "Your profile is not approved by admin"})
      } else if(usercode.statuscode == 406){
        return res.status(406).json({message: "This email is registered with gmail account"})
      }else {
        return res.status(200).json({ token: usercode.token, message: "Login successfully"});
      }
  }

  public static socialLogin = async (req:Request,res: Response,next:any) => {
    if(req.body.social_id == ""){
      return res.status(400).json({message:"Social ID is required"});
    }else if(req.body.social_id_type == ""){
      return res.status(400).json({message:"Social ID type is required (google/fb/twitter/linkedin)"});
    }else if(req.body.email == ""){
      return res.status(400).json({message:"Email is required"});
    }else{
      let result = await service.socialLogin(req.body);
      if( result.statuscode == 500){
        return res.status(500).json({message: "Something  went wrong"})
      }else if (result.statuscode == 207) {
        return res.status(207).json({token:result.token,message: "Your profile is incomplete"})
      } else if(result.statuscode == 203){
        return res.status(203).json({message: "You are temprory block"})
      } else if(result.statuscode == 206){
        return res.status(206).json({message: "Your profile is not approved by admin."})
      }else if(result.statuscode == 201){
        return res.status(201).json({message: "This email is already taken."})
      } else if(result.statuscode == 404){
        return res.status(404).json({message: "User not found"})
      } else if(result.statuscode == 202){
        return res.status(202).json({message: "User not registered as a freelancer."})
      }else {
        return res.status(200).json({ token: result.token, message: "Login successfully"});
      }
    }
  }

  public static socialSignup = async (req:Request,res: Response,next:any) => {
    if(req.body.social_id == ""){
      return res.status(400).json({message:"Social ID is required"});
    }else if(req.body.social_id_type == ""){
      return res.status(400).json({message:"Social ID type is required (google/fb/twitter/linkedin)"});
    }else if(req.body.first_name == ""){
      return res.status(400).json({message:"First name is required"});
    }else if(req.body.last_name == ""){
      return res.status(400).json({message:"Last name is required"});
    }else if(req.body.email == ""){
      return res.status(400).json({message:"Email is required"});
    }else if(req.body.exprience == ""){
      return res.status(400).json({message:"Experience is required"});
    }else{
      let result = await service.socialSignup(req.body);
      if( result.statuscode == 500){
        return res.status(500).json({message: "Something  went wrong"})
      }else if (result.statuscode == 207) {
        return res.status(207).json({token:result.token,message: "Your profile is incomplete"})
      }
    }
  }


  public static verifyOtp = async (req: any, res: Response, next: any) => {
    if (!req.body.otp) {
      return res.status(400).json({message: "Otp is required"})
    }
    let usercode = await service.freelancerVerifyOtp(req.body,req.user)
    if( usercode.statuscode == 200){
      return res.status(200).json({token:usercode.token,message: "Otp verified successfully"})
    }else if( usercode.statuscode == 500){
      return res.status(500).json({message: "Something went wrong"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid Otp"})
    }
  }

  public static resendOtp = async (req: any, res: Response, next: any) => {
    let usercode = await service.freelancerResendOtp(req.user)
      if( usercode.statuscode == 200){
        return res.status(200).json({message: "Otp resend successfully"})
      }else if( usercode.statuscode == 500){
        return res.status(500).json({message: "Something went wrong"})
      }
  }

  public static getEducationQaulification = async (req: Request, res: Response, next: any) => {
    try {
      let freelancereducation = await service.getallEducationQualification()
      if (freelancereducation.statuscode == 200) {
        return res.status(200).json({freelancereducation:freelancereducation.data, success: true})
      } else {
        return res.status(500).json({message: "Something went wrong"})
      }
    }
      catch (error) {
        return res.status(500).json({message: "Something went wrong"})
    }
  }

  public static listOfCompanyAdmins = async (req: any, res: Response, next: any) => {
    try {
      let listOfCompanyAdmins = await service.listOfCompanyAdmins(req.body,req.user);
      if (listOfCompanyAdmins.statuscode == 200) {
        return res.status(200).json({data:listOfCompanyAdmins.data, success: true})
      }else if(listOfCompanyAdmins.statuscode == 201){
        return res.status(201).json({success: false,message:"No data found."})
      } else {
        return res.status(500).json({message: "Something went wrong"})
      }
    }
      catch (error) {
        return res.status(500).json({message: "Something went wrong"})
    }
  }

  public static addBasicDetails = async (req: any, res: Response, next: any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    try {
      let basicdetails = await service.basicDetails(req.body, req.user)
      if (basicdetails.statuscode == 200) {
        return res.status(200).json({success: true, message: 'Record updated successfully'})
      } else {
        return res.status(500).json({success: false, message: 'Something went wroung'})
      }
    }
      catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static employerUpdateAddress = async (req: any, res: Response, next: any) => {
    try {
      let basicdetails = await service.employerUpdateAddress(req.body, req.user)
      if (basicdetails.statuscode == 200) {
        return res.status(200).json({success: true, message: 'Record updated successfully.'})
      } else {
        return res.status(500).json({success: false, message: 'Something went wroung'})
      }
    }
      catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static changePassword = async (req:any,res:Response,next:any) => {
    if(req.body.new_password != req.body.confirm_new_password){
      return res.status(201).json({message:"New password and confirm password do not matched."});
    }
    let result = await service.changePassword(req.body,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Password change successfully."});
    }else if(result.statuscode == 201 ){
      return res.status(201).json({message: "Invalid username."});
    }else if(result.statuscode == 202 ){
      return res.status(202).json({message: "Current password did not matched."});
    }else if(result.statuscode == 203 ){
      return res.status(203).json({message: "Password not changed."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static changeMobileNumber = async (req:any,res:Response,next:any) => {
    let result = await service.changeMobileNumber(req.body,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Please verify otp."});
    }else if(result.statuscode == 201 ){
      return res.status(201).json({message: "Your current mobile number did not matched."});
    }else if(result.statuscode == 202 ){
      return res.status(202).json({message: "New mobile number already taken."});
    }else if(result.statuscode == 203 ){
      return res.status(203).json({message: "Mobile number not updated."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static addfreelancerexperience = async (req: any, res: Response, next: any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    try {
      let basicdetails = await service.addExprience(req.body, req.user)
      if (basicdetails.statuscode == 200) {
         return res.status(200).json({success: true, message: 'Record updated successfully'})
      } else {
         return res.status(500).json({success: false, message: 'Something went wroung'})
      }
    }
      catch (error) {
         return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static addfreelancereducation = async (req: any, res: Response, next: any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    try {
      let freelancereducation = await service.addEducation(req.body, req.user)
      if (freelancereducation.statuscode == 200) {
         return res.status(200).json({success: true, message: 'Record updated successfully'})
      } else {
         return res.status(500).json({success: false, message: 'Something went wroung'})
      }
    }
      catch (error) {
         return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static addfreelancerskills = async (req: any, res: Response, next: any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    try {
      let addskills = await service.addSkills(req.body, req.user)
      if (addskills.statuscode == 200) {
         return res.status(200).json({success: true, message: 'Record updated successfully'})
      } else {
         return res.status(500).json({success: false, message: 'Something went wroung'})
      }
    }
    catch (error) {
       return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static addfreelancerlicense = async (req: any, res: Response, next: any) => {
    try {
        let addlicense = await service.addfreelancerAccomplishments(req.body, req.user)
        if (addlicense.statuscode == 200) {
          return res.status(200).json({success: true, message: 'Record updated successfully'})
        } else {
          return res.status(500).json({success: false, message: 'Something went wroung'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getUserByid = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.userDataById(req.user,req.params.id)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ userData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'Invaid user id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getUserForFrontPageByid = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.getUserForFrontPageByid(req.user,req.params.id)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ userData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'Invaid user id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static sendEmailToAdminForNewBid = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.sendEmailToAdminForNewBid(req.body,req.user)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ userData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'Invaid user ids'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getMultiUserByid = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.multiUserDataByIds(req.body,req.user)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ userData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'Invaid user ids'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getNotificationList = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.getNotificationList(req.user)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ notificationData: usercode.notificationData, success: true})
        } else {
          return res.status(201).json({success: false, message: 'No data found.'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static readNotification = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.readNotification(req.body)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ message:"Readed successfully", success: true})
        } else {
          return res.status(500).json({success: false, message: 'Something went wroung'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static readAllNotification = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.readAllNotification(req.user)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ message:"Readed successfully", success: true})
        } else {
          return res.status(500).json({success: false, message: 'Something went wroung'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }


  public static sendNotificationsFls = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.sendNotificationsFls(req.body)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ message: 'notification send successfully', success: true})
        } else {
          return res.status(500).json({success: false, message: 'Something went wroung'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static sendNotifications = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.sendNotifications(req.body)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ message: 'notification send successfully', success: true})
        } else {
          return res.status(500).json({success: false, message: 'Something went wroung'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getMultiUserForFrontPageByid = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.getMultiUserForFrontPageByid(req.body,req.user)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ userData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'Invaid user ids'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static saveFlCountByGigsIds = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.saveFlCountByGigsIds(req.body)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ savedUserData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'No data found.'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static fileUpload = async (req: any, res: Response, next: any)  => {
    let usercode = await service.fileUpload(req.file);
    if( usercode.statuscode == 200){
      return res.status(200).json({ filePathUrl: usercode.data, message: "File upload successfully"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "File not uploaded."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static multipleFilesUpload = async (req: any, res: Response, next: any)  => {
    let usercode = await service.multipleFilesUpload(req.files);
    if( usercode.statuscode == 200){
      return res.status(200).json({ filePathUrl: usercode.data, message: "File upload successfully"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "File not uploaded."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static getEmployerAddress = async (req: any, res: Response, next: any) => {
    let usercode = await service.getEmployerAddress(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({reelancerData: usercode.data, message: "Employer address."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static forgetPasswordLink = async (req: any, res: Response, next: any) => {
    if(req.body.email == ""){
      return res.status(400).json({message:"Email id require."});
    }
    let usercode = await service.forgetPasswordLink(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Email send on your email id"});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Email id not registered."});
    }else if( usercode.statuscode == 202){
      return res.status(202).json({message: "Mail not sent."});
    }else if( usercode.statuscode == 203){
      return res.status(203).json({message: "This email is registered with gmail account, so you can not change its password. Please login with gmail."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static resetPassword = async (req: any, res: Response, next: any) => {
    if(req.body.new_password != req.body.confirm_new_password){
      return res.status(400).json({message:"New password and confirm password do not matched."});
    }
    let usercode = await service.resetPassword(req.body,req.params.token);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Password reset successfully"});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Password reset token is invalid or has expired."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static resumeParsing = async (req: any, res: Response, next: any) => {
    if(req.body.s3_link == ""){
      return res.status(400).json({message:"Url required."});
    }
    let usercode = await service.resumeParsing(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Resume parsing data."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Parsing data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static updatePersonalDetails = async (req: any, res: Response, next: any) => {
    let usercode = await service.updatePersonalDetails(req.body,req.user);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Information update successfully."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid id."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static jdParsing = async (req: any, res: Response, next: any) => {
    if(req.body.s3_link == ""){
      return res.status(400).json({message:"Url required."});
    }
    let usercode = await service.jdParsing(req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Resume parsing data."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Parsing data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static recommendedFreelancers = async (req: any, res: Response, next: any) => {
    let usercode = await service.recommendedFreelancers(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Recommended freelancers data."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Parsing data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static recommendedGigs = async (req: any, res: Response, next: any) => {
    let usercode = await service.recommendedGigs(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Recommended gigs data."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Gigs data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static searchGigs = async (req: any, res: Response, next: any) => {
    let usercode = await service.searchGigs(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Search gigs data."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Gigs data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static matchScore = async (req: any, res: Response, next: any) => {
    let usercode = await service.matchScore(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Match socre"});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Match socre not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static getAdminAccountByUserId = async (req: any, res: Response, next: any) => {
    let usercode = await service.getAdminAccountByUserId(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "success"});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "no user found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static adminSaveFlCount = async (req: any, res: Response, next: any) => {
    let usercode = await service.adminSaveFlCount(req.user);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Counts"});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }


  public static getCompanyOwnerId = async (req: any, res: Response, next: any) => {
    let usercode = await service.getCompanyOwnerId(req.params.company_id);
    if( usercode.statuscode == 200){
      return res.status(200).json({data: usercode.data,message: "Company owner data."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid id."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }


  public static insertFLs = async (req: any, res: Response, next: any) => {
    let usercode = await service.insertFLs();
    return res.status(200).json({message: "Company owner data."});
  }

  public static insertEmployers = async (req: any, res: Response, next: any) => {
    let usercode = await service.insertEmployers();
    return res.status(200).json({message: "Company owner data."});
  }

  public static createZohoAccountForCompany = async (req: any, res: Response, next: any) => {
    let usercode = await service.createZohoAccountForCompany();
    return res.status(200).json({message: "status = "+usercode.statuscode});
  }

  public static createZohoAccountForFLs = async (req: any, res: Response, next: any) => {
    let usercode = await service.createZohoAccountForFLs();
    return res.status(200).json({message: "status = "+usercode.statuscode});
  }


}

export default UserController;
