
import { Request, Response } from 'express';
import { SiteAdminService } from '../services/SiteAdminService';
const service = new SiteAdminService();

class SiteAdminController {

  public static getTotalUnapprovedClientList = async (req: any, res: Response, next: any) => {
    try {
      if(req.user.role !=2 && req.user.role !=3){
        return res.status(403).json({success: false, message: 'You dont have to permission to access'})
      }
      let client = await service.getTotalUnapprovedClientList(req.body)
      if (client.statuscode == 200) {
          return res.status(200).json({  UnapprovedClientList: client.data,  success: true})
      } else {
        return res.status(201).json({message: 'No data found.'})
      }
    }
    catch (error) {
      return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getTotalApprovedClientList = async (req: any, res: Response, next: any) => {
    try {
      if(req.user.role !=2 && req.user.role !=3){
        return res.status(403).json({success: false, message: 'You dont have to permission to access'})
      }
      let client = await service.getTotalApprovedClientList(req.body)
      if (client.statuscode == 200) {
        return res.status(200).json({  ApprovedClientList: client.data,  success: true})
      } else {
        return res.status(201).json({message: 'No data found.'})
      }
    }
    catch (error) {
      return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static approveClient = async (req: any, res: Response, next: any) => {
    try {
      if(req.user.role !=2 && req.user.role !=3){
        return res.status(403).json({success: false, message: 'You dont have to permission to access'})
      }
      let client = await service.approveClient(req.params.id);
      if (client.statuscode == 200) {
        return res.status(200).json({ id: client.data, message: "Employer Approved",  success: true})
      }else if(client.statuscode == 201){
        return res.status(201).json({message: 'Invalid id.'})
      } else {
        return res.status(201).json({success: false, message: 'Employer not approved.'})
      }
    }
    catch (error) {
      return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static rejectClient = async (req: any, res: Response, next: any) => {
    try {
      if(req.user.role !=2 && req.user.role !=3){
        return res.status(403).json({success: false, message: 'You dont have to permission to access'})
      }
      let client = await service.rejectClient(req.params.id , req.params.userid);
      if (client.statuscode == 200) {
        return res.status(200).json({  message: "Employer Rejected",  success: true})
      }else if(client.statuscode == 201){
        return res.status(201).json({message: 'Invalid id.'})
      } else {
        return res.status(201).json({success: false, message: 'Something went wroung'})
      }
    }
    catch (error) {
      return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getAllEmployer = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.getAllEmployer(req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({reelancerData: usercode.data, message: "All Employer"});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }


  public static adminInformation = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.adminInformation(req.user);
    if( usercode.statuscode == 200){
      return res.status(200).json({adminData: usercode.data, message: "Admin information."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static clientCreatedOpenGigs = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.clientCreatedOpenGigs(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Client created open gigs."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static clientCreatedOngoingGigs = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.clientCreatedOngoingGigs(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Client created ongoing gigs."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static clientCreatedDraftedGigs = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.clientCreatedDraftedGigs(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Client created drafted gigs."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static freelacerBidList = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.freelacerBidList(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Freelacer bided List."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static freelancerHiredList = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.freelancerHiredList(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Freelancer hired list."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static siteAdminClientDailyStatus = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.siteAdminClientDailyStatus(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Client daily status."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static siteAdminFreelancerDailyStatus = async (req: any, res: Response, next: any) => {
    if(req.user.role !=2 && req.user.role !=3){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.siteAdminFreelancerDailyStatus(req.body,req.headers);
    if( usercode.statuscode == 200){
      return res.status(200).json({clientData: usercode.data, message: "Freelancer daily status ."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }


  



}

export default SiteAdminController