
import { Request, Response } from 'express';
import { FreelancerService } from '../services/FreelancerService';
const { validationResult } = require('express-validator');
const service = new FreelancerService();
class FreelancerController {

  static getAllDesignation(arg0: string, varifyToken: any, getAllDesignation: any) {
      throw new Error('Method not implemented.');
  }

  public static searchFreelancer = async (req: any, res: Response, next: any) => {
    try {
        let freelancer = await service.searchFreelancer(req.body, req.user)
        if (freelancer.statuscode == 200) {
          return res.status(200).json({  freelancerData: freelancer.data,  success: true})
        } else {
          return res.status(201).json({success: false, message: 'Data not found'});
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static freelancerDetails = async (req: any, res: Response, next: any) => {
    try {
        let details = await service.getFreelancerDetailsById(req.body, req.user,req.params.id)
        if (details.statuscode == 200) {
          return res.status(200).json({ flDetails: details.data, success: true})
        }else {
          return res.status(201).json({success: false, message: 'Invaid freelancer id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static freelancerSkills = async (req: any, res: Response, next: any) => {
    try {
        let skillsData = await service.gerfreelancerskills(req.body,req.user,req.params.id)
        if (skillsData.statuscode == 200) {
          return res.status(200).json({ skills: skillsData.data, success: true})
        }else {
          return res.status(201).json({success: false, message: 'Invaid freelancer id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static freelancerEducation = async (req: any, res: Response, next: any) => {
    try {
        let educationData = await service.getFreelancerEducation(req.body,req.user,req.params.id)
        if (educationData.statuscode == 200) {
          return res.status(200).json({ education: educationData.data, success: true})
        }else {
          return res.status(201).json({success: false, message: 'Invaid freelancer id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static freelancerExperience = async (req: any, res: Response, next: any) => {

    try {
        let experience = await service.getFreelancerExperience(req.body,req.user,req.params.id)
        if (experience.statuscode == 200) {
          return res.status(200).json({ experience: experience.data, success: true})
        }else {
          return res.status(201).json({success: false, message: 'Invaid freelancer id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static freelancerAccomplishments = async (req: any, res: Response, next: any) => {
    try {
        let accomplishments = await service.getFreelancerAccomplishments(req.body,req.user,req.params.id)
        if (accomplishments.statuscode == 200) {
          return res.status(200).json({ accomplishments: accomplishments.data, success: true})
        }else {
          return res.status(201).json({success: false, message: 'Invaid freelancer id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static saveFreelancer = async (req: any, res: Response, next: any) => {
    if (!req.body.freelancerId) {
      return res.status(400).json({message: "Freelancer id is required"})
    }
    if (typeof(req.body.freelancerId) !== 'number') {
      return res.status(400).json({message: "Freelancer id must be number"})
    }
    try {
        let saveFl = await service.saveFreelancerdata(req.body,req.user)
        if (saveFl.statuscode == 200) {
          return res.status(200).json({ success: true, message: 'Freelancer data saved'})
        }else {
          return res.status(201).json({success: false, message: 'Already saved.'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static savedFreelancersList = async(req:any,res:Response,next:any) => {
    let saveFl = await service.savedFreelancersList(req.user,req.params.gig_id)
    if (saveFl.statuscode == 200) {
      return res.status(200).json({ success: true, message: 'Saved Freelancers found.', data:saveFl.data});
    }else if(saveFl.statuscode == 201) {
      return res.status(201).json({success: false, message: 'No data found.'})
    }else{
      return res.status(500).json({success: false, message: 'Something went wroung.'})
    }
  }

  public static deleteSavedFreelancers = async(req:any,res:Response,next:any) => {
    let saveFl = await service.deleteSavedFreelancers(req.params)
    if (saveFl.statuscode == 200) {
      return res.status(200).json({ success: true, message: 'Delete saved Freelancers'});
    }else if(saveFl.statuscode == 201) {
      return res.status(201).json({success: false, message: 'Invalid id.'})
    }else{
      return res.status(500).json({success: false, message: 'Something went wroung.'})
    }
  }

  public static hiredFreelancersList = async(req:any,res:Response,next:any) => {
    let saveFl = await service.hiredFreelancersList(req.body,req.user,req.headers)
    if (saveFl.statuscode == 200) {
      return res.status(200).json({ success: true, message: 'Hired Freelancers found.', data:saveFl.data});
    }else if(saveFl.statuscode == 201) {
      return res.status(201).json({success: false, message: 'No data found.'})
    }else{
      return res.status(500).json({success: false, message: 'Something went wroung.'})
    }
  }

  public static clientFeedback = async (req: any, res: Response, next: any) => {
    try {
        let clientFeedback = await service.getClientFeedback(req.body,req.user,req.params.id)
        if (clientFeedback.statuscode == 200) {
          return res.status(200).json({ feedback: clientFeedback.data, success: true})
        }else {
          return res.status(201).json({success: false, message: 'Invaid freelancer id'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static getMultiFreelancerByid = async (req: any, res: Response, next: any) => {
    try {
      let usercode = await service.multiFreelanceDataByIds(req.body,req.user)
        if (usercode.statuscode == 200) {
          return res.status(200).json({ freelancerData: usercode.data, success: true})
        } else {
          return res.status(201).json({success: false, message: 'Invaid user ids'})
        }
    }
    catch (error) {
        return res.status(500).json({success: false, message: 'Something went wroung'})
    }
  }

  public static bankAndBilingAddUpdate = async (req: any, res: Response, next: any) => {
    let usercode = await service.bankAndBilingAddUpdate(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Details updated successfully."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not updated."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static flTaxInformation = async (req: any, res: Response, next: any) => {
    let usercode = await service.flTaxInformation(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Tax information updated successfully."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not updated."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static getFlbankAndBiling = async (req: any, res: Response, next: any) => {
    let usercode = await service.getFlbankAndBiling(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({reelancerData: usercode.data, message: "Freelancer bank and billing information."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static getflTaxInformation = async (req: any, res: Response, next: any) => {
    let usercode = await service.getflTaxInformation(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({reelancerData: usercode.data, message: "Freelancer tax information."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static updateGigCompletedCountForFl = async (req: any, res: Response, next: any) => {
    let usercode = await service.updateGigCompletedCountForFl(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Modified successfully."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid id."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static getFreelancerAllDetailsById = async (req: any, res: Response, next: any) => {
    let usercode = await service.getFreelancerAllDetailsById(req.params.fl_id);
    if( usercode.statuscode == 200){
      return res.status(200).json({freelancerData: usercode.data,message: "Freelancer all details."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid id."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static flChangeEmail = async (req: any, res: Response, next: any) => {
    if(req.body.current_email == req.body.new_email){
      return res.status(201).json({message:"Your current email and new email are same."});
    }
    if(req.user.role !=0){
      return res.status(403).json({success: false, message: 'You dont have to permission to access'})
    }
    let usercode = await service.flChangeEmail(req.user,req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Otp send to your verify email id."});
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Email not found."});
    }else if( usercode.statuscode == 202){
      return res.status(202).json({message: "Your new email in already registered try with new one."});
    }else if( usercode.statuscode == 203){
      return res.status(203).json({message: "New email data not updated."});
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static flVerifyChangeEmail = async (req: any, res: Response, next: any) => {
    if (!req.body.otp) {
      return res.status(400).json({message: "Otp is required"})
    }
    let usercode = await service.flVerifyChangeEmail(req.user,req.body)
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "Otp verified successfully"})
    }else if( usercode.statuscode == 500){
      return res.status(500).json({message: "Something went wrong"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Invalid Otp"})
    }else if( usercode.statuscode == 202){
      return res.status(202).json({message: "Your new email already registered."})
    }else if( usercode.statuscode == 203){
      return res.status(203).json({message: "New email not updated."})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static reviewFl = async (req: any, res: Response, next: any) => {
    let usercode = await service.reviewFl(req.user,req.body);
    console.log(usercode);
    if( usercode.statuscode == 200){
      return res.status(200).json({message: "rated successfully"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "already rated"})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }
  
  public static freelancerSearch = async (req: any, res: Response, next: any) => {
    let usercode = await service.freelancerSearch(req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({freelancerData: usercode.data,message: "Search freelancer data"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found"})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static freelancerListByGigID = async (req: any, res: Response, next: any) => {
    let usercode = await service.freelancerListByGigID(req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({freelancerData: usercode.data,message: "freelancer review"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found"})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

}

export default FreelancerController;
