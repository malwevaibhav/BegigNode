export interface IDatabase {
    database: string,
    dialect: string,
    host: string,
    password: string,
    port: string,
    username: string,
}