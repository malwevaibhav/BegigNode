import { User } from "../models/User";
import { Freelancer } from "../models/Freelancer";
import { FreelancersEducations } from "../models/FreelancerEducations";
import { FreelancersSkills } from "../models/FreelancersSkills";
import { FreelancerExperience } from "../models/FreelancerExperience";
import { FreelancerFeedback } from "../models/FreelancerFeedback";
import { SavedFreelancer } from "../models/SavedFreelancer";
import { getRepository, Brackets, MoreThanOrEqual } from 'typeorm';
import { FreelancerAccomplishments } from "../models/FreelancerAccomplishments";
import { FreelancerBankDetails } from "../models/FreelancerBankDetails";
import { FreelancerBillingAddress } from "../models/FreelancerBillingAddress";
import { ZohoInfo } from "../models/ZohoInfo";
const {updateZohoFreelancer} = require('../helper/zohoApi');
import { log } from "console";
const {mailSendFunction} = require('../helper/mailSend');
require('dotenv').config();
const axios = require('axios');
const util = require('util');
const fs = require('fs');

export class FreelancerService {

    //Search freelancer
    async searchFreelancer(body:any, user:any): Promise<any> {
        try {
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            var freelancerDetails:any = "";
            var query_condition :any = "";
            var search_query_condition :any = "";
            var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var search_key = body.search_key;
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(search_key != ""&& search_key != undefined){
                search_query_condition = new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                    }
                );
            }
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "user.created_at >="+from+" AND user.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "user.created_at >="+from+" AND user.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "user.created_at >="+from+" AND user.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "user.created_at >="+from+" AND user.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "user.created_at >="+from+" AND user.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "user.created_at >="+from+" AND user.created_at < "+to+"";
            }
            if(query_condition != "" && search_query_condition !=""){
                freelancerDetails = await getRepository(Freelancer)
                .createQueryBuilder("freelancecr")
                .leftJoinAndSelect("freelancecr.user", "user")
                .leftJoinAndSelect("user.userMeta","userMeta")
                .where("status = 1")
                .andWhere("is_deleted = 0")
                .andWhere(query_condition)
                .andWhere(search_query_condition)
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(search_query_condition != ""){
                freelancerDetails = await getRepository(Freelancer)
                .createQueryBuilder("freelancecr")
                .leftJoinAndSelect("freelancecr.user", "user")
                .leftJoinAndSelect("user.userMeta","userMeta")
                .where("status = 1")
                .andWhere("is_deleted = 0")
                .andWhere(search_query_condition)
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(query_condition != ""){
                freelancerDetails = await getRepository(Freelancer)
                .createQueryBuilder("freelancecr")
                .leftJoinAndSelect("freelancecr.user", "user")
                .leftJoinAndSelect("user.userMeta","userMeta")
                .where("status = 1")
                .andWhere("is_deleted = 0")
                .andWhere(query_condition)
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else{
                freelancerDetails = await getRepository(Freelancer)
                .createQueryBuilder("freelancecr")
                .leftJoinAndSelect("freelancecr.user", "user")
                .leftJoinAndSelect("user.userMeta","userMeta")
                .where("status = 1")
                .andWhere("is_deleted = 0")
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }
            if(freelancerDetails.length > 0){
                return {statuscode:200,data:freelancerDetails};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    //get freelancer details by id
    async getFreelancerDetailsById(body:any, user:any, id:any): Promise<any> {
        try {
            const freelancerRepository = getRepository(Freelancer);
            const freelancerFeedback = getRepository(FreelancerFeedback);
            const freelancerDetails = await freelancerRepository.find({ relations: ["user"], where: { id:id} });
            const productCount = await freelancerFeedback.count({ fl_id: id });
            if(freelancerDetails.length > 0){
                return {statuscode:200,data: {...freelancerDetails, review: productCount}};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    //get freelancer basic detials by id
    async gerfreelancerskills(body:any, user:any, id:any): Promise<any> {
        try {
            const Freelancers_skills_Repository = getRepository(FreelancersSkills);
            const skills : any = await Freelancers_skills_Repository.find({where: {  freelancer:id}, select: ["skill", "experience_in_month"] });
            if(skills.length > 0){
                return {statuscode:200,data:skills};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getFreelancerEducation(body:any, user:any, id:any): Promise<any> {
        try {
            const Freelancers_educations_Repository = getRepository(FreelancersEducations);
            const education = await Freelancers_educations_Repository.find({where: { freelancerId:id}, select: ["freelancerId", "educationQualificationsId", "institution_name", "start_date", "end_date", "specializaion", "currently_studying"],relations: ["educationQualifications"]});
            if(education.length > 0){
                return {statuscode:200,data:education};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getFreelancerExperience(body:any, user:any, id:any): Promise<any> {
        try {
            let Freelancer_experience_Repository = getRepository(FreelancerExperience);
            const experience = await Freelancer_experience_Repository.find({  where: { freelancerId:id}, select: ["freelancerId","company_name","start_date", "end_date", "total_exp_in_month","job_type", "description","designation","present_company"]});
            if(experience.length > 0){
                return {statuscode:200,data:experience};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getFreelancerAccomplishments(body:any, user:any, id:any): Promise<any> {
        try {
            const freelancerRepository = getRepository(Freelancer);
            const Freelancers_FreelancerAccomplishments = getRepository(FreelancerAccomplishments);
            const Accomplishments = await Freelancers_FreelancerAccomplishments.find({where: { freelancerId: id }, select: ["name_of_license","organisation_name", "url", "start_date", "end_date", "license_staus"] });
            const freelancerDetails = await freelancerRepository.find({where: { id:id}, select:["linkedin_url","github_url", "other_url"]});
            if(Accomplishments.length > 0){
                return {statuscode:200,data: {...Accomplishments,socialMediaUrl: freelancerDetails}};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async saveFreelancerdata(body:any, user:any): Promise<any> {
        try {
            const saveFlRepo = getRepository(SavedFreelancer);
            const saveFlData :any= await saveFlRepo.find({ where: { employer_id:user.id, fl_id :body.freelancerId,gig_id:body.gig_id}});
            if(saveFlData.length > 0){
                return {statuscode:201};
            }else{
                let currentTime = Date.now() / 1000;
                let savedata = new SavedFreelancer();
                    savedata.fl_id = body.freelancerId;
                    savedata.gig_id = body.gig_id;
                    savedata.match_score = body.match_score || 0;
                    savedata.employer_id = user.id;
                    savedata.saved_on = currentTime;
                const savedData = await saveFlRepo.save(savedata);
                return {statuscode:200};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async savedFreelancersList(user:any,gig_id:any): Promise<any> {
      try {

        const saveFlRepo = await getRepository(SavedFreelancer)
        const saveFldata = await saveFlRepo.find({ where: { employer_id:user.id,gig_id:gig_id} });
        var saveFlIds = [];

        for(let i =0; i < saveFldata.length; i++){
            saveFlIds.push(saveFldata[i].fl_id)
        }

        if(saveFlIds.length > 0){
          const freelancerDetails :any= await getRepository(Freelancer)
            .createQueryBuilder("freelancer")
            .leftJoinAndSelect("freelancer.user", "user")
            .where("freelancer.id IN (:...ids)",{ ids: saveFlIds })
            .getMany();
            for(let j =0; j < freelancerDetails.length; j++){
                for(let i =0; i < saveFldata.length; i++){
                    if(freelancerDetails[j].id == saveFldata[i].fl_id){
                        freelancerDetails[j].match_score = saveFldata[i].match_score
                        freelancerDetails[j].gig_id = saveFldata[i].gig_id
                    }
                }
            }
            return {statuscode:200,data: {freelancerDetails, numberOfRecord: freelancerDetails.length}};
        } else {
            return {statuscode:201};
        }

    }catch (error) {console.log(error);
        if(process.env.ENV != "development"){
            rollbar.error(error);
        } 
        return {statuscode:500};
      }
    }

    async deleteSavedFreelancers(params:any): Promise<any> {
        try{
            const saveFlRepo = await getRepository(SavedFreelancer)
            let res:any = await saveFlRepo.delete({fl_id:params.fl_id,gig_id: params.gig_id});
            if(res.affected > 0){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async hiredFreelancersList(body:any, user:any, token:any): Promise<any>{
        try{
            const bigigJobUrl = process.env.Begig_job_url+'api/v1/job/hired/freelancers/list';
            const json = JSON.stringify({"id": user.id});
                const res = await axios.post(bigigJobUrl, json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                if(res.data.data.length > 0){
                let freelancerRepo = getRepository(Freelancer);
                const fls = await freelancerRepo.createQueryBuilder("freelancer").leftJoinAndSelect("freelancer.user", "user").leftJoinAndSelect("freelancer.freelancersSkills", "freelancers_skills").where("freelancer.id IN (:...ids)", { ids: res.data.data }).getMany();
                let obj = {count:res.data.data.length,records:fls};
                return {statuscode:200,data:obj};
                }else{res.data.data
                return {statuscode:201};
                }
        }catch(err){
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async getClientFeedback(body:any, user:any, id:any): Promise<any> {
        try {
            const freelancer_feedback = getRepository(FreelancerFeedback);
            const fl_feedback = await freelancer_feedback.find({relations: ["user"], where: { fl_id: id }});
            if(fl_feedback.length > 0){
                return {statuscode:200,data:fl_feedback};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async multiFreelanceDataByIds(body:any, user:any): Promise<any> {
        try {
            const fl_details = await getRepository(Freelancer)
            .createQueryBuilder("freelancer")
            .leftJoinAndSelect("freelancer.user", "user")
            .where("freelancer.id IN (:...ids)",{ ids: body.id })
            .getMany();
            if(fl_details.length > 0){
                return {statuscode:200,data:fl_details};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async bankAndBilingAddUpdate(user:any,body:any): Promise<any> {
        try {
            const freelancerBankDetailsRepo = getRepository(FreelancerBankDetails);
            const freelancerBillingAddressRepo = getRepository(FreelancerBillingAddress);
            const zohoInfoRepo = getRepository(ZohoInfo);
            const userRepository = getRepository(User);
            var currentTime = Date.now() / 1000;
            let flBankdata = await freelancerBankDetailsRepo.find({freelancer: user.freelancer_id});
            if(flBankdata.length > 0){
                var bankDetails = {
                    bank_full_name : body.bank_full_name,
                    bank_account_number: body.bank_account_number,
                    ifsc_code :body.ifsc_code,
                    branch_name : body.branch_name,
                    created_at : currentTime,
                    created_by : user.id,
                    freelancer : user.freelancer_id,
                }
                const savedDetails =  await freelancerBankDetailsRepo.update({ created_by: user.id }, bankDetails);

                var BillingAddress = {
                    complete_address : body.complete_address,
                    pin_code: body.pin_code,
                    city :body.city,
                    state : body.state,
                    country : body.country,
                    created_by : user.id,
                    freelancer : user.freelancer_id,
                }
                const savedBillingAddressRepo =  await freelancerBillingAddressRepo.update({ created_by: user.id }, BillingAddress);   
                try{
                    var abc = body.state;
                    var arr :any= { "Andhra Pradesh": 'AD', "Arunachal Pradesh": 'AR', "Assam": 'AS',"Bihar": 'BR',"Chattisgarh": 'CG',
                        "Delhi": 'DL',"New Delhi": 'DL',"Goa": 'GA',"Gujarat": 'GJ',"Haryana": 'HR',"Himachal Pradesh": 'HP',"Jammu and Kashmir": 'JK',
                        "Jharkhand": 'JH',"Karnataka": 'KA',"Kerala": 'KL',
                        "Lakshadweep Islands": 'LD',"Madhya Pradesh": 'MP',"Maharashtra": 'MH',"Manipur": 'MN',"Meghalaya": 'ML',
                        "Mizoram": 'MZ',"Nagaland": 'NL',"Odisha": 'OD',"Pondicherry": 'PY',"Punjab": 'PB',"Rajasthan": 'RJ',
                        "Sikkim": 'SK',"Tamil Nadu": 'TN',"Telangana": 'TS',"Tripura": 'TR',"Uttar Pradesh": 'UP',
                        "Uttarakhand": 'UK',"West Bengal": 'WB',"Andaman and Nicobar Islands": 'AN',"Chandigarh": 'CH',
                        "Dadra & Nagar Haveli and Daman & Diu": 'DNHDD',"Ladakh": 'LA',"Other Territory": 'OT',
                    };
    
                    let placeOfSupply :any= "";
                    for (var key in arr) {
                        if(key == abc){    
                            placeOfSupply = arr[key];
                            break;      
                        }
                    }
                    var updateData = {
                        Country: body.country,
                        City: body.city,
                        Zip_Code:body.pin_code,
                        Street: body.complete_address,
                        State : body.state,
                        Place_of_Supply:placeOfSupply
                    }
                    var zohoData :any = await zohoInfoRepo.findOne();
                    updateZohoFreelancer(zohoData.accesstoken,user.zoho_user_id,updateData);
                }catch(error){
                    console.log(error); 
                    if(process.env.ENV != "development"){
                        rollbar.error(error);
                    }                   
                }                 
                if(savedBillingAddressRepo.affected){
                    return {statuscode:200};
                } else {
                    return {statuscode:201};
                }
            }else{
                let saveFlBankDetails = new FreelancerBankDetails();
                    saveFlBankDetails.bank_full_name = body.bank_full_name;
                    saveFlBankDetails.bank_account_number = body.bank_account_number;
                    saveFlBankDetails.ifsc_code = body.ifsc_code;
                    saveFlBankDetails.branch_name = body.branch_name;
                    saveFlBankDetails.created_at = currentTime;
                    saveFlBankDetails.created_by = user.id;
                    saveFlBankDetails.freelancer = user.freelancer_id;
                const savedDetails = await freelancerBankDetailsRepo.save(saveFlBankDetails);

                let saveFlBillingAddress = new FreelancerBillingAddress();
                    saveFlBillingAddress.complete_address = body.complete_address;
                    saveFlBillingAddress.pin_code = body.pin_code;
                    saveFlBillingAddress.city = body.city;
                    saveFlBillingAddress.state = body.state;
                    saveFlBillingAddress.country = body.country;
                    saveFlBillingAddress.created_at = currentTime;
                    saveFlBillingAddress.created_by = user.id;
                    saveFlBillingAddress.freelancer = user.freelancer_id;
                const savedFLBillingAdd = await freelancerBillingAddressRepo.save(saveFlBillingAddress);    
                try{
                    var abc = body.state;
                   
                    var arr :any= { "Andhra Pradesh": 'AD', "Arunachal Pradesh": 'AR', "Assam": 'AS',"Bihar": 'BR',"Chattisgarh": 'CG',
                        "Delhi": 'DL',"New Delhi": 'DL',"Goa": 'GA',"Gujarat": 'GJ',"Haryana": 'HR',"Himachal Pradesh": 'HP',"Jammu and Kashmir": 'JK',
                        "Jharkhand": 'JH',"Karnataka": 'KA',"Kerala": 'KL',
                        "Lakshadweep Islands": 'LD',"Madhya Pradesh": 'MP',"Maharashtra": 'MH',"Manipur": 'MN',"Meghalaya": 'ML',
                        "Mizoram": 'MZ',"Nagaland": 'NL',"Odisha": 'OD',"Pondicherry": 'PY',"Punjab": 'PB',"Rajasthan": 'RJ',
                        "Sikkim": 'SK',"Tamil Nadu": 'TN',"Telangana": 'TS',"Tripura": 'TR',"Uttar Pradesh": 'UP',
                        "Uttarakhand": 'UK',"West Bengal": 'WB',"Andaman and Nicobar Islands": 'AN',"Chandigarh": 'CH',
                        "Dadra & Nagar Haveli and Daman & Diu": 'DNHDD',"Ladakh": 'LA',"Other Territory": 'OT',
                    };
    
                    let placeOfSupply :any= "";
                    for (var key in arr) {
                        if(key == abc){    
                            placeOfSupply = arr[key];
                            break;      
                        }
                    }
                    var updateDatas = {
                        Country: body.country,
                        City: body.city,
                        Zip_Code:body.pin_code,
                        Street: body.complete_address,
                        State : body.state,
                        Place_of_Supply:placeOfSupply
                    }
                    var zohoData :any = await zohoInfoRepo.findOne();                         
                    updateZohoFreelancer(zohoData.accesstoken,user.zoho_user_id,updateDatas);
                }catch(error){
                    console.log(error);
                    if(process.env.ENV != "development"){
                        rollbar.error(error);
                    } 
                }               
                return {statuscode:200};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async flTaxInformation(user:any,body:any): Promise<any> {
        try {
            const freelancerRepository = getRepository(Freelancer);
            if(body.indian_citizen == 0){
                var taxInfo :any = {
                    indian_citizen:0,
                    pan_number: body.pan_number,
                    gst_number: body.gst_number
                }
                const savedDetails =  await freelancerRepository.update({ id: user.freelancer_id }, taxInfo);
                if(savedDetails.affected){
                    return {statuscode:200};
                }else{
                    return {statuscode:201};
                }
            }
            if(body.indian_citizen == 1){
                var taxInfomation = {
                    indian_citizen:1,
                    passport_number: body.passport_number,
                    country: body.country
                }
                const savedDetails =  await freelancerRepository.update({ id: user.freelancer_id }, taxInfomation);
                if(savedDetails.affected){
                    return {statuscode:200};
                }else{
                    return {statuscode:201};
                }
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getFlbankAndBiling(user:any,body:any): Promise<any> {
        try {
            const freelancerBankDetailsRepo = getRepository(FreelancerBankDetails);
            const freelancerBillingAddressRepo = getRepository(FreelancerBillingAddress);
            let flBankDetails = await freelancerBankDetailsRepo.find({where:{created_by: user.id}, select: ["bank_full_name", "bank_account_number", "ifsc_code", "branch_name"]});
            let flBillingAdd = await freelancerBillingAddressRepo.find({where:{created_by: user.id}, select: ["complete_address", "pin_code", "city", "state","country"]});
            if(flBankDetails.length > 0){
                return {statuscode:200,data:{flBankDetails, flBillingAdd}};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getflTaxInformation(user:any,body:any): Promise<any> {
        try {
            const freelancerRepository = getRepository(Freelancer);
            const fLdata = await freelancerRepository.find({where: { id: user.freelancer_id }, select: ["indian_citizen","pan_number", "gst_number", "passport_number", "country"] });
            if(fLdata.length > 0){
                return {statuscode:200,data:fLdata};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async updateGigCompletedCountForFl(user:any,body:any): Promise<any> {
        try {
            var fl_id = body.fl_id;
            const freelancerRepository = getRepository(Freelancer);
            const freelancer : any = await freelancerRepository.find({ id:fl_id});
            if(freelancer.length > 0){
                const savedDetails =  await freelancerRepository.update({ id: fl_id }, {completed_gigs:freelancer[0].completed_gigs+1});
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getFreelancerAllDetailsById(fl_id:any): Promise<any> {
        try {
            const freelancerRepository = getRepository(Freelancer);
            const freelancerDetails = await freelancerRepository.find({where: { id:fl_id}, relations: ["user","freelancersSkills","freelancerExperience","freelancersEducations","freelancerAccomplishments","freelancerFeedback"] });
            if(freelancerDetails.length > 0){
                return {statuscode:200,data: freelancerDetails};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async flChangeEmail(user:any,body:any): Promise<any> {
        try {
            var { current_email, new_email } = body;
            const userRepository = getRepository(User);
           
            const users :any = await userRepository.findOne({ where: { email: current_email,is_deleted:0}});
            if(users){
                const new_user :any = await userRepository.findOne({ where: { email: new_email,is_deleted:0}});
                if(new_user){
                    return {statuscode:202};
                }else{
                    var otpcode :any= Math.floor(1000 + Math.random() * 9000);
                    var resetPasswordExpires = parseInt(""+Date.now()/1000) + 3600;
                    if(process.env.ENV != "development"){
                      otpcode = 1111;
                    }
                    /* SENDING OTP STARTS */
                    const readFile = util.promisify(fs.readFile);
                    let email_template_str  = await readFile('email-template.html','utf8');
                    // let message = email_template_str.replace("{{OTP}}", otpcode);
                    // message = message.replace("{{NAME}}", users.first_name);
                    let message = "Your otp is "+otpcode+"";
                    let reciver_address = current_email;
                    let subject =  "Begig OTP";
                    await mailSendFunction(reciver_address,message,subject,"");
                    // if(process.env.ENV != "development"){
                    //   await mailSendFunction(reciver_address,message,subject,"");
                    // }
                    const updateToken = await userRepository.update({ id:  users.id }, {otp:otpcode, otp_expire_time:resetPasswordExpires,temp_email: new_email});
                    if(updateToken.affected){
                        return {statuscode:200};
                    }else{
                        return {statuscode:203};
                    }
                }
            }else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log(error);
            return {statuscode:500};
        }
    }

    async flVerifyChangeEmail(user:any,body:any): Promise<any> {
        try {
            const { otp } = body;
            const userRepository = getRepository(User);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var time = Date.now()/1000;
            var users :any= await userRepository.findOne({ where: { id: user.id, otp_expire_time: MoreThanOrEqual(time), otp: otp }});
            if(!users){
                return {statuscode:201};
            } else {
                const new_email_cheack = await userRepository.findOne({ where: { email: users.temp_email }});
                if(new_email_cheack){
                    return {statuscode:202};
                }else{
                    var update_email = await userRepository.update({ id:  users.id }, {email: users.temp_email, otp:"", otp_expire_time:0,temp_email:""});  
                    try{
                        var updateData = {
                            Email: users.temp_email,
                        }
                        var zohoData :any = await zohoInfoRepo.findOne();
                        updateZohoFreelancer(zohoData.accesstoken,user.zoho_user_id,updateData);
                    }catch(error){
                        if(process.env.ENV != "development"){
                            rollbar.error(error);
                        } 
                        console.log(error);
                    }                                    
                    if(update_email.affected){
                        return {statuscode:200};
                    }else{
                        return {statuscode:203};
                    }
                }
            }
        } catch (err) {
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async reviewFl(user:any,body:any): Promise<any> {
      try {
        var employer_id = user.employer_id;
        var fl_id = body.fl_id;
        var gig_id = body.gig_id;
        var rate = body.rate;
        var review = body.review;
        const userRepository = getRepository(User);
        const freelancerRepository = getRepository(Freelancer);
        const freelancerFeedbackRepository = getRepository(FreelancerFeedback);
        var chk:any = await freelancerFeedbackRepository.findOne({ where: { userId: employer_id,fl_id:fl_id,gig_id:gig_id}})
        if(chk){
          return {statuscode:201};
        }else{
          let feedbackObj = new FreelancerFeedback();
          feedbackObj.userId = employer_id;
          feedbackObj.fl_id = fl_id;
          feedbackObj.gig_id = gig_id;
          feedbackObj.average_rating = rate;
          feedbackObj.feedback = review;
          feedbackObj.created_at = Date.now()/1000;
          feedbackObj.freelancer = fl_id;
          feedbackObj.user = employer_id;
          const savedFeedback = await freelancerFeedbackRepository.save(feedbackObj);
          let total_rate = 0;
          total_rate = await getRepository(FreelancerFeedback)
            .createQueryBuilder("freelancer_feedback")
            .where("freelancer_feedback.fl_id = "+fl_id)
            .getCount();
          let fl:any = await freelancerRepository.findOne({where:{id:fl_id},relations:['user']});
          let user_id = fl.user.id;
          let usr:any = await userRepository.findOne({where:{id:user_id}});
          let new_avg_rate = (usr.average_rating + rate) / (total_rate+1);
          let update_rate = await userRepository.update({ id: user_id }, {average_rating:new_avg_rate});
          return {statuscode:200};
        }
      } catch (err) {console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500};
      }
    }

    async freelancerSearch(body:any): Promise<any> {
        try {
            var page_number :any= body.page_number || 0;
            var number_of_record:any = body.number_of_record || 10;
            var search_str :any = body.search_str || "";
            var freelancerData : any = "";
            var search_type :any = body.search_type //"all" , "skills" , "people" , "designation"
            if(search_str == ""){
                freelancerData = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .leftJoinAndSelect("freelancer.freelancersSkills", "freelancersSkills")
                .leftJoinAndSelect("freelancer.freelancerExperience", "freelancerExperience")
                .where("user.status = 1")
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }
            else if(search_type == "all"){
                freelancerData = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .leftJoinAndSelect("freelancer.freelancersSkills", "freelancersSkills")
                .leftJoinAndSelect("freelancer.freelancerExperience", "freelancerExperience")
                .where("user.status = 1")
                .andWhere( new Brackets( qb => {
                    qb.orWhere("user.first_name like :search_str", { search_str: `%${search_str}%` })
                        .orWhere("user.last_name like :search_str", { search_str: `%${search_str}%` })
                        .orWhere("freelancersSkills.skill like :search_str", { search_str: `%${search_str}%` })
                        .orWhere("freelancerExperience.designation like :search_str", { search_str: `%${search_str}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(search_type == "skills"){
                freelancerData = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .leftJoinAndSelect("freelancer.freelancersSkills", "freelancersSkills")
                .leftJoinAndSelect("freelancer.freelancerExperience", "freelancerExperience")
                .where("user.status = 1")
                .andWhere("freelancersSkills.skill like :search_str", { search_str: `%${search_str}%` })
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(search_type == "people"){
                console.log('people');
                freelancerData = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .leftJoinAndSelect("freelancer.freelancersSkills", "freelancersSkills")
                .leftJoinAndSelect("freelancer.freelancerExperience", "freelancerExperience")
                .where("user.status = 1")
                .andWhere( new Brackets( qb => {
                    qb.orWhere("user.first_name like :search_str", { search_str: `%${search_str}%` })
                        .orWhere("user.last_name like :search_str", { search_str: `%${search_str}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(search_type == "designation"){
                freelancerData = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .leftJoinAndSelect("freelancer.freelancersSkills", "freelancersSkills")
                .leftJoinAndSelect("freelancer.freelancerExperience", "freelancerExperience")
                .where("user.status = 1")
                .andWhere("freelancerExperience.designation like :search_str", { search_str: `%${search_str}%` })
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

            }
            if(freelancerData.length > 0){
                return {statuscode:200,data:freelancerData};
            }else{
                return {statuscode:201};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async freelancerListByGigID(body:any): Promise<any> {
        try {
            console.log("body.gig_id " , body.gig_id );
            const fl_details = await getRepository(Freelancer)
            .createQueryBuilder("freelancer")
            .leftJoinAndSelect("freelancer.user", "user")
            .leftJoinAndSelect("freelancer.freelancerFeedback", "freelancerFeedback")
            .where("freelancerFeedback.gig_id IN (:...ids)",{ ids: body.gig_id })
            .select(['freelancer.id','user.first_name','user.last_name','user.profile_pic','freelancerFeedback.gig_id','freelancerFeedback.average_rating'])
            .getMany();
            if(fl_details.length > 0){
                return {statuscode:200,data:fl_details};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


}

