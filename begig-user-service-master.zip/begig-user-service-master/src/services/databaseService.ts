import EventEmitter = require('events');
import { createConnection } from 'typeorm';
import config from '../config/config';
import { Logger } from '../lib/logger';
import { Company } from '../models/Company';
import { EducationQualifications } from '../models/EducationQualifications';
import { Employer } from '../models/Employer';
import { FreelancersEducations } from '../models/FreelancerEducations';
import { Freelancer } from '../models/Freelancer';
import { FreelancersSkills } from '../models/FreelancersSkills';
import { FreelancerExperience } from '../models/FreelancerExperience';
import { Referrals } from '../models/Referrals';
import { User } from '../models/User';
import { FreelancerAccomplishments } from '../models/FreelancerAccomplishments';
import { FreelancerFeedback } from '../models/FreelancerFeedback';
import { SavedFreelancer } from '../models/SavedFreelancer';
import { CompanyBankDetails } from '../models/CompanyBankDetails';
import { FreelancerBankDetails } from '../models/FreelancerBankDetails';
import { FreelancerBillingAddress } from '../models/FreelancerBillingAddress';
import { UserMeta } from '../models/UserMeta';
import { ZohoInfo } from '../models/ZohoInfo';
import { Notifications } from '../models/Notifications';

class DatabaseService {

  public static emitter: EventEmitter = new EventEmitter();
  public static isConnected = false;
  public static logger: any = new Logger();

  public static async getConnection(callback = null, wait = false) {
    DatabaseService.handleConnectionError();
    return await DatabaseService.createConnection();
  }

  public static async createConnection() {
    const dbConfig = config[`${process.env.ENV}`];
    return await createConnection({
      type: 'mysql',
      host: dbConfig.host,
      port: parseInt(dbConfig.port),
      username: dbConfig.username,
      password: dbConfig.password,
      database: dbConfig.database,
      entities: [
        User,Freelancer,Company,EducationQualifications,Employer,FreelancersEducations,FreelancersSkills,
        Referrals,FreelancerExperience,FreelancerAccomplishments,FreelancerFeedback,SavedFreelancer,CompanyBankDetails,
        FreelancerBankDetails,FreelancerBillingAddress,UserMeta,ZohoInfo,Notifications
      ],
    }).then(() => {
      DatabaseService.isConnected = true;
      DatabaseService.logger.log('info', 'database connected successfully');
    }).catch((err: Error) => {
      console.log("database error " , err);
      DatabaseService.logger.log('info', 'database connection error...retrying');
      DatabaseService.emitter.emit('DB_CONNECT_ERROR');
    });
  }
  public static async handleConnectionError() {
    DatabaseService.emitter.on('DB_CONNECT_ERROR', async () => {
      DatabaseService.logger.log('info', 'database connection error...retrying');
      setTimeout(async () => {
        await DatabaseService.createConnection();
      }, 3000)
    });
  }
}

export { DatabaseService };
