import { User } from "../models/User";
import { Freelancer } from "../models/Freelancer";
import { EducationQualifications } from "../models/EducationQualifications";
import { FreelancersEducations } from "../models/FreelancerEducations";
import { FreelancersSkills } from "../models/FreelancersSkills";
import { FreelancerExperience } from "../models/FreelancerExperience";
import { FreelancerFeedback } from "../models/FreelancerFeedback";
import { getRepository, Like, LessThan, MoreThan, MoreThanOrEqual, createQueryBuilder, getManager, Not,Brackets } from 'typeorm';

import { Employer } from "../models/Employer";
import { Company } from "../models/Company";
import { FreelancerAccomplishments } from "../models/FreelancerAccomplishments";
import { SavedFreelancer } from "../models/SavedFreelancer";
import { UserMeta } from "../models/UserMeta";
import { Notifications } from "../models/Notifications";
import { ZohoInfo } from "../models/ZohoInfo";
const {zohoCreateAccessToekn,createZohoFreelancer,createZohoEnterpriseAccount, updateZohoFreelancer,createZohoContact,updateZohoContact} = require('../helper/zohoApi');
const AWS = require('aws-sdk');
const {s3fileUpload,s3MultiplefileUpload} = require('../helper/fileUpload');
var crypto = require("crypto");
const {mailSendFunction} = require('../helper/mailSend');
const {sendNotifications} = require('../helper/sendNotifications');
const multer = require('multer');
const { extname } = require('path');
const path = require("path");
const fs = require('fs');
var bcrypt = require('bcryptjs');
require('dotenv').config()
const jwt = require('jsonwebtoken');
const axios = require('axios');
const Razorpay = require('razorpay');
const util = require('util');
const {rollbar} = require('../helper/rollbar');

export class AuthService {

    async test(): Promise<any>{
      try{
        const readFile = util.promisify(fs.readFile);
        let email_template_str  = await readFile('email-template.html','utf8');
        let message = email_template_str.replace("{{OTP}}", "1234");
        message = message.replace("{{NAME}}", "Farid");
        let reciver_address = "farid.shaikh8894@gmail.com";
        let subject =  "Begig OTP";
        if(process.env.ENV == "UAT"){console.log("email sent");
          await mailSendFunction(reciver_address,message,subject,"");
        }
      }catch(err){
        console.log(err);
      }
    }

    async siteAdinLogin(model:any): Promise<any> {
        try {
            const { email, password } = model;
            const users:any = await getRepository(User)
            .createQueryBuilder("user")
            .where("user.email =:email",{email: email })
            .andWhere("user.is_deleted = 0")
            .andWhere("(user.role =3 OR user.role =2)")
            .getOne();
            if(users){
                const validPass = await bcrypt.compare(password, users.password);
                if (validPass){
                    const token = jwt.sign({ id: users.id,freelancer_id :null, employer_id : null, employer_type : null,company_id:null, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time }, process.env.JWT_SECRET);
                    return { statuscode:200,token:token};
                } else {
                    return {statuscode:201};
                }
            }else{
                return {statuscode:201};
            }
        } catch (err) {
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }  
            return {statuscode:500};
        }
    }


    async fileUpload(file:any): Promise<any> {
        try{
            var fileUrl = await s3fileUpload(file);
            return {statuscode:200,data:fileUrl};
        }catch(error){
            console.log("error " , error);
            return {statuscode:500};
        }
    }

    async multipleFilesUpload(files:any): Promise<any> {
        try{
            var multiFilesUrl = await s3MultiplefileUpload(files);
            return {statuscode:200,data:multiFilesUrl};
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }  
            console.log("error " , error);
            return {statuscode:500};
        }
    }

    async createEmployerAdmin(data:any,user:any):Promise<any>{
      try{
        const userRepository = getRepository(User);
        const employerRepositor = getRepository(Employer);
        const zohoInfoRepo = getRepository(ZohoInfo);
        var zohoToken :any = await zohoInfoRepo.findOne();
        const {first_name,last_name,email} = data;
        const company_id = user.company_id;
        const users = await userRepository.findOne({ where: { email:email, is_deleted:0}});
        let currentTime = Date.now() / 1000;
        if(users){
          return {statuscode:201};
        }else{
          var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
          var new_pass = "";
          for (var i = 0, n = charset.length; i < 8; ++i) {
            new_pass += charset.charAt(Math.floor(Math.random() * n));
          }
          var encryptpassword = await bcrypt.hash(new_pass, 12);
          let userObj = new User();
          userObj.first_name = first_name;
          userObj.last_name = last_name;
          userObj.otp = "";
          userObj.otp_expire_time = 0;
          userObj.password = encryptpassword;
          userObj.email = email;
          userObj.role = 1;
          userObj.created_at = currentTime;
          userObj.updated_at = currentTime;
          userObj.status = 1;
          const savedUser = await userRepository.save(userObj);
          let employerObj = new Employer();
          employerObj.user = savedUser;
          employerObj.company = company_id;
          employerObj.location = "";
          employerObj.type = 1;
          const savedEmployer = await employerRepositor.save(employerObj);
          let  message =  'Hi '+first_name+',\n\n' +
          'Welcome to the Begig V2, your account is created by your company admin, please find login to new version with email '+email+' and password '+new_pass+' \n\nThanks.';
          let  subject =  "Welcome to Begig V2";
          var sentMail = await mailSendFunction(email,message,subject,"");

            try{
                var Shipping_Code ="";
                var Phone ="";
                var Billing_State ="";
                var Shipping_Street ="";
                var Salutation = "";
                var First_Name = first_name;
                var Last_Name = last_name;
                var Department = "";
                var Mailing_Country = "";
                var Mailing_City = "";
                var Title = "";
                var Mobile = "";
                var Lead_Source = "";
                var createContactOnZoho = await createZohoContact(zohoToken.accesstoken,user.zoho_enterprise_id,email,Shipping_Code,Phone,Billing_State,Shipping_Street,Salutation,First_Name,Last_Name,Department,Mailing_Country,Mailing_City,Title,Mobile,Lead_Source);

                await userRepository.update({ id: savedUser.id }, {zoho_enterprise_id:user.zoho_enterprise_id,zoho_user_id:createContactOnZoho.data[0].details.id});

            }catch(error){
                console.log(error);
            }
          return {statuscode:200};
        }
      }catch(err){
        console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500}
      }
    }

    async listOfCompanyAdmins(body:any,user:any):Promise<any>{
      try{
        const page_number = body.page || 0;
        const number_of_record = body.record || 10;
        const saerch_str = body.search_str || "";
        const company_id = user.company_id;
        var search_query_condition:any = "";
        if(saerch_str != ""&& saerch_str != undefined){
          search_query_condition = new Brackets( qb => {
              qb.where("user.first_name like :search_key", { search_key: `%${saerch_str}%` })
                .orWhere("user.email like :search_key", { search_key: `%${saerch_str}%` })
                .orWhere("user.mobile_no like :search_key", { search_key: `%${saerch_str}%` })
              }
          );
          var freelancerDetails:any = await getRepository(Employer)
          .createQueryBuilder("employer")
          .leftJoinAndSelect("employer.user", "user")
          .leftJoinAndSelect("employer.company", "company")
          .andWhere("user.is_deleted = 0")
          .andWhere("employer.type = 1")
          .andWhere("company.id = "+company_id)
          .andWhere(search_query_condition)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
        }else{
          var freelancerDetails:any = await getRepository(Employer)
          .createQueryBuilder("employer")
          .leftJoinAndSelect("employer.user", "user")
          .leftJoinAndSelect("employer.company", "company")
          .andWhere("user.is_deleted = 0")
          .andWhere("employer.type = 1")
          .andWhere("company.id = "+company_id)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
        }
        if(freelancerDetails.length > 0){
          return {statuscode:200,data:freelancerDetails}
        }else{
          return {statuscode:201}
        }
      }catch(err){
        console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500}
      }
    }

    async signupEmployer(data:any): Promise<any>{
        try{
            const userRepository = getRepository(User);
            const employerRepositor = getRepository(Employer);
            const companyRepositor = getRepository(Company);
            const userMetaRepository = getRepository(UserMeta);
            const {first_name,last_name,email,password,company_name,referral_code,meta} = data;
            const users = await userRepository.findOne({ where: { email:email, is_deleted:0}});
            if(users){
                return {statuscode:201};
            }else{
                let currentTime = Date.now() / 1000;
                let tmp = email.split('@');
                if(process.env.ENV != "development"){
                    const domainArray = ["gmail.com","inbox.com","yahoo.com","outlook.com","hotmail.com"];
                    let tmpOne = tmp[1];
                    if(domainArray.includes(tmpOne.toLowerCase())){
                       return {statuscode:203};
                    }
                }

                let tmp2 = tmp[1].split('.');
                let email_domain = tmp2[0];
                let check_company = await companyRepositor.findOne({where : {company_name:email_domain , is_deleted:0}});
                var otpcode = Math.floor(1000 + Math.random() * 9000);
                if(process.env.ENV == "development"){
                  otpcode = 1111;
                }
                /* SENDING OTP STARTS */
                const readFile = util.promisify(fs.readFile);
                let email_template_str  = await readFile('email-template.html','utf8');
                let message = email_template_str.replace("{{OTP}}", otpcode);
                message = message.replace("{{NAME}}", first_name);
                let reciver_address = email;
                let subject =  "Begig OTP";
                if(process.env.ENV != "development"){
                  await mailSendFunction(reciver_address,message,subject,"");
                }
                /* SENDING OTP ENDS */

                var expireToken =  Date.now()/1000 + 1000
                var encryptpassword = await bcrypt.hash(password, 12);
                let userObj = new User();
                userObj.first_name = first_name;
                userObj.last_name = last_name;
                userObj.otp = otpcode.toString();
                userObj.otp_expire_time = expireToken;
                userObj.password = encryptpassword;
                userObj.email = email;
                userObj.role = 1;
                userObj.created_at = currentTime;
                userObj.updated_at = currentTime;
                const savedUser = await userRepository.save(userObj);
                let companyObj = new Company();
                companyObj.company_name = email_domain;
                companyObj.gst_tin = "";
                companyObj.location = "";
                companyObj.created_by = savedUser.id;
                companyObj.updated_by = savedUser.id;
                companyObj.created_at = currentTime;
                companyObj.updated_at = currentTime;

                const savedCompany = await companyRepositor.save(companyObj);
                let employerObj = new Employer();
                employerObj.user = savedUser;
                employerObj.company = savedCompany;
                employerObj.location = "";
                employerObj.type = 0;
                const savedEmployer = await employerRepositor.save(employerObj);

                for(var i in meta){
                  let uMeta = new UserMeta();
                  uMeta.user_id = savedUser.id;
                  uMeta.fl_id = 0;
                  uMeta.user = savedUser;
                  uMeta.meta_key = i;
                  uMeta.meta_value = meta[i];
                  await userMetaRepository.save(uMeta);
                }

                const token = jwt.sign({ id: savedUser.id,freelancer_id :null, employer_id : savedEmployer.id, employer_type : savedEmployer.type,company_id:savedCompany.id, email: userObj.email, role:userObj.role, first_name:userObj.first_name,last_name:userObj.last_name,profile_pic:userObj.profile_pic, steps_completed:userObj.steps_completed,is_login_first_time:1}, process.env.JWT_SECRET);

                return {statuscode:200, token : token};
                //if(!check_company){
                    // let companyObj = new Company();
                    // companyObj.company_name = email_domain;
                    // companyObj.gst_tin = "";
                    // companyObj.location = "";
                    // companyObj.created_by = savedUser.id;
                    // companyObj.updated_by = savedUser.id;
                    // companyObj.created_at = currentTime;
                    // companyObj.updated_at = currentTime;
                    // console.log(companyObj)
                    // const savedCompany = await companyRepositor.save(companyObj);
                    // let employerObj = new Employer();
                    // employerObj.user = savedUser;
                    // employerObj.company = savedCompany;
                    // employerObj.location = "";
                    // employerObj.type = 0;
                    // const savedEmployer = await employerRepositor.save(employerObj);



                    // const token = jwt.sign({ id: savedUser.id,freelancer_id :null, employer_id : savedEmployer.id, employer_type : savedEmployer.type,company_id:savedCompany.id, email: userObj.email, role:userObj.role, first_name:userObj.first_name,last_name:userObj.last_name,profile_pic:userObj.profile_pic, steps_completed:userObj.steps_completed,is_login_first_time:1}, process.env.JWT_SECRET);

                    // return {statuscode:200, token : token};
                // }else{
                //     let employerObj = new Employer();
                //     employerObj.user = savedUser;
                //     employerObj.company = check_company;
                //     employerObj.location = "";
                //     employerObj.type = 1;
                //     const savedEmployer = await employerRepositor.save(employerObj);

                //     const token = jwt.sign({ id: savedUser.id,freelancer_id :null, employer_id : savedEmployer.id, employer_type : savedEmployer.type,company_id:check_company.id, email: userObj.email, role:userObj.role, first_name:userObj.first_name,last_name:userObj.last_name,profile_pic:userObj.profile_pic, steps_completed:userObj.steps_completed,is_login_first_time:1 }, process.env.JWT_SECRET);

                //     return {statuscode:200, token : token};
                // }
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async checkEmployerLogin(data:any): Promise<any> {
        try {
            const { email, password } = data;
            const userRepository = getRepository(User);
            const employerRepository = getRepository(Employer);
            const companyRepository = getRepository(Company);
            const zohoInfoRepo = getRepository(ZohoInfo);
            const users :any = await userRepository.findOne({ where: { email: email,is_deleted:0, role:1 }});
            if(users){
                const validPass = await bcrypt.compare(password, users.password);
                if (validPass){
                    let employer:any = await employerRepository.findOne({ where: { user: users }, relations:['company']});
                    let employer_id:any = employer.id;
                    let employer_type:any = employer.type;
                    if(!employer){
                        employer_id = null;
                        employer_type = null;
                    }
                    const token = jwt.sign({ id: users.id,freelancer_id :null, employer_id : employer_id, employer_type : employer_type,company_id:employer.company.id, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,
                        zoho_user_id:users.zoho_user_id,zoho_enterprise_id:users.zoho_enterprise_id }, process.env.JWT_SECRET);

                    if(users.razorpay_account_number == ""){
                        if(employer_type == 0){
                             /* CREATING RAZORPAY VIRTUAL ACCOUNT STARTS */
                            let check_email_has_virtual_acc = await userRepository.find({ where: { email: users.email, is_deleted:Not(0)}});
                            var razorpay_customer_id = "";
                            var razorpay_account_number = "";
                            var razorpay_bank_account_number = "";
                            var razorpay_ifsc_code = "";
                            var razorpay_bank_account_name = "";
                            var razorpay_bank_name = "";
                            if(check_email_has_virtual_acc.length > 0){
                            for(let  i = 0;i<check_email_has_virtual_acc.length;i++){
                                if(check_email_has_virtual_acc[i].razorpay_customer_id != ""){
                                razorpay_customer_id = check_email_has_virtual_acc[i].razorpay_customer_id;
                                }
                            }
                            }
                            var instance = new Razorpay({ key_id: process.env.RAZORPAY_ID, key_secret: process.env.RAZORPAY_SECRET })
                            if(razorpay_customer_id == ""){
                            let rp_cust = await instance.customers.create({name:users.first_name+" "+users.last_name, email:users.email, contact:"", notes:""});
                            razorpay_customer_id = rp_cust.id;
                            }
                            let rp_virtual_account = await instance.virtualAccounts.create({receivers:{types:["bank_account"]},customer_id:razorpay_customer_id});
                            razorpay_account_number = rp_virtual_account.id;
                            razorpay_bank_account_number = rp_virtual_account.receivers[0].account_number;
                            razorpay_ifsc_code = rp_virtual_account.receivers[0].ifsc;
                            razorpay_bank_account_name = rp_virtual_account.receivers[0].name;
                            razorpay_bank_name = rp_virtual_account.receivers[0].bank_name;
                            if(razorpay_bank_name == null){
                            razorpay_bank_name = "";
                            }
                            userRepository.update({ id:  users.id }, {razorpay_customer_id:razorpay_customer_id,razorpay_account_number:razorpay_account_number,razorpay_bank_account_number:razorpay_bank_account_number,razorpay_ifsc_code:razorpay_ifsc_code,razorpay_bank_account_name:razorpay_bank_account_name,razorpay_bank_name:razorpay_bank_name});
                            /* CREATING RAZORPAY VIRTUAL ACCOUNT ENDS */
                            let obj = JSON.stringify({virtual_account_id:razorpay_account_number});
                            const bigigJobUrl = process.env.Begig_payment_url+'api/v1/payment/create/superadmin/wallet';
                            axios.post(bigigJobUrl, obj ,{
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Authorization': 'Bearer '+token
                                }
                          });

                            /* create wallet of admin on payment service ends */

                        }
                    }

                    if(users.is_login_first_time == 1){
                        userRepository.update({ id:  users.id }, {is_login_first_time:0});
                    }

                    async function createEnterpriseAndemployerAccOnZoho(email:any) {
                        try{
                            let tmp = email.split('@');
                            let tmp2 = tmp[1].split('.');
                            var email_domain = tmp2[0];
                            var Legal_name = email_domain;
                            var Account_Name = email_domain;
                            var Description = "";
                            var Account_Type = "Enterprise";
                            var Shipping_State = "";
                            var Website = "";
                            var Industry = "";
                            var Phone = "";
                            var Billing_Country = "";
                            var Billing_Street = "";
                            var Billing_Code = "";
                            var Shipping_City = "";
                            var Shipping_Country = "";
                            var Shipping_Code = "";
                            var Billing_City = "";
                            var Billing_State = "";
                            var Shipping_Street = "";
                            var GSTN = "";
                            var GST_Treatment = "Unregistered Business";
                            var Place_of_Supply = "HR";
                            var Salutation = "";
                            var Mobile = ""
                            var zohoToken :any = await zohoInfoRepo.findOne();
                            if(employer_type == 0){
                                let createEnterprise = await createZohoEnterpriseAccount(zohoToken.accesstoken,Legal_name,Account_Name,Description,Account_Type,Shipping_State,Website,Industry,Phone,Billing_Country,Billing_Street,Billing_Code,Shipping_City,Shipping_Country,Shipping_Code,Billing_City,Billing_State,Shipping_Street,GSTN,GST_Treatment,Place_of_Supply);

                                let createContactOnZoho = await createZohoContact(zohoToken.accesstoken,createEnterprise.data[0].details.id,users.email,Shipping_Code,Phone,Billing_State,Shipping_Street,Salutation,users.first_name,users.last_name,Account_Type,Shipping_Country,Billing_City,Description,Mobile,Industry);

                                companyRepository.update({ created_by: users.id }, {zoho_enterprise_id:createEnterprise.data[0].details.id});

                                userRepository.update({ id: users.id }, {zoho_enterprise_id:createEnterprise.data[0].details.id,zoho_user_id:createContactOnZoho.data[0].details.id});

                                let token = jwt.sign({ id: users.id,freelancer_id :null, employer_id : employer_id, employer_type : employer_type,company_id:employer.company.id, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,zoho_user_id:createContactOnZoho.data[0].details.id,zoho_enterprise_id:createEnterprise.data[0].details.id }, process.env.JWT_SECRET);

                                return token

                            }else{
                                let createContactOnZoho = await createZohoContact(zohoToken.accesstoken,employer.company.zoho_enterprise_id,users.email,Shipping_Code,Phone,Billing_State,Shipping_Street,Salutation,users.first_name,users.last_name,Account_Type,Shipping_Country,Billing_City,Description,Mobile,Industry);

                                userRepository.update({ id: users.id }, {zoho_enterprise_id:employer.company.zoho_enterprise_id,zoho_user_id:createContactOnZoho.data[0].details.id});

                                let token = jwt.sign({ id: users.id,freelancer_id :null, employer_id : employer_id, employer_type : employer_type,company_id:employer.company.id, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,zoho_user_id:createContactOnZoho.data[0].details.id,zoho_enterprise_id:employer.company.zoho_enterprise_id }, process.env.JWT_SECRET);

                                return token
                            }

                        }catch(error){
                            console.log(error);
                            if(process.env.ENV != "development"){
                                rollbar.error(error);
                            } 
                        }
                    }
                    if(users.status == 0){
                        if(users.zoho_user_id == 0){
                            var data :any = await createEnterpriseAndemployerAccOnZoho(users.email);
                            return { statuscode:202,token:data}
                        }
                        return {statuscode:202,token:token};
                    }else if(users.status == 2){
                         return {statuscode:203};
                    }else if(users.status == 1){
                        if(users.zoho_user_id == 0){
                            var data :any = await createEnterpriseAndemployerAccOnZoho(users.email);
                            return { statuscode:200,token:data}
                        }
                        return { statuscode:200,token:token}
                    }else if(users.status == 4){
                        return { statuscode:206}
                    }
                } else {
                    return {statuscode:201};
                }
            } else {
                return {statuscode:201};
            }
        } catch (err) {
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            console.log(err);
            return {statuscode:500};
        }
    }

    async employerVerifyOtp(data:any,user:any): Promise<any>{
        try {
            const { otp } = data;
            const userRepository = getRepository(User);
            const zohoInfoRepo = getRepository(ZohoInfo);
            const companyRepositor = getRepository(Company);
            const employerRepository = getRepository(Employer);
            var time = Date.now()/1000;
            var users :any = await userRepository.findOne({ where: { id: user.id, otp_expire_time: MoreThanOrEqual(time), otp: otp }});
            if(!users){
                return {statuscode:201};
            }else{
                let tmp = users.email.split('@');
                let tmp2 = tmp[1].split('.');
                var email_domain = tmp2[0];
                var employer:any = await employerRepository.findOne({ where: { user: users.id }, relations:['company']});
                var employer_id:any = employer.id;
                var employer_type:any = employer.type;
                if(!employer){
                    employer_id = null;
                    employer_type = null;
                }
                await userRepository.update({ id:  user.id }, {otp:"", otp_expire_time:0,status: 1});
                var token = jwt.sign({ id: users.id,freelancer_id :null, employer_id : employer_id, employer_type : employer_type,company_id:employer.company.id, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,zoho_user_id:null,zoho_enterprise_id:null }, process.env.JWT_SECRET);
                try{
                    var Legal_name = email_domain;
                    var Account_Name = email_domain;
                    var Description = "";
                    var Account_Type = "Enterprise";
                    var Shipping_State = "";
                    var Website = "";
                    var Industry = "";
                    var Phone = "";
                    var Billing_Country = "";
                    var Billing_Street = "";
                    var Billing_Code = "";
                    var Shipping_City = "";
                    var Shipping_Country = "";
                    var Shipping_Code = "";
                    var Billing_City = "";
                    var Billing_State = "";
                    var Shipping_Street = "";
                    var GSTN = "";
                    var GST_Treatment = "Unregistered Business";
                    var Place_of_Supply = "HR";
                    var Salutation = "";
                    var Mobile = ""

                    var zohoToken :any = await zohoInfoRepo.findOne();

                    var createEnterprise = await createZohoEnterpriseAccount(zohoToken.accesstoken,Legal_name,Account_Name,Description,Account_Type,Shipping_State,Website,Industry,Phone,Billing_Country,Billing_Street,Billing_Code,Shipping_City,Shipping_Country,Shipping_Code,Billing_City,Billing_State,Shipping_Street,GSTN,GST_Treatment,Place_of_Supply);

                    var createContactOnZoho = await createZohoContact(zohoToken.accesstoken,createEnterprise.data[0].details.id,users.email,Shipping_Code,Phone,Billing_State,Shipping_Street,Salutation,users.first_name,users.last_name,Account_Type,Shipping_Country,Billing_City,Description,Mobile,Industry);

                    companyRepositor.update({ created_by: users.id }, {zoho_enterprise_id:createEnterprise.data[0].details.id});

                    userRepository.update({ id: users.id }, {zoho_enterprise_id:createEnterprise.data[0].details.id,zoho_user_id:createContactOnZoho.data[0].details.id});

                    token = jwt.sign({ id: users.id,freelancer_id :null, employer_id : employer_id, employer_type : employer_type,company_id:employer.company.id, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,zoho_user_id:createContactOnZoho.data[0].details.id,zoho_enterprise_id:createEnterprise.data[0].details.id }, process.env.JWT_SECRET);



                }catch(error){console.log("abcd");
                    console.log(error);
                    if(process.env.ENV != "development"){
                        rollbar.error(error);
                    } 
                }


                /* create wallet of admin on payment service starts */
                // virtual account should be create here
                    /* CREATING RAZORPAY VIRTUAL ACCOUNT STARTS */
                    let check_email_has_virtual_acc = await userRepository.find({ where: { email: users.email, is_deleted:Not(0)}});
                    var razorpay_customer_id = "";
                    var razorpay_account_number = "";
                    var razorpay_bank_account_number = "";
                    var razorpay_ifsc_code = "";
                    var razorpay_bank_account_name = "";
                    var razorpay_bank_name = "";
                    if(check_email_has_virtual_acc.length > 0){
                      for(let  i = 0;i<check_email_has_virtual_acc.length;i++){
                        if(check_email_has_virtual_acc[i].razorpay_customer_id != ""){
                          razorpay_customer_id = check_email_has_virtual_acc[i].razorpay_customer_id;
                        }
                      }
                    }
                    var instance = new Razorpay({ key_id: process.env.RAZORPAY_ID, key_secret: process.env.RAZORPAY_SECRET })
                    if(razorpay_customer_id == ""){
                      let rp_cust = await instance.customers.create({name:users.first_name+" "+users.last_name, email:users.email, contact:"", notes:""});
                      razorpay_customer_id = rp_cust.id;
                    }
                    let rp_virtual_account = await instance.virtualAccounts.create({receivers:{types:["bank_account"]},customer_id:razorpay_customer_id});
                    razorpay_account_number = rp_virtual_account.id;
                    razorpay_bank_account_number = rp_virtual_account.receivers[0].account_number;
                    razorpay_ifsc_code = rp_virtual_account.receivers[0].ifsc;
                    razorpay_bank_account_name = rp_virtual_account.receivers[0].name;
                    razorpay_bank_name = rp_virtual_account.receivers[0].bank_name;
                    if(razorpay_bank_name == null){
                      razorpay_bank_name = "";
                    }
                    await userRepository.update({ id:  users.id }, {razorpay_customer_id:razorpay_customer_id,razorpay_account_number:razorpay_account_number,razorpay_bank_account_number:razorpay_bank_account_number,razorpay_ifsc_code:razorpay_ifsc_code,razorpay_bank_account_name:razorpay_bank_account_name,razorpay_bank_name:razorpay_bank_name});

                /* CREATING RAZORPAY VIRTUAL ACCOUNT ENDS */
                let obj = JSON.stringify({virtual_account_id:razorpay_account_number});
                const bigigJobUrl = process.env.Begig_payment_url+'api/v1/payment/create/superadmin/wallet';
                try{
                  axios.post(bigigJobUrl, obj ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer '+token
                    }
                 });
                }catch(e){
                    console.log(e);
                    if(process.env.ENV != "development"){
                       rollbar.error(e);
                    } 
                }


                /* create wallet of admin on payment service ends */
                return {statuscode:200, token:token};
            }

        } catch (err) {
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async employerResendOtp(user:any): Promise<any> {
        try {
            const userRepository = getRepository(User);
            var otpcode = Math.floor(1000 + Math.random() * 9000);
            if(process.env.ENV == "development"){
              otpcode = 1111;
            }
            var expireToken =  Date.now()/1000 + 1000;

            /* SENDING OTP STARTS */
            const readFile = util.promisify(fs.readFile);
            let email_template_str  = await readFile('email-template.html','utf8');
            let message = email_template_str.replace("{{OTP}}", otpcode);
            message = message.replace("{{NAME}}", user.first_name);
            let reciver_address = user.email;
            let subject =  "Begig OTP";
            if(process.env.ENV != "development"){
              await mailSendFunction(reciver_address,message,subject,"");
            }
            /* SENDING OTP ENDS */
            const updatetoken =  await userRepository.update(Number(user.id), {otp:otpcode.toString(), otp_expire_time:expireToken});
            return {statuscode:200};
        } catch (err) {
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async freelancerSignup(model:any): Promise<any> {

        try {
            const { first_name,last_name,role, exprience, password, email,meta } = model;
            const userRepository = getRepository(User);
            const userMetaRepository = getRepository(UserMeta);
            const users = await userRepository.findOne({ where: { email:email, is_deleted:0}});
            if(users){
                return {statuscode:201};
            }

            let currentTime = Date.now() / 1000;
            var otpcode = Math.floor(1000 + Math.random() * 9000);
            if(process.env.ENV == "development"){
              otpcode = 1111;
            }

            // SENDING OTP STARTS
            const readFile = util.promisify(fs.readFile);
            let email_template_str  = await readFile('email-template.html','utf8');
            let message = email_template_str.replace("{{OTP}}", otpcode);
            message = message.replace("{{NAME}}", first_name);
            let reciver_address = email;
            let subject =  "Begig OTP";
            if(process.env.ENV != "development"){
              await mailSendFunction(reciver_address,message,subject,"");
            }
            // SENDING OTP ENDS

            var expireToken =  Date.now()/1000 + 1000
            var encryptpassword = await bcrypt.hash(password, 12)

            const usersd = new User();
                usersd.first_name = first_name;
                usersd.last_name = last_name;
                usersd.otp = otpcode.toString();
                usersd.otp_expire_time = expireToken;
                usersd.password = encryptpassword;
                usersd.email = email;
                usersd.steps_completed = 0;
                usersd.role = 0;
                usersd.created_at = currentTime;
                usersd.updated_at = currentTime;
            const savedUser = await userRepository.save(usersd);

            const freelancerRepository = getRepository(Freelancer);

            const freelancer = new Freelancer();

                freelancer.user = usersd;
                freelancer.about_me = "";
                freelancer.exprience_slots = exprience;

            const savedfreelancer = await freelancerRepository.save(freelancer);

            for(var i in meta){
              let uMeta = new UserMeta();
              uMeta.user_id = savedUser.id;
              uMeta.fl_id = savedfreelancer.id;
              uMeta.user = savedUser;
              uMeta.meta_key = i;
              uMeta.meta_value = meta[i];
              await userMetaRepository.save(uMeta);
            }

            const token = jwt.sign({ id: savedUser.id,freelancer_id :savedfreelancer.id, employer_id : null, employer_type : null,company_id:null, email: usersd.email, role:usersd.role, first_name:usersd.first_name,last_name:usersd.last_name,profile_pic:usersd.profile_pic, steps_completed:usersd.steps_completed,is_login_first_time:1 }, process.env.JWT_SECRET);

            return {statuscode:200, token : token};
        } catch (err) {
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }

    }

    async freelancerLogin(model:any): Promise<any> {
        try {
            const { email, password } = model;
            const userRepository = getRepository(User);
            const freelancerRepository = getRepository(Freelancer);
            const zohoInfoRepo = getRepository(ZohoInfo);
            const users :any = await userRepository.findOne({ where: { email: email,is_deleted:0,role:0}});
            if(users){
                if(!users.socail_id){
                    const validPass = await bcrypt.compare(password, users.password);
                    if (validPass){
                        let freelancer:any = await freelancerRepository.findOne({ where: { user: users }});
                        let freelancer_id:any = freelancer.id;
                        if(!freelancer){
                            freelancer_id = null;
                        }
                        var token = jwt.sign({ id: users.id,freelancer_id :freelancer_id, employer_id : null, employer_type : null,company_id:null, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,
                            zoho_user_id:users.zoho_user_id }, process.env.JWT_SECRET);
                        if(users.is_login_first_time == 1){
                            userRepository.update({ id:  users.id }, {is_login_first_time:0});
                        }
                        async function createFreelancerAccountOnZoho() {
                            try{
                                var Email = users.email;
                                var Category = "freelancer";
                                var Description = freelancer.about_me;
                                var Vendor_Name = users.first_name+ ' ' +users.last_name;
                                var Website = "";
                                var City = freelancer.city;
                                var Phone = users.mobile_no;
                                var State = "";
                                var GL_Account = "";
                                var Street = "";
                                var Country = freelancer.country;
                                var Zip_Code = "";
                                var GSTN = "";
                                var Place_of_Supply = "HR";
                                var zohoToken :any = await zohoInfoRepo.findOne();
                                var createFl :any = await createZohoFreelancer(zohoToken.accesstoken,Email,Category,Description,Vendor_Name,Website,City,Phone,State,GL_Account,Street,Country,Zip_Code,GSTN,Place_of_Supply);

                                userRepository.update({ id: users.id }, {zoho_user_id:createFl.data[0].details.id});

                                var token = jwt.sign({ id: users.id,freelancer_id :freelancer_id, employer_id : null, employer_type : null,company_id:null, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,
                                    zoho_user_id:createFl.data[0].details.id }, process.env.JWT_SECRET);
                                return token
                            }catch(error){
                                console.log(error);
                                if(process.env.ENV != "development"){
                                    rollbar.error(error);
                                } 
                            }
                        }
                        if(users.status == 0){
                            if(users.zoho_user_id == 0){
                                var data :any = await createFreelancerAccountOnZoho();
                                return { statuscode:202,token:data}
                            }
                            return {statuscode:202,token:token};
                        }else if(users.status == 2){
                            return {statuscode:203};
                        }else if(users.status == 3){
                            if(users.zoho_user_id == 0){
                                var data :any = await createFreelancerAccountOnZoho();
                                return { statuscode:207,token:data}
                            }
                            return {statuscode:207,token:token};
                        }else if(users.status == 1){
                            if(users.zoho_user_id == 0){
                                var data :any = await createFreelancerAccountOnZoho();
                                return { statuscode:200,token:data}
                            }
                            return { statuscode:200,token:token};
                        }else if(users.status == 4){
                            return { statuscode:206}
                        }
                    } else {
                        return {statuscode:201};
                    }
                }else{
                    return {statuscode:406};
                }
            }else{
                return {statuscode:201};
            }
        } catch (err) {
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }


    async socialLogin(body:any): Promise<any>{
        try{
            const userRepository = getRepository(User);
            const freelancerRepository = getRepository(Freelancer);
            const zohoInfoRepo = getRepository(ZohoInfo);
            let chkSocialid :any= await userRepository.findOne({ where: { socail_id: body.social_id,is_deleted:0}});
            console.log(chkSocialid);
            if(!chkSocialid){
              let chkEmail = await userRepository.findOne({ where: { email: body.email,is_deleted:0}});
              if(chkEmail){
                return {statuscode:201}
              }else{
                return {statuscode:404};
              }
            }else{ // login as fl
                let freelancer:any = await freelancerRepository.findOne({ where: { user: chkSocialid }});
                let freelancer_id:any = freelancer.id;
                if(!freelancer){
                    freelancer_id = null;
                }
                const token = jwt.sign({ id: chkSocialid.id,freelancer_id :freelancer_id, employer_id : null, employer_type : null,company_id:null, email: chkSocialid.email, role:chkSocialid.role, first_name:chkSocialid.first_name, last_name:chkSocialid.last_name,profile_pic:chkSocialid.profile_pic, steps_completed:chkSocialid.steps_completed,is_login_first_time:chkSocialid.is_login_first_time,zoho_user_id:chkSocialid.zoho_user_id }, process.env.JWT_SECRET);
                if(chkSocialid.is_login_first_time == 1){
                    userRepository.update({ id:  chkSocialid.id }, {is_login_first_time:0});
                }
                async function createFreelancerAccountOnZoho() {
                    try{
                        var Email = chkSocialid.email;
                        var Category = "freelancer";
                        var Description = freelancer.about_me;
                        var Vendor_Name = chkSocialid.first_name+ ' ' +chkSocialid.first_name;
                        var Website = "";
                        var City = freelancer.city;
                        var Phone = chkSocialid.mobile_no;
                        var State = "";
                        var GL_Account = "";
                        var Street = "";
                        var Country = freelancer.country;
                        var Zip_Code = "";
                        var GSTN = "";
                        var Place_of_Supply = "HR";
                        var zohoToken :any = await zohoInfoRepo.findOne();
                        var createFl :any = await createZohoFreelancer(zohoToken.accesstoken,Email,Category,Description,Vendor_Name,Website,City,Phone,State,GL_Account,Street,Country,Zip_Code,GSTN,Place_of_Supply);

                        userRepository.update({ id: chkSocialid.id }, {zoho_user_id:createFl.data[0].details.id});

                        var token = jwt.sign({ id: chkSocialid.id,freelancer_id :freelancer_id, employer_id : null, employer_type : null,company_id:null, email: chkSocialid.email, role:chkSocialid.role, first_name:chkSocialid.first_name, last_name:chkSocialid.last_name,profile_pic:chkSocialid.profile_pic, steps_completed:chkSocialid.steps_completed,is_login_first_time:chkSocialid.is_login_first_time,
                            zoho_user_id:createFl.data[0].details.id }, process.env.JWT_SECRET);
                        return token
                    }catch(error){
                        console.log(error);
                        if(process.env.ENV != "development"){
                            rollbar.error(error);
                        } 
                    }
                }
                if(chkSocialid.status == 2){
                    return {statuscode:203};
                }else if(chkSocialid.status == 3){
                    if(chkSocialid.zoho_user_id == 0){
                        var data :any = await createFreelancerAccountOnZoho();
                        return { statuscode:207,token:data}
                    }
                    return {statuscode:207,token:token};
                }else if(chkSocialid.status == 1){
                    if(chkSocialid.zoho_user_id == 0){
                        var data :any = await createFreelancerAccountOnZoho();
                        return { statuscode:200,token:data}
                    }
                    return { statuscode:200,token:token}
                }else if(chkSocialid.status == 4){
                    return { statuscode:206}
                }
            }
        }catch(err){console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async socialSignup(body:any): Promise<any> {
        try {
            const userRepository = getRepository(User);
            const userMetaRepository = getRepository(UserMeta);
            const zohoInfoRepo = getRepository(ZohoInfo);
            let meta = body.meta;
            const usersd = new User();
            let currentTime = Date.now() / 1000;
            usersd.first_name = body.first_name;
            usersd.last_name = body.last_name;
            usersd.social_id_type = body.social_id_type;
            usersd.socail_id = body.socail_id;
            usersd.otp = '0000';
            usersd.otp_expire_time = 0;
            usersd.password = '';
            usersd.email = body.email;
            usersd.steps_completed = 0;
            usersd.status = 3;
            usersd.role = 0;
            usersd.created_at = currentTime;
            usersd.updated_at = currentTime;
            const savedUser = await userRepository.save(usersd);

            const freelancerRepository = getRepository(Freelancer);

            const freelancer = new Freelancer();

            freelancer.user =  usersd;
            freelancer.exprience_slots = body.exprience;
            freelancer.about_me = "";

            const savedfreelancer = await freelancerRepository.save(freelancer);

            for(var i in meta){
              let uMeta = new UserMeta();
              uMeta.user_id = savedUser.id;
              uMeta.fl_id = savedfreelancer.id;
              uMeta.user = savedUser;
              uMeta.meta_key = i;
              uMeta.meta_value = meta[i];
              await userMetaRepository.save(uMeta);
            }

            var token = jwt.sign({ id: savedUser.id,freelancer_id :savedfreelancer.id, employer_id : null, employer_type : null,company_id:null, email: usersd.email, role:usersd.role, first_name:usersd.first_name,last_name:usersd.last_name,profile_pic:usersd.profile_pic, steps_completed:usersd.steps_completed,is_login_first_time:1,zoho_user_id:usersd.zoho_user_id }, process.env.JWT_SECRET);

            try{
                var Email = usersd.email;
                var Category = "freelancer";
                var Description = "";
                var Vendor_Name = usersd.first_name+ ' ' +usersd.last_name;
                var Website = "";
                var City = "";
                var Phone = "";
                var State = "";
                var GL_Account = "";
                var Street = "";
                var Country = "";
                var Zip_Code = "";
                var GSTN = "";
                var Place_of_Supply = "HR";
                var zohoToken :any = await zohoInfoRepo.findOne();
                var createFl :any = await createZohoFreelancer(zohoToken.accesstoken,Email,Category,Description,Vendor_Name,Website,City,Phone,State,GL_Account,Street,Country,Zip_Code,GSTN,Place_of_Supply);
                userRepository.update({ id: usersd.id }, {zoho_user_id:createFl.data[0].details.id});
                token = jwt.sign({ id: savedUser.id,freelancer_id :savedfreelancer.id, employer_id : null, employer_type : null,company_id:null, email: usersd.email, role:usersd.role, first_name:usersd.first_name,last_name:usersd.last_name,profile_pic:usersd.profile_pic, steps_completed:usersd.steps_completed,is_login_first_time:1,zoho_user_id:createFl.data[0].details.id }, process.env.JWT_SECRET);

            }catch(error){
                console.log(error);
                if(process.env.ENV != "development"){
                    rollbar.error(error);
                } 
            }

            return {statuscode:207, token : token};
        } catch (err) {console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async freelancerVerifyOtp(model:any, user:any): Promise<any> {
        try {
            const { otp } = model;
            const userRepository = getRepository(User);
            const zohoInfoRepo = getRepository(ZohoInfo);
            const freelancerRepository = getRepository(Freelancer);
            var time = Date.now()/1000;
            var users :any= await userRepository.findOne({ where: { id: user.id, otp_expire_time: MoreThanOrEqual(time), otp: otp }});
            if(!users){
                return {statuscode:201};
            } else {
                let freelancer:any = await freelancerRepository.findOne({ where: { user: users }});
                let freelancer_id:any = freelancer.id;
                if(!freelancer){
                    freelancer_id = null;
                }
                await userRepository.update({ id:  user.id }, {otp:"", otp_expire_time:0,status:  3});
                try{
                    var Email = users.email;
                    var Category = "freelancer";
                    var Description = "";
                    var Vendor_Name = users.first_name+ ' ' +users.last_name;
                    var Website = "";
                    var City = "";
                    var Phone = "";
                    var State = "";
                    var GL_Account = "";
                    var Street = "";
                    var Country = "";
                    var Zip_Code = "";
                    var GSTN = "";
                    var Place_of_Supply = "HR";
                    var zohoToken :any = await zohoInfoRepo.findOne();
                    var createFl :any = await createZohoFreelancer(zohoToken.accesstoken,Email,Category,Description,Vendor_Name,Website,City,Phone,State,GL_Account,Street,Country,Zip_Code,GSTN,Place_of_Supply);
                    userRepository.update({ id: user.id }, {zoho_user_id:createFl.data[0].details.id});
                    let token = jwt.sign({ id: users.id,freelancer_id :freelancer_id, employer_id : null, employer_type : null,company_id:null, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,zoho_user_id:createFl.data[0].details.id }, process.env.JWT_SECRET);
                    return {statuscode:200, token:token};
                }catch(error){
                    console.log(error);
                    if(process.env.ENV != "development"){
                        rollbar.error(error);
                    } 
                }
                let token = jwt.sign({ id: users.id,freelancer_id :freelancer_id, employer_id : null, employer_type : null,company_id:null, email: users.email, role:users.role, first_name:users.first_name, last_name:users.last_name,profile_pic:users.profile_pic, steps_completed:users.steps_completed,is_login_first_time:users.is_login_first_time,zoho_user_id:null }, process.env.JWT_SECRET);
                return {statuscode:200,token:token};
            }
        } catch (err) {
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async freelancerResendOtp(user:any): Promise<any> {
        try {
            const userRepository = getRepository(User);
            var otpcode = Math.floor(1000 + Math.random() * 9000);
            if(process.env.ENV == "development"){
              otpcode = 1111;
            }
            var expireToken =  Date.now()/1000 + 1000;
            /* SENDING OTP STARTS */
            const readFile = util.promisify(fs.readFile);
            let email_template_str  = await readFile('email-template.html','utf8');
            let message = email_template_str.replace("{{OTP}}", otpcode);
            message = message.replace("{{NAME}}", user.first_name);
            let reciver_address = user.email;
            let subject =  "Begig OTP";
            if(process.env.ENV != "development"){
              await mailSendFunction(reciver_address,message,subject,"");
            }
            /* SENDING OTP ENDS */
            const updatetoken =  await userRepository.update(Number(user.id), {otp:otpcode.toString(), otp_expire_time:expireToken});
            return {statuscode:200};
        } catch (err) {
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async getallEducationQualification(): Promise<any> {
        try {
            const education_qualificationsRepository = getRepository(EducationQualifications);
            const education_qualifications = await education_qualificationsRepository.find({ select: ["id", "title"] });
            return {statuscode:200,data:education_qualifications};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }         
            return {statuscode:500};
        }
    }

    async basicDetails(body:any, user:any): Promise<any> {
        try {
            const freelancerRepository = getRepository(Freelancer);
            const userRepository = getRepository(User);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var basicDetails = {
                country: body.country,
                city: body.city,
                resume_url:body.resume_url,
                about_me:body.about_me,
                freelancing_type:body.freelancing_type,
                rate_per_hour:body.rate_per_hour,
                availibity:body.availibity,
                english_proficiency:body.english_proficiency
            }

            freelancerRepository.update({ id:  user.freelancer_id }, basicDetails);
            userRepository.update({ id:  user.id }, {steps_completed:1,mobile_no:body.mobile_number});
            try{
                var updateData = {
                    Country: body.country,
                    City: body.city,
                    Description:body.about_me,
                    Phone:body.mobile_number
                }
                var zohoData :any = await zohoInfoRepo.findOne();
                updateZohoFreelancer(zohoData.accesstoken,user.zoho_user_id,updateData);
            }catch(error){
                if(process.env.ENV != "development"){
                    rollbar.error(error);
                }  
                console.log(error);
            }
            return {statuscode:200};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async employerUpdateAddress(body:any, user:any): Promise<any> {
        try {
            const employerRepository = getRepository(Employer);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var addressInfo = {
                complete_address: body.complete_address,
                pin_code: body.pin_code,
                city: body.city,
                state: body.state,
                tax_residence: body.tax_residence,
                country: body.country
            }
            await employerRepository.update({ id:  user.id }, addressInfo);
            try{
                var updateData = {
                    Mailing_Zip: body.pin_code,
                    Mailing_City: body.city,
                    Mailing_Country:body.country,
                    Mailing_State:body.state,
                    Mailing_Street: body.complete_address,
                }
                var zohoData:any = await zohoInfoRepo.findOne();
                updateZohoContact(zohoData.accesstoken,user.zoho_user_id,updateData);
            }catch(error){
                if(process.env.ENV != "development"){
                    rollbar.error(error);
                } 
                console.log(error);
            }
            return {statuscode:200};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async changeMobileNumber(body:any, user:any): Promise<any> {
        try {
            const userRepository = getRepository(User);
            const users :any = await userRepository.findOne({ where: {id:user.id, mobile_no: body.current_mobile_no,is_deleted:0}});
            if(users){
                const userData :any = await userRepository.findOne({ where: {mobile_no: body.new_mobile_no}});
                if(userData){
                    return {statuscode:202};
                }else{
                    const updatePassword = await userRepository.update({ id:  user.id },{mobile_no:body.new_mobile_no});
                    if(updatePassword.affected){
                        var otpcode = Math.floor(1000 + Math.random() * 9000);
                        otpcode = 1111;
                        var expireToken =  Date.now()/1000 + 1000;
                        const updatetoken =  await userRepository.update({ id:  user.id }, {otp:otpcode.toString(), otp_expire_time:expireToken});
                        return {statuscode:200};
                    }else{
                        return {statuscode:203};
                    }
                }
            }else{
                return {statuscode:201};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async changePassword(data:any, user:any): Promise<any> {
        try {
            const { current_password, new_password } = data;
            const userRepository = getRepository(User);
            const users :any = await userRepository.findOne({ where: { id: user.id,is_deleted:0}});
            if(users){
                const validPass = await bcrypt.compare(current_password, users.password);
                if (validPass){
                    var encryptpassword = await bcrypt.hash(new_password, 12);
                    const updatePassword = await userRepository.update({ id:  user.id },{password:encryptpassword});
                    if(updatePassword.affected){
                        return {statuscode:200};
                    }else{
                        return {statuscode:203};
                    }
                } else {
                    return {statuscode:202};
                }
            }else {
                return {statuscode:201};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async addExprience(body:any, user:any): Promise<any> {
        let Freelancer_experience_Repository = getRepository(FreelancerExperience);
        let currentTime = Date.now() / 1000;
        try {
            let chk = await Freelancer_experience_Repository.find({freelancerId: user.freelancer_id});
            if(chk){
                await Freelancer_experience_Repository.delete({freelancerId: user.freelancer_id});
            }
            for (let i = 0; i < body.expriences.length; i++) {
                const exprience = new FreelancerExperience();
                    exprience.freelancerId = user.freelancer_id;
                    exprience.company_name = body.expriences[i].company_name;
                    exprience.designation = body.expriences[i].designation;
                    exprience.total_exp_in_month = body.expriences[i].total_exp_in_month;
                    exprience.job_type = body.expriences[i].job_type;
                    exprience.description = body.expriences[i].description;
                    exprience.start_date = body.expriences[i].start_date;
                    exprience.end_date = body.expriences[i].end_date;
                    exprience.present_company = body.expriences[i].present_company;
                    exprience.created_at = currentTime;
                    exprience.updated_at = currentTime;
                const saveExprience = await Freelancer_experience_Repository.save(exprience);
            }
            const userRepository = getRepository(User);
            const updateSteps =  await userRepository.update({ id:  user.id }, {steps_completed:3});
            return {statuscode:200};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }

    }

    async addEducation(body:any, user:any): Promise<any> {
        try {
            const Freelancers_educations_Repository = getRepository(FreelancersEducations);
            let chk = await Freelancers_educations_Repository.find({freelancerId: user.freelancer_id});
            if(chk){
                await Freelancers_educations_Repository.delete({freelancerId: user.freelancer_id});
            }
            let currentTime = Date.now() / 1000;
            for (let i = 0; i < body.educations.length; i++) {
                const education = new FreelancersEducations();
                    education.freelancerId = user.freelancer_id;
                    education.educationQualificationsId = body.educations[i].educationQualificationsId;
                    education.institution_name = body.educations[i].institution_name;
                    education.specializaion = body.educations[i].specializaion;
                    education.start_date = body.educations[i].start_date;
                    education.end_date = body.educations[i].end_date;
                    education.currently_studying = body.educations[i].currently_studying;
                    education.created_at = currentTime;
                    education.updated_at = currentTime;
                const saveEducation = await Freelancers_educations_Repository.save(education);
            }
            const userRepository = getRepository(User);
            const updateSteps =  await userRepository.update({ id:  user.id }, {steps_completed:4});
            return {statuscode:200};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async addSkills(body:any, user:any): Promise<any> {
        try {
            const Freelancers_skills_Repository = getRepository(FreelancersSkills);
            let chk :any= await Freelancers_skills_Repository.find({freelancer: user.freelancer_id});
            if(chk){
                await Freelancers_skills_Repository.delete({freelancer: user.freelancer_id});
            }
            let currentTime = Date.now() / 1000;
            for(let i=0;i<body.skills.length;i++){
                const skills = new FreelancersSkills();
                    skills.freelancer = user.freelancer_id;
                    skills.skill = body.skills[i].skill;
                    skills.experience_in_month = body.skills[i].experience_in_month;
                    skills.created_at = currentTime;
                    skills.updated_at = currentTime;
                    skills.created_by = user.id;
                const saveSkills = await Freelancers_skills_Repository.save(skills);
            }

            const userRepository = getRepository(User);
            const updateSteps =  await userRepository.update({ id:  user.id }, {steps_completed:2});
            return {statuscode:200};
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async addfreelancerAccomplishments(body:any, user:any): Promise<any> {
        try {
            const Freelancers_FreelancerAccomplishments = getRepository(FreelancerAccomplishments);
            const freelancerRepository = getRepository(Freelancer);
            let currentTime = Date.now() / 1000;
            if(!body.github_url){
                body.github_url = "";
            }
            if(!body.linkedin_url){
                body.linkedin_url = "";
            }
            if(!body.other_url){
                body.other_url = "";
            }
            await freelancerRepository.update({ id:  user.freelancer_id }, { github_url:body.github_url, linkedin_url: body.linkedin_url, other_url:body.other_url });
            let chk = await Freelancers_FreelancerAccomplishments.find({freelancerId: user.freelancer_id});
            if(chk){
                await Freelancers_FreelancerAccomplishments.delete({freelancerId: user.freelancer_id});
            }
            for (let i = 0; i < body.license.length; i++) {
                const accomplishments = new FreelancerAccomplishments();
                    accomplishments.freelancerId = user.freelancer_id;
                    accomplishments.name_of_license = body.license[i].name_of_license;
                    accomplishments.organisation_name = body.license[i].organisation_name;
                    accomplishments.url = body.license[i].url;
                    accomplishments.start_date = body.license[i].start_date;
                    accomplishments.end_date = body.license[i].end_date;
                    accomplishments.license_staus = body.license[i].license_staus;
                    accomplishments.created_at = currentTime;
                    accomplishments.updated_at = currentTime;
                const saveccomplishments = await Freelancers_FreelancerAccomplishments.save(accomplishments);
            }
            const userRepository = getRepository(User);
            const updateSteps =  await userRepository.update({ id: user.id }, {steps_completed:5, status:1});
            return {statuscode:200};
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async userDataById(user:any,id:any): Promise<any> {
        try {
            const userData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id =:id",{id: id })
            .getMany();
            if(userData){
                return {statuscode:200,data:userData};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getUserForFrontPageByid(user:any,id:any): Promise<any> {
        try {
            const userData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id =:id",{id: id })
            .getMany();
            if(userData){
                return {statuscode:200,data:userData};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async sendEmailToAdminForNewBid(body:any, user:any): Promise<any> {
      try {
          let created_by = body.created_by;
          let gig_name = body.gig_name;
          let gig_id = body.gig_id;
          let project_id = body.project_id;
          let fl_id = body.fl_id;
          const userRepository = getRepository(User);
          const userData:any = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id = "+created_by)
            .getOne();
          const fl_data:any = await getRepository(Freelancer)
            .createQueryBuilder("freelancer")
            .leftJoinAndSelect("freelancer.user", "user")
            .where("freelancer.id = "+fl_id)
            .getOne();
          if(userData){
            let reciver_address = userData.email;
            let  message =  'Hi '+userData.company.company_name+', \n\n ' +
            'We got a quick update for you!\n\n The gig you posted has a got a new bid from '+fl_data.user.first_name+' '+fl_data.user.last_name +
            ' \n\n Check out the bid here <a href="'+ process.env.FORGET_PASSWORD_URL + '/home/hire-freelancer/'+project_id+'/'+gig_id+'">'+ process.env.FORGET_PASSWORD_URL + '/home/hire-freelancer/'+project_id+'/'+gig_id+'</a>'  +
            ' \n\n We hope it’s a match!. \n\n\n\n Best Wishes, \n Team BeGig';
            let  subject =  gig_name+": A new bid is in!";
            var sentMail = await mailSendFunction(reciver_address,message,subject,"support@begig.io");
            return {statuscode:200,data:userData};
          } else {
            return {statuscode:201};
          }
      }
      catch (error) {
        if(process.env.ENV != "development"){
            rollbar.error(error);
        } 
          console.log("error user", error )
          return {statuscode:500};
      }
    }

    async multiUserDataByIds(body:any, user:any): Promise<any> {
        try {
            const userData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id IN (:...ids)",{ ids: body.id })
            .getMany();
            if(userData){
                return {statuscode:200,data:userData};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log("error user", error )
            return {statuscode:500};
        }
    }

    async getMultiUserForFrontPageByid(body:any, user:any): Promise<any> {
        try {
            const userData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id IN (:...ids)",{ ids: body.id })
            .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
            .getMany();
            if(userData){
                return {statuscode:200,data:userData};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log("error user", error )
            return {statuscode:500};
        }
    }

    async getEmployerAddress(body:any, user:any): Promise<any> {
        try {
            const employerRepository = getRepository(Employer);
            const employerData = await employerRepository.find({where: { id: user.id }, select: ["complete_address","pin_code", "city", "state", "country"] });
            if(employerData.length > 0){
                return {statuscode:200,data:employerData};
            } else {
                return {statuscode:201};
            }

        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async resumeParsing(user:any,body:any): Promise<any> {
        try {
            const parsUrl = process.env.RESUME_PARSING_URL +'parser';
            const json = JSON.stringify({"s3_link": body.s3_link});
            const res:any = await axios.post(parsUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if(res.data){
                return {statuscode:200,data:res.data};
            }else{
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async jdParsing(body:any): Promise<any> {
        try {
            const parsUrl = process.env.JD_PARSING_URL + 'parser/';
            const json = JSON.stringify({"s3_link": body.s3_link});
            const res:any = await axios.post(parsUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if(res.data){
                return {statuscode:200,data:res.data};
            }else{
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async recommendedFreelancers(user:any,body:any): Promise<any> {
        try {
           if(process.env.ENV != "development" ){
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL + 'recommended_freelancers/';
            }else {
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL_DEV + 'recommended_freelancers/';
            }
            var json = "";
            var obj :any = {
                gigId:body.gigId,
                pageNumber:body.pageNumber,
                search_key:body.search_key
            };
            if(body.order_by){
                obj.order_type = body.order_type;
                obj.order_by = body.order_by;
            }
            if(body.payment_type || body.payment_type == 0){
                obj.payment_type = body.payment_type;
            }
            if(body.pay_per_hour){
                obj.pay_per_hour = body.pay_per_hour;
            }
            if(body.hrs_per_week || body.hrs_per_week == 0){
                obj.hrs_per_week = body.hrs_per_week;
            }
            if(body.experience){
                obj.experience = body.experience;
            }
            json = JSON.stringify(obj);
            const response:any = await axios.post(parsUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if(response.status == 200){
                return {statuscode:200,data: response.data};
            }else if(response.status == 201){
                return {statuscode:201};
            }else{
                return {statuscode:500};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async recommendedGigs(user:any,body:any): Promise<any> {
        try {
           if(process.env.ENV != "development" ){
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL + 'recommended_gigs/';
            }else {
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL_DEV + 'recommended_gigs/';
            }
            var json = "";
            var obj :any = {
                flId:user.freelancer_id,
                pageNumber:body.pageNumber
            };
            if(body.order_by){
                obj.order_type = body.order_type;
                obj.order_by = body.order_by;
            }
            if(body.search_key){
                obj.search_key = body.search_key;
            }
            if(body.payment_type || body.payment_type == 0){
                obj.payment_type = body.payment_type;
            }
            if(body.pay_per_hour){
                obj.pay_per_hour = body.pay_per_hour;
            }
            if(body.gig_del_time){
                obj.gig_del_time = body.gig_del_time;
            }
            if(body.hrs_per_week || body.hrs_per_week == 0){
                obj.hrs_per_week = body.hrs_per_week;
            }
            if(body.experience){
                obj.experience = body.experience;
            }
            json = JSON.stringify(obj);
            const response:any = await axios.post(parsUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if(response.status == 200){
                return {statuscode:200,data: response.data};
            }else if(response.status == 201){
                return {statuscode:201};
            }else{
                return {statuscode:500};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log("error " , error );
            return {statuscode:500};
        }
    }

    async searchGigs(user:any,body:any): Promise<any> {
        try {
            if(process.env.ENV != "development" ){
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL + 'search_gigs/';
            }else {
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL_DEV + 'search_gigs/';
            }
            var json = "";
            var obj :any = {
                flId:body.flId,
                search_key:body.search_key
            };
            if(body.search_key_type || body.search_key_type == 0){
                obj.search_key_type = body.search_key_type;
            }
            if(body.pageNumber){
                obj.pageNumber = body.pageNumber;
            }
            if(body.norpp){
                obj.norpp = body.norpp;
            }
            json = JSON.stringify(obj);
            const response:any = await axios.post(parsUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if(response.status == 200){
                return {statuscode:200,data: response.data};
            }else if(response.status == 201){
                return {statuscode:201};
            }else{
                return {statuscode:500};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async matchScore(user:any,body:any): Promise<any> {
        try {
            if(process.env.ENV != "development" ){
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL + 'get_match_score/';
            }else {
                var parsUrl :any= process.env.RECOMMENDED_BASE_URL_DEV + 'get_match_score/';
            }
            const json = JSON.stringify({ "gigId":body.gigId,"flId":body.flId});
            const response:any = await axios.post(parsUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if(response.status == 200){
                return {statuscode:200,data: response.data};
            }else if(response.status == 201){
                return {statuscode:201};
            }else{
                return {statuscode:500};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async forgetPasswordLink( user:any,body:any): Promise<any> {
        try {
          const userRepository = getRepository(User);
          const users = await userRepository.findOne({ where: { email:body.email, is_deleted:0}});
          if(!users){
              return {statuscode:201};
          } else {
            if(users.socail_id != ""){
              return {statuscode:203};
            }else{
              var resetToken :any = await crypto.randomBytes(32).toString('hex');
              var resetPasswordExpires :any = parseInt(""+Date.now()/1000) + 3600; //expires in an hour
              const updateToken = await userRepository.update({ id:  users.id }, {resetToken:resetToken, resetPasswordExpires:resetPasswordExpires});

              let  reciver_address = body.email;
              let  message =  'You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n' +
              'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
              '' + process.env.FORGET_PASSWORD_URL + '/reset-password/' + resetToken + '\n\n' +
              'If you did not request this, please ignore this email, your password will remain unchanged.\n The link to reset expires in an hour';
              let  subject =  "Reset password on begig";

              var sentMail = await mailSendFunction(reciver_address,message,subject,"");
              if(sentMail){
                  return {statuscode:200};
              } else {
                  return {statuscode:202};
              }
            }
          }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log("error " , error );
            return {statuscode:500};
        }
    }

    async resetPassword(body:any,token:any): Promise<any> {
        try {
            const userRepository = getRepository(User);
            var time = Date.now()/1000;
            const users = await userRepository.findOne({ where: {resetPasswordExpires: MoreThanOrEqual(time), resetToken: token }});
            if(!users){
                return {statuscode:201};
            } else {
                var encryptpassword = await bcrypt.hash(body.new_password, 12);
                const updateToken = await userRepository.update({ id:  users.id }, {password: encryptpassword, resetToken:"", resetPasswordExpires:0});
                return {statuscode:200};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getAdminAccountByUserId(user:any,body:any): Promise<any> {
        try {
            var user_id = body.user_id;
            const userRepository = getRepository(User);
            const employer = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id =:id",{id: user_id })
            .getOne();
            if(employer){
               let company_owner = employer.company.created_by;
               var user:any = await userRepository.findOne({where:{id:company_owner}});
               return {statuscode:200,data:{owner_id:company_owner,owner_account:user.razorpay_account_number}};
            }else{
                return {statuscode:201}
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async adminSaveFlCount(user:any): Promise<any> {
        try {
            var top = 0;
            var good = 0;
            var basic = 0;
            top = await getRepository(SavedFreelancer)
            .createQueryBuilder("saved_freelancer")
            .where("saved_freelancer.employer_id =:emp_id",{emp_id: user.id})
            .andWhere("saved_freelancer.match_score >= 80")
            .getCount();

            good = await getRepository(SavedFreelancer)
            .createQueryBuilder("saved_freelancer")
            .where("saved_freelancer.employer_id =:emp_id",{emp_id: user.id})
            .andWhere("saved_freelancer.match_score >= 50 AND saved_freelancer.match_score < 80")
            .getCount();

            basic = await getRepository(SavedFreelancer)
            .createQueryBuilder("saved_freelancer")
            .where("saved_freelancer.employer_id =:emp_id",{emp_id: user.id})
            .andWhere("saved_freelancer.match_score < 50")
            .getCount();

            return {statuscode:200,data:{top_fl:top, good_fl:good, basic_fl:basic}};

        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async saveFlCountByGigsIds(body:any): Promise<any> {
      try {
        var top:any;
        var good:any;
        var basic:any;
        top = await getRepository(SavedFreelancer)
        .createQueryBuilder("saved_freelancer")
        .where("saved_freelancer.gig_id IN (:...ids)",{ ids: body.gig_ids })
        .andWhere("saved_freelancer.match_score >= 80")
        .getMany();

        good = await getRepository(SavedFreelancer)
        .createQueryBuilder("saved_freelancer")
        .where("saved_freelancer.gig_id IN (:...ids)",{ ids: body.gig_ids })
        .andWhere("saved_freelancer.match_score >= 50 AND saved_freelancer.match_score < 80")
        .getMany();

        basic = await getRepository(SavedFreelancer)
        .createQueryBuilder("saved_freelancer")
        .where("saved_freelancer.gig_id IN (:...ids)",{ ids: body.gig_ids })
        .andWhere("saved_freelancer.match_score < 50")
        .getMany();
        var main_arr :any = [];
        for(let i=0;i<body.gig_ids.length;i++){
          let count = 0;
          for(let j=0;j<basic.length;j++){
            if(body.gig_ids[i] == basic[j].gig_id){
              count++;
            }
          }
          let count_good = 0;
          for(let j=0;j<basic.length;j++){
            if(body.gig_ids[i] == good[j].gig_id){
              count_good++;
            }
          }
          let count_top = 0;
          for(let j=0;j<top.length;j++){
            if(body.gig_ids[i] == top[j].gig_id){
              count_top++;
            }
          }
          let obj = {gig_id:body.gig_ids[i],top_saved:count_top,good_saved:count_good,basic_saved:count};
          main_arr.push(obj);
        }

            return {statuscode:200,data:main_arr};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log("error user", error )
            return {statuscode:500};
        }
    }

    async getCompanyOwnerId(company_id:any): Promise<any> {
        try {
            const companyRepo = await getRepository(Company);
            const companyData :any= await companyRepo.findOne({ where: {id: company_id }});
            const companyAllData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .select(['employer.id','user.first_name','user.last_name','company.id','company.company_name',])
            .where("user.id =:id",{id: companyData.created_by })
            .getOne();
            if(!companyAllData){
                return {statuscode:201}
            }else{
                return {statuscode:200,data:companyAllData};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async updatePersonalDetails(body:any,user:any): Promise<any> {
        try {
            const userRepository = getRepository(User);
            const freelancerRepository = getRepository(Freelancer);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var info = {
                profile_pic: body.profile_pic,
                first_name: body.first_name,
                last_name: body.last_name
            }
            var updateName = {
                Vendor_Name: body.first_name
            }
            var userUpdate = await userRepository.update({ id:  user.id }, info);
            try{
                if(user.role == 0){
                    var zohoData :any = await zohoInfoRepo.findOne();
                    updateZohoFreelancer(zohoData.accesstoken,user.zoho_user_id,updateName);

                }else{
                    var updateEmpData = {
                        First_Name: body.first_name,
                        Last_Name: body.last_name
                    }
                    var zohoData :any = await zohoInfoRepo.findOne();
                    updateZohoContact(zohoData.accesstoken,user.zoho_user_id,updateEmpData);
                }
            }catch(error){
                console.log(error);
            }
            if(userUpdate.affected){
                if(user.role == 0){
                    const updateSteps =  await freelancerRepository.update({ user: user.id }, {exprience_slots: body.exprience});
                    if(updateSteps.affected){
                        return {statuscode:200};
                    }else{
                        return {statuscode:201};
                    }
                }else{
                    return {statuscode:200};
                }
            }else{
                return {statuscode:201};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async sendNotifications(body:any): Promise<any> {
        try {
            const notificationRepo = getRepository(Notifications);
            var time = Date.now() / 1000;
            var ids_str_arr = [];
            var fl_id = body.meta_data.fl_id;
            var created_by = body.meta_data.created_by;
            var message = body.message;
            if(fl_id != null){
            const fl_details = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .where("freelancer.id = "+fl_id)
                .getOne();
                if(fl_details){
                message = message.replace("{{fl_name}}", fl_details.user.first_name+" "+fl_details.user.last_name)
                }
            }
            if(created_by != null){
            const userData = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .where("user.id = "+created_by)
                .getOne();
                if(userData){
                message = message.replace("{{company_name}}", userData.company.company_name);
                message = message.replace("{{admin_name}}", userData.user.first_name+" "+userData.user.last_name);
                }
            }
            for(let i=0;i<body.ids.length;i++){
            let notificationObj = new Notifications();
            notificationObj.message = message;
            notificationObj.meta_data = JSON.stringify(body.meta_data);
            notificationObj.send_on = time;
            notificationObj.user_id = body.ids[i];
            await notificationRepo.save(notificationObj);
            ids_str_arr.push(body.ids[i].toString());
            }
            sendNotifications(ids_str_arr,message,body.meta_data);
            return {statuscode:200};
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log("error user", error )
            return {statuscode:500};
        }
    }

    async sendNotificationsFls(body:any): Promise<any> {
      try {
        const notificationRepo = getRepository(Notifications);
        var time = Date.now() / 1000;
        var ids_str_arr = [];
        var fl_id = body.meta_data.fl_id;
        var created_by = body.meta_data.created_by;
        var message = body.message;
        if(fl_id != null){
          const fl_details = await getRepository(Freelancer)
            .createQueryBuilder("freelancer")
            .leftJoinAndSelect("freelancer.user", "user")
            .where("freelancer.id = "+fl_id)
            .getOne();
            if(fl_details){
              message = message.replace("{{fl_name}}", fl_details.user.first_name+" "+fl_details.user.last_name)
            }
        }
        if(created_by != null){
          const userData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .where("user.id = "+created_by)
            .getOne();
            if(userData){
              message = message.replace("{{company_name}}", userData.company.company_name);
              message = message.replace("{{admin_name}}", userData.user.first_name+" "+userData.user.last_name);
            }
        }
        const userData = await getRepository(Freelancer)
            .createQueryBuilder("freelancer")
            .leftJoinAndSelect("freelancer.user", "user")
            .where("freelancer.id IN (:...ids)",{ ids: body.ids })
            .getMany();
        for(let i=0;i<userData.length;i++){
          let notificationObj = new Notifications();
          notificationObj.message = message;
          notificationObj.meta_data = JSON.stringify(body.meta_data);
          notificationObj.send_on = time;
          notificationObj.user_id = userData[i].user.id;
          await notificationRepo.save(notificationObj);
          ids_str_arr.push(userData[i].user.id.toString());
        }
        sendNotifications(ids_str_arr,message,body.meta_data);
        return {statuscode:200};
      }
      catch (error) {
        if(process.env.ENV != "development"){
            rollbar.error(error);
        } 
        console.log("error user", error )
        return {statuscode:500};
      }
    }


    async getNotificationList(user:any):Promise<any>{
      try{
        const notificationRepo = getRepository(Notifications);
        const notificationData = await getRepository(Notifications)
            .createQueryBuilder("notifications")
            .where("notifications.user_id  = "+user.id)
            .orderBy("notifications.id", 'DESC')
            .limit(100)
            .getMany();
        if(notificationData.length > 0){
          return {statuscode:200,notificationData:notificationData};
        }else{
          return {statuscode:201};
        }
      }catch(err){
        console.log(err)
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500}
      }
    }

    async readNotification(body:any):Promise<any>{
      try{
        const notificationRepo = getRepository(Notifications);
        await notificationRepo.update({id:body.notification_id},{is_read:1})
        return {statuscode:200};
      }catch(err){
        console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500}
      }
    }


    async readAllNotification(user:any):Promise<any>{
      try{
        const notificationRepo = getRepository(Notifications);
        await notificationRepo.update({user_id:user.id},{is_read:1})
        return {statuscode:200};
      }catch(err){
        console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500}
      }
    }

    async createZohoToken(){
        try{
            const zohoInfoRepo = getRepository(ZohoInfo);
            var zohoToken :any = await zohoInfoRepo.findOne();
            var time = Date.now()/1000;
            if(zohoToken){
                if(time > zohoToken.expire_time){
                    var createNewAcceessToken =  await zohoCreateAccessToekn();
                    await zohoInfoRepo.update({ accesstoken:zohoToken.accesstoken }, {accesstoken:createNewAcceessToken.access_token, expire_time:time+3500});
                }
            }else{
                var createNewAcceessToken =  await zohoCreateAccessToekn();
                const zohoInfo = new ZohoInfo();
                    zohoInfo.accesstoken = createNewAcceessToken.access_token;
                    zohoInfo.expire_time = time+3500;
                const savedfreelancer:any = await zohoInfoRepo.save(zohoInfo);
            }
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log(error);
        }
    }

    async createZohoAccountForFLs():Promise<any>{
      try{
        var arr = [31,15854,29,16122,15969,16071,16369,16048,16075,16069,16011,16216,15252,15311,15337,57,14639,207,15471,14353,15469,15599,15145,15602,15485,15127,15152,15682,15228,15688,15189,15751,15231,15271,15293,15767,15742,16991,16989,15819,16537,16751,16776,16771,17540,16966,16990,17126,17353,17209,17252,17390,17328,17402,16682,16003,16038,15883,16063,16084,16091,16094,16096,15998,21,16002,16126,15927,16143,16164,10018,9875,14687,14788,14306,14908,15449,15548,14312,15580,15596,15600,15149,15597,15154,15640,15639,15191,15645,15195,15662,15206,15221,15763,15804,47,5669,16161,16149,16294,16312,16351,16423,16468,16471,16436,15868,16480,16587,16588,16603,16605,16629,16666,16655,15970,16677,16685,16687,16657,16622,16060,16696,16740,16742,16759,16763,16809,16554,16825,16919,16924,16814,16932,15697,16954,16976,16732,16965,17017,17010,16959,17037,17036,17057,17071,17106,16611,17168,17181,17185,17200,17231,17220,17164,17223,17308,17310,17316,17334,17327,17360,17339,17333,17400,17293,17417,17434,17384,17351,17480,17477,17502,17534,17538,17574,16377,17590,17584,17600,17613,17614,17544,17623,17503,17636,17635,17637,17633,17469,17654,17660,17659,8426,17643,17645,17003,17689,17681,16024,17009]; // query to get fl ids SELECT distinct fl_id FROM begig_job_service.gigs where fl_id != 0 union select distinct fl_id from begig_job_service.bids union select distinct fl_id from begig_job_service.invite_fl_for_gigs;SELECT * FROM begig_job_service.invite_fl_for_gigs LIMIT 0, 50000

        const userRepository = getRepository(User);
        const freelancerRepositor = getRepository(Freelancer);
        const zohoInfoRepo = getRepository(ZohoInfo);
        var fl_data:any = await getRepository(Freelancer)
        .createQueryBuilder("freelancer")
        .leftJoinAndSelect("freelancer.user", "user")
        .where("freelancer.id IN (:...ids)",{ids:arr})
        .andWhere("(user.zoho_user_id = 0 or user.zoho_user_id = '')")
        .getMany();
        console.log("---------------------------");
        console.log(fl_data.length);
        async function create(id:any){
          let users = fl_data[id].user
          let chk:any = await userRepository.findOne({where:{id:users.id}});
          if(chk.zoho_user_id == "" || chk.zoho_user_id == 0){
            var Email = users.email;
            var Category = "freelancer";
            var Description = "";
            var Vendor_Name = users.first_name + ' ' +users.last_name;
            var Website = "";
            var City = "";
            var Phone = "";
            var State = "";
            var GL_Account = "";
            var Street = "";
            var Country = "";
            var Zip_Code = "";
            var GSTN = "";
            var Place_of_Supply = "HR";
            var zohoToken :any = await zohoInfoRepo.findOne();
            var createFl :any = await createZohoFreelancer(zohoToken.accesstoken,Email,Category,Description,Vendor_Name,Website,City,Phone,State,GL_Account,Street,Country,Zip_Code,GSTN,Place_of_Supply);
            console.log("created ", createFl.data[0].details);
            userRepository.update({ id: users.id }, {zoho_user_id:createFl.data[0].details.id});
          }
        }
        for(let i = 0;i<fl_data.length;i++){
          setTimeout(function(){
            create(i);
          }, 1000);
        }
        return {statuscode:200}
      }catch(err){
        console.log(err);
        return {statuscode:500}
      }
    }

    async createZohoAccountForCompany():Promise<any>{
      try{
        var arr = [24,25,42,45,54,15912,16127,16129,16137,15906,16151,15903,15924,15908,16220,15905,16238,16245,16324,16325,16333,58,16354,16367,16371,16380,16382,16383,16391,16392,16058,16416,57,16292,16428,16443,16445,16446,16448,16447,16329,15918,16464,16469,16494,16505,15935,15931,16079,16086,16099,15988,16096,16005,16063,16100,16090,16064,16103,15883,15875,15878,16068,15897,15898,16112,15899,16113,16110,15886,15891,16116,16114,16517,16523,16529,16540,16556,16541,16714,16911,16912,17054,17063,17079,14,15907,17134,17185,17306,17338,17511,17544,17547,17591,17651,17679,17721,17737,17749];
        const userRepository = getRepository(User);
        const employerRepositor = getRepository(Employer);
        const companyRepositor = getRepository(Company);
        const zohoInfoRepo = getRepository(ZohoInfo);
        for(let i = 0;i<arr.length;i++){
          setTimeout(function(){
            create(arr[i]);
          }, 1000);
        }
        async function create(id:any){
          var employerDetails:any = await getRepository(Employer)
          .createQueryBuilder("employer")
          .leftJoinAndSelect("employer.user", "user")
          .leftJoinAndSelect("employer.company", "company")
          .andWhere("user.id = "+id)
          .getOne();
          if(employerDetails){
            let tmp = employerDetails.user.email.split('@');
            let tmp2 = tmp[1].split('.');
            let email_domain = tmp2[0];
            let Legal_name = email_domain;
            let Account_Name = email_domain;
            let Description = "";
            let Account_Type = "Enterprise";
            let Shipping_State = "";
            let Website = "";
            let Industry = "";
            let Phone = "";
            let Billing_Country = "";
            let Billing_Street = "";
            let Billing_Code = "";
            let Shipping_City = "";
            let Shipping_Country = "";
            let Shipping_Code = "";
            let Billing_City = "";
            let Billing_State = "";
            let Shipping_Street = "";
            let GSTN = "";
            let GST_Treatment = "Unregistered Business";
            let Place_of_Supply = "HR";
            let Salutation = "";
            let Mobile = ""
            if(employerDetails.company.zoho_enterprise_id != 0){// create only contact
			  if(employerDetails.user.zoho_user_id == 0){	console.log("id = "+id);console.log(employerDetails);
				  try{
					var zohoToken :any = await zohoInfoRepo.findOne();
					var createContactOnZoho = await createZohoContact(zohoToken.accesstoken,employerDetails.company.zoho_enterprise_id,employerDetails.user.email,Shipping_Code,Phone,Billing_State,Shipping_Street,Salutation,employerDetails.user.first_name,employerDetails.user.last_name,Account_Type,Shipping_Country,Billing_City,Description,Mobile,Industry);console.log(createContactOnZoho.data[0].details);
					console.log("zoho contact = "+createContactOnZoho.data[0].details.id)
					userRepository.update({ id: employerDetails.user.id }, {zoho_enterprise_id:employerDetails.company.zoho_enterprise_id,zoho_user_id:createContactOnZoho.data[0].details.id});
				  }catch(er){
					console.log(er);
				  }
			  }
            }else{//create contact as well as enterprises account
				console.log("id = "+id);console.log(employerDetails);
              try{
                var zohoToken :any = await zohoInfoRepo.findOne();
                var createEnterprise = await createZohoEnterpriseAccount(zohoToken.accesstoken,Legal_name,Account_Name,Description,Account_Type,Shipping_State,Website,Industry,Phone,Billing_Country,Billing_Street,Billing_Code,Shipping_City,Shipping_Country,Shipping_Code,Billing_City,Billing_State,Shipping_Street,GSTN,GST_Treatment,Place_of_Supply);
				console.log("enterprises id - "+createEnterprise.data[0].details.id);
                var createContactOnZoho = await createZohoContact(zohoToken.accesstoken,createEnterprise.data[0].details.id,employerDetails.user.email,Shipping_Code,Phone,Billing_State,Shipping_Street,Salutation,employerDetails.user.first_name,employerDetails.user.last_name,Account_Type,Shipping_Country,Billing_City,Description,Mobile,Industry);
				console.log(createContactOnZoho.data[0].details);
				console.log("zoho contact = "+createContactOnZoho.data[0].details.id)
                companyRepositor.update({ id: employerDetails.company.id }, {zoho_enterprise_id:createEnterprise.data[0].details.id});

                userRepository.update({ id: employerDetails.user.id }, {zoho_enterprise_id:employerDetails.company.zoho_enterprise_id,zoho_user_id:createContactOnZoho.data[0].details.id});
              }catch(er){
                console.log(er);
              }
            }
          }
        }
        return {statuscode:200}
      }catch(err){
        console.log(err);
        return {statuscode:500}
      }

    }


    async insertFLs():Promise<any>{
        /*try{
        const userRepository = getRepository(User);
        const freelancerRepository = getRepository(Freelancer);
        const userMetaRepository = getRepository(UserMeta);
        const readFile = util.promisify(fs.readFile);
        var json_str  = await readFile('freelancers_0_8000.json','utf8');
        var json = JSON.parse(json_str);
        var result:any = [];
        for(var i in json)
        {  result.push(json [i]); }
        var len = result.length;


        async function signup_fl(index:any){
            try{
            let wp_id = result[index].basic.data.ID;
            let user_email = result[index].basic.data.user_email;
            let user_registered = result[index].basic.data.user_registered;
            let first_name = result[index].first_name;
            let last_name = result[index].last_name;
            let image_url = result[index].image_url;
            let phone = result[index].phone;
            let country = result[index].country;
            let address = result[index].address;
            let exp_years = parseInt(result[index].exp_years);
            let skills = result[index].skills; //  { title: 'Data Structures &amp; Algorithms', skill_experience: '70' }
            let social_linkedin = result[index].social.social_linkedin;
            let social_github = result[index].social.social_github;
            let social_others = result[index].social.social_others;
            let about_me = "";
            let password = await bcrypt.hash("123456", 12);
            let exprience = "0+";
            if(exp_years > 1 && exp_years <=2){
                exprience = "1+";
            }else if(exp_years > 2 && exp_years <=3){
                exprience = "2+";
            }else{
                exprience = "3+";
            }
            const users = await userRepository.findOne({ where: { email:user_email, is_deleted:0}});console.log(users);
            if(!users){console.log("no user found");
                var usersd = new User();
                    usersd.first_name = first_name;
                    usersd.last_name = last_name;
                    usersd.otp = "1111";
                    usersd.otp_expire_time = Date.now() / 1000;
                    usersd.password = password;
                    usersd.email = user_email;
                    usersd.mobile_no = phone;
                    usersd.profile_pic = image_url;
                    usersd.steps_completed = 0;
                    if(result[index].profile_blocked == "off"){
                    usersd.status = 1;
                    }else{
                    usersd.status = 2;
                    }
                    usersd.is_login_first_time = 1;
                    usersd.role = 0;
                    usersd.is_imported_from_wp = 1;
                    usersd.created_at = new Date(user_registered).getTime();
                    usersd.updated_at = new Date(user_registered).getTime();
                const savedUser = await userRepository.save(usersd);

                var freelancer = new Freelancer();
                    freelancer.user = usersd;
                    freelancer.exprience_slots = exprience;
                    freelancer.about_me = about_me;
                    freelancer.linkedin_url = social_linkedin;
                    freelancer.github_url = social_github;
                    freelancer.other_url = social_others;
                    freelancer.country = country;
                const savedfreelancer = await freelancerRepository.save(freelancer);
                    console.log("fl_id =  "+savedfreelancer.id);
                    console.log("uid =  "+savedUser.id);
                    console.log("wp_id =  "+wp_id);

                var userMeta = new UserMeta();
                userMeta.fl_id = savedfreelancer.id;
                userMeta.user_id = savedUser.id;
                userMeta.meta_key = "wordpress_user_id";
                userMeta.meta_value = ""+wp_id;
                const savedUserMeta = await userMetaRepository.save(userMeta);
            }
            }catch(e){
            console.log(e)
            }
        }
        console.log("start");
        for(let i = 180;i<1000;i++){
        //for(let i = 0;i<1;i++){
            signup_fl(i);
            //console.log(result);
        }

        }catch(err){
        console.log(err);
        }*/
    }

    async insertEmployers():Promise<any>{
        /*try{
        const userRepository = getRepository(User);
        const employerRepository = getRepository(Employer);
        const companyRepository = getRepository(Company);
        const userMetaRepository = getRepository(UserMeta);
        const readFile = util.promisify(fs.readFile);
        var json_str  = await readFile('employers.json','utf8');
        var json = JSON.parse(json_str);
        var result:any = [];
        for(var i in json)
        {  result.push(json [i]); }
        var len = result.length;
        async function signup_employers(index:any){console.log("started :- ");
            let wp_id = result[index].basic.data.ID;
            let user_email = result[index].basic.data.user_email;
            let user_registered = result[index].basic.data.user_registered;
            let first_name = result[index].first_name;
            let last_name = result[index].last_name;
            let password = await bcrypt.hash("123456", 12);

            let tmp = user_email.split("@");
            let tmp2 = tmp[1].split('.');
            let email_domain = tmp2[0];

            const users = await userRepository.findOne({ where: { email:user_email, is_deleted:0}});
            console.log(users);
            if(!users){

            var usersd = new User();
                usersd.first_name = first_name;
                usersd.last_name = last_name;
                usersd.otp = "1111";
                usersd.otp_expire_time = Date.now() / 1000;
                usersd.password = password;
                usersd.email = user_email;
                usersd.status = 1;
                usersd.is_login_first_time = 1;
                usersd.role = 1;
                usersd.is_imported_from_wp = 1;
                usersd.created_at = new Date(user_registered).getTime();
                usersd.updated_at = new Date(user_registered).getTime();
            const savedUser = await userRepository.save(usersd);

            let companyObj = new Company();
                companyObj.company_name = email_domain;
                companyObj.gst_tin = "";
                companyObj.location = "";
                companyObj.created_by = savedUser.id;
                companyObj.updated_by = savedUser.id;
                companyObj.created_at = new Date(user_registered).getTime();
                companyObj.updated_at = new Date(user_registered).getTime();
                const savedCompany = await companyRepository.save(companyObj);

            let employerObj = new Employer();
            employerObj.user = savedUser;
            employerObj.company = savedCompany;
            employerObj.location = "";
            employerObj.type = 0;
            const savedEmployer = await employerRepository.save(employerObj);

            var userMeta = new UserMeta();
            userMeta.fl_id = 0;
            userMeta.user_id = savedUser.id;
            userMeta.meta_key = "wordpress_user_id";
            userMeta.meta_value = ""+wp_id;
            const savedUserMeta = await userMetaRepository.save(userMeta);
            console.log("end");
            }
        }console.log(result.length);
        for(let i = 180;i<result.length;i++){
            signup_employers(i);
            }console.log(result[1]);
        }catch(err){
        console.log(err);
        }*/
    }

    async sendLoginCredentialsEmailToOldUSers(){
        /*try{
        const userRepository = getRepository(User);
        var resetToken :any = await crypto.randomBytes(32).toString('hex');
        var resetPasswordExpires :any = parseInt(""+Date.now()/1000) + (3600 * 24); //expires in an 24 hour
        var new_users = await userRepository.find({where:{is_imported_from_wp:1,is_email_sent:0},take: 1000});
        async function sendNewCredentials(index:any){
            let user_id = new_users[index].id;
            let email = new_users[index].email;
            let first_name = new_users[index].first_name;
            var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var new_pass = "";
            for (var i = 0, n = charset.length; i < 8; ++i) {
            new_pass += charset.charAt(Math.floor(Math.random() * n));
            }
            var encrypted_pass = await bcrypt.hash(new_pass, 12);
            await userRepository.update({ id:  user_id }, {resetToken:resetToken, resetPasswordExpires:resetPasswordExpires,password:encrypted_pass,is_email_sent:1});
            let  message =  'Hi '+first_name+',\n\n' +
            'Welcome to the Begig V2, please find login to new version with this password '+new_pass+' also you can reset your password by clicking following link\n\n' +
            '' + process.env.FORGET_PASSWORD_URL + '/reset-password/' + resetToken + '\n\nThanks.';
            let  subject =  "Welcome to Begig V2";
            var sentMail = await mailSendFunction(email,message,subject,"");
        }
        console.log(new_users.length);
        for(let i=0;i<new_users.length;i++){
            await sendNewCredentials(i);
        }
        }catch(err){
        console.log(err);
        }*/
    }

}

