import { User } from "../models/User";
import { Freelancer } from "../models/Freelancer";
import { Company } from "../models/Company";
import { getRepository, Brackets, Not } from 'typeorm';
import { Employer } from "../models/Employer";
const axios = require('axios');
const Razorpay = require('razorpay');
require('dotenv').config()

export class SiteAdminService {

    async getTotalUnapprovedClientList(body:any){
        try{
            var page_number = body.page_number || 0;
            var number_of_record = body.number_of_record || 10;
            var search_key = body.search_key;
            var unApprovedEmployer :any = "";
            if(body.search_key != "" && body.search_key != undefined){
                unApprovedEmployer = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .where("user.status = 4")
                .andWhere("employer.type = 0")
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("employer.company like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
                .orderBy('user.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)
                .getMany();
            }else{
                unApprovedEmployer = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .where("user.status = 4")
                .andWhere("employer.type = 0")
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
                .orderBy('user.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)
                .getMany();
            }
            if(unApprovedEmployer.length > 0){
                return {statuscode:200,data:unApprovedEmployer};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }

    }

    async getTotalApprovedClientList(body:any){
        try{
            var page_number = body.page_number || 0;
            var number_of_record = body.number_of_record || 10;
            var search_key = body.search_key;
            var approvedEmployer :any = "";
            if(body.search_key != "" && body.search_key != undefined){
                 approvedEmployer = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .where("user.status = 1")
                .andWhere("employer.type = 1")
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("employer.company like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','user.approved_at','company.id','company.company_name','company.location'])
                .orderBy('user.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)
                .getMany();
            }else{
                approvedEmployer = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .where("user.status = 1")
                .andWhere("employer.type = 1")
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','user.approved_at','company.id','company.company_name','company.location'])
                .orderBy('user.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)
                .getMany();
            }
            if(approvedEmployer.length > 0){
                return {statuscode:200,data:approvedEmployer};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }

    }

    async approveClient(id : any){
        try{
            var todayDate = Date.now()/1000;
            var userRepository = getRepository(User);
            var razorpay_customer_id = "";
            var razorpay_account_number = "";
            var razorpay_bank_account_number = "";
            var razorpay_ifsc_code = "";
            var razorpay_bank_account_name = "";
            var razorpay_bank_name = "";
            var getUser:any = await userRepository.findOne({where:{id:id}});
            let check_email_has_virtual_acc = await userRepository.find({ where: { email:getUser.email, is_deleted:Not(0)}});
            if(check_email_has_virtual_acc.length > 0){
              for(let  i = 0;i<check_email_has_virtual_acc.length;i++){
                if(check_email_has_virtual_acc[i].razorpay_customer_id != ""){
                  razorpay_customer_id = check_email_has_virtual_acc[i].razorpay_customer_id;
                  razorpay_account_number = check_email_has_virtual_acc[i].razorpay_account_number;
                  razorpay_bank_account_number = check_email_has_virtual_acc[i].razorpay_bank_account_number;
                  razorpay_ifsc_code = check_email_has_virtual_acc[i].razorpay_ifsc_code;
                  razorpay_bank_account_name = check_email_has_virtual_acc[i].razorpay_bank_account_name;
                  razorpay_bank_name = check_email_has_virtual_acc[i].razorpay_bank_name;
                }
              }
            }
            try{
              /* CREATING RAZORPAY VIRTUAL ACCOUNT STARTS */
              var instance = new Razorpay({ key_id: process.env.RAZORPAY_ID, key_secret: process.env.RAZORPAY_SECRET })
              if(razorpay_customer_id == ""){
                let rp_cust = await instance.customers.create({name:getUser.first_name+" "+getUser.last_name, email:getUser.email, contact:"", notes:""});
                razorpay_customer_id = rp_cust.id;
                let rp_virtual_account = await instance.virtualAccounts.create({receivers:{types:["bank_account"]},customer_id:razorpay_customer_id});
                razorpay_account_number = rp_virtual_account.id;
                razorpay_bank_account_number = rp_virtual_account.receivers[0].account_number;
                razorpay_ifsc_code = rp_virtual_account.receivers[0].ifsc;
                razorpay_bank_account_name = rp_virtual_account.receivers[0].name;
                razorpay_bank_name = rp_virtual_account.receivers[0].bank_name;
                if(razorpay_bank_name == null){
                  razorpay_bank_name = "";
                }
                /* CREATING RAZORPAY VIRTUAL ACCOUNT ENDS */
              }
            }catch(e){
                if(process.env.ENV != "development"){
                    rollbar.error(e);
                } 
              console.log(e);
            }
            const approvedEmployer :any= await getRepository(User)
            .createQueryBuilder("user")
            .update()
            .set({ status: 1, approved_at:todayDate,razorpay_customer_id:razorpay_customer_id,razorpay_account_number:razorpay_account_number,razorpay_bank_account_number:razorpay_bank_account_number,razorpay_ifsc_code:razorpay_ifsc_code,razorpay_bank_account_name:razorpay_bank_account_name,razorpay_bank_name:razorpay_bank_name})
            .where("user.id=:id",{id: id })
            .execute();
            if(approvedEmployer.affected){
                return {statuscode:200,data:id};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async rejectClient(id : any , userid : any){
        try{
            const rejectEmployer = await getRepository(Employer)
            .createQueryBuilder("employer")
            .delete()
            .where("employer.id=:id",{id: id })
            .execute();
            const deleteUser = await getRepository(User)
            .createQueryBuilder("user")
            .delete()
            .where("user.id=:id",{id: userid })
            .execute();
            if(deleteUser.affected){
                return {statuscode:200,data:id};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }            
            return {statuscode:500};
        }
    }

    async getAllEmployer(body:any): Promise<any> {
        try {
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            var userData :any = "";
            var query_condition :any = "";
            var search_query_condition :any = "";
            var filter_type = body.filter_type ;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var search_key = body.search_key;
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(search_key != ""&& search_key != undefined){
                search_query_condition = new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("company.company_name like :search_key", { search_key: `%${search_key}%` })
                    }
                );
            }
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+to+"";
            }

            if(query_condition != "" && search_query_condition !=""){
                userData = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
                .where("user.is_deleted = 0")
                .andWhere(query_condition)
                .andWhere(search_query_condition)
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(query_condition != ""){
                 userData = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
                .where("user.is_deleted = 0")
                .andWhere(query_condition)
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(search_query_condition != ""){
                userData = await getRepository(Employer)
               .createQueryBuilder("employer")
               .leftJoinAndSelect("employer.user", "user")
               .leftJoinAndSelect("employer.company", "company")
               .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
               .where("user.is_deleted = 0")
               .andWhere(search_query_condition)
               .limit(number_of_record)   // page number
               .offset(page_number * number_of_record)   // offset (from where we want to get record)
               .getMany();
            }else{
                userData = await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .leftJoinAndSelect("employer.company", "company")
                .select(['employer.id','employer.location','user.id','user.first_name','user.last_name','user.email','user.created_at','company.id','company.company_name','company.location'])
                .where("user.is_deleted = 0")
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }
            if(userData.length > 0){
                return {statuscode:200,data:userData};
            } else {
                return {statuscode:201};
            }
        }
        catch (error) {
            console.log("error user", error )
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    

    async adminInformation(user:any): Promise<any> {
        try {
            const companyRepo = await getRepository(Company);
            const companyData :any= await companyRepo.findOne({ where: {id: user.company_id }});
            const companyAllData = await getRepository(Employer)
            .createQueryBuilder("employer")
            .leftJoinAndSelect("employer.user", "user")
            .leftJoinAndSelect("employer.company", "company")
            .select(['employer.id','user.first_name','user.last_name','user.email','company.id','company.company_name'])
            .where("user.id =:id",{id: companyData.created_by })
            .getOne();
            if(!companyAllData){
                return {statuscode:201}
            }else{
                return {statuscode:200,data:companyAllData};
            }
        }
        catch (error) {
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async clientCreatedOpenGigs(body:any,token:any): Promise<any> {
        try {
            if(body.search_key != "" && body.search_key != undefined){
                var body = body;
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var search_key = body.search_key;
                var employerData :any= await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .where("user.is_deleted = 0")
                .select(['employer.id','user.id','user.first_name','user.last_name','user.email','user.mobile_no'])
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

                var user_id = [];
                for(let j=0;j< employerData.length;j++){
                    user_id.push(employerData[j].user.id);
                }

                body.user_id = user_id;
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/open_gig/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                var openData :any =[];
                for(let j=0;j< employerData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == employerData[j].user.id){
                            var openGigData : any = {
                                id:employerData[j].user.id,
                                first_name : employerData[j].user.first_name,
                                last_name : employerData[j].user.last_name,
                                email : employerData[j].user.email,
                                count : res.data.details[i].count
                            }
                            openData.push(openGigData);
                        }
                    }
                }
                if(openData.length > 0){
                    return {statuscode:200,data:openData};
                }else{
                    return {statuscode:201};
                }
            }else{
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/open_gig/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                if(res.data.details == undefined || res.data.details == null){
                    return {statuscode:201};
                }
                var created_by_arr = [];
                for(let j=0;j< res.data.details.length;j++){
                    created_by_arr.push(res.data.details[j].created_by)
                }
                var userData:any = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.id IN (:...ids)",{ ids: created_by_arr })
                .select(['user.id','user.first_name','user.last_name','user.email'])
                .getMany();
                for(let j=0;j< userData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == userData[j].id){
                        userData[j].count = res.data.details[i].count;
                        }
                    }
                }
                if(userData.length > 0){
                    return {statuscode:200,data:userData};
                }else{
                    return {statuscode:201};
                }
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async clientCreatedOngoingGigs(body:any,token:any): Promise<any> {
        try {
            if(body.search_key != "" && body.search_key != undefined){
                var body = body;
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var search_key = body.search_key;
                var employerData :any= await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .where("user.is_deleted = 0")
                .select(['employer.id','user.id','user.first_name','user.last_name','user.email','user.mobile_no'])
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

                var user_id = [];
                for(let j=0;j< employerData.length;j++){
                    user_id.push(employerData[j].user.id);
                }

                body.user_id = user_id;
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/ongoing_gigs/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                var openData :any =[];
                for(let j=0;j< employerData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == employerData[j].user.id){
                            var openGigData : any = {
                                id:employerData[j].user.id,
                                first_name : employerData[j].user.first_name,
                                last_name : employerData[j].user.last_name,
                                email : employerData[j].user.email,
                                count : res.data.details[i].count
                            }
                            openData.push(openGigData);
                        }
                    }
                }
                if(openData.length > 0){
                    return {statuscode:200,data:openData};
                }else{
                    return {statuscode:201};
                }
            }else{
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/ongoing_gigs/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                if(res.data.details == undefined || res.data.details == null){
                    return {statuscode:201};
                }
                var created_by_arr = [];
                for(let j=0;j< res.data.details.length;j++){
                    created_by_arr.push(res.data.details[j].created_by)
                }
                var userData:any = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.id IN (:...ids)",{ ids: created_by_arr })
                .select(['user.id','user.first_name','user.last_name','user.email'])
                .getMany();
                for(let j=0;j< userData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == userData[j].id){
                        userData[j].count = res.data.details[i].count;
                        }
                    }
                }
                if(userData.length > 0){
                    return {statuscode:200,data:userData};
                }else{
                    return {statuscode:201};
                }
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async clientCreatedDraftedGigs(body:any,token:any): Promise<any> {
        try {
            if(body.search_key != "" && body.search_key != undefined){
                var body = body;
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var search_key = body.search_key;
                var employerData :any= await getRepository(Employer)
                .createQueryBuilder("employer")
                .leftJoinAndSelect("employer.user", "user")
                .where("user.is_deleted = 0")
                .select(['employer.id','user.id','user.first_name','user.last_name','user.email','user.mobile_no'])
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

                var user_id = [];
                for(let j=0;j< employerData.length;j++){
                    user_id.push(employerData[j].user.id);
                }

                body.user_id = user_id;
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/drafted_gigs/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                var openData :any =[];
                for(let j=0;j< employerData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == employerData[j].user.id){
                            var openGigData : any = {
                                id:employerData[j].user.id,
                                first_name : employerData[j].user.first_name,
                                last_name : employerData[j].user.last_name,
                                email : employerData[j].user.email,
                                count : res.data.details[i].count
                            }
                            openData.push(openGigData);
                        }
                    }
                }
                if(openData.length > 0){
                    return {statuscode:200,data:openData};
                }else{
                    return {statuscode:201};
                }
            }else{
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/drafted_gigs/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                if(res.data.details == undefined || res.data.details == null){
                    return {statuscode:201};
                }
                var created_by_arr = [];
                for(let j=0;j< res.data.details.length;j++){
                    created_by_arr.push(res.data.details[j].created_by)
                }
                var userData:any = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.id IN (:...ids)",{ ids: created_by_arr })
                .select(['user.id','user.first_name','user.last_name','user.email'])
                .getMany();
                for(let j=0;j< userData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == userData[j].id){
                        userData[j].count = res.data.details[i].count;
                        }
                    }
                }
                if(userData.length > 0){
                    return {statuscode:200,data:userData};
                }else{
                    return {statuscode:201};
                }
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async freelacerBidList(body:any,token:any): Promise<any> {
        try {
            if(body.search_key != "" && body.search_key != undefined){
                var body = body;
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var search_key = body.search_key;
                var freelancerData :any = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .where("user.is_deleted = 0")
                .select(['freelancer.id','user.id','user.first_name','user.last_name','user.email','user.mobile_no'])
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

                var user_id = [];
                for(let j=0;j< freelancerData.length;j++){
                    user_id.push(freelancerData[j].id);
                }

                body.user_id = user_id;
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/freelancer_bid/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let j=0;j< freelancerData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == freelancerData[j].id){
                            freelancerData[j].count = res.data.details[i].count;
                        }
                    }
                }
                if(freelancerData.length > 0){
                    return {statuscode:200,data:freelancerData};
                }else{
                    return {statuscode:201};
                }
            }else{
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/freelancer_bid/owner_id/array';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                if(res.data.details == undefined || res.data.details == null){
                    return {statuscode:201};
                }
                var created_by_arr = [];
                for(let j=0;j< res.data.details.length;j++){
                    created_by_arr.push(res.data.details[j].created_by)
                }
                const userData:any = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .where("freelancer.id IN (:...ids)",{ ids: created_by_arr })
                .select(['freelancer.id','freelancer.userId','user.id','user.first_name','user.last_name','user.email'])
                .getMany();
                for(let j=0;j< userData.length;j++){
                    for(let i=0;i< res.data.details.length;i++){
                        if(res.data.details[i].created_by == userData[j].id){
                        userData[j].count = res.data.details[i].count;
                        }
                    }
                }
                if(userData.length > 0){
                    return {statuscode:200,data:userData};
                }else{
                    return {statuscode:201};
                }
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async freelancerHiredList(body:any,token:any): Promise<any> {
        try {
            if(body.search_key != "" && body.search_key != undefined){
                var body = body;
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var search_key = body.search_key;
                var freelancerData :any = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .where("user.is_deleted = 0")
                .select(['freelancer.id','user.id','user.first_name','user.last_name','user.email','user.mobile_no'])
                .andWhere( new Brackets( qb => {
                    qb.where("user.first_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.last_name like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.email like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("user.mobile_no like :search_key", { search_key: `%${search_key}%` })
                    }
                ))
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

                var fl_id = [];
                if(freelancerData.length > 0){
                    for(let j=0;j< freelancerData.length;j++){
                        fl_id.push(freelancerData[j].id);
                    }
                }else{
                    return {statuscode:201};
                }
                body.fl_id = fl_id;
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/siteadmin/hired_feelancer_list';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                if(res.data.details == undefined || res.data.details == null){
                    return {statuscode:201};
                }
                for(let i=0;i< res.data.details.length;i++){
                    for(let j=0;j< freelancerData.length;j++){
                        if(res.data.details[i].fl_id == freelancerData[j].id){
                            res.data.details[i].freelancer = freelancerData[j]
                            break;
                        }
                    }
                }
                if(res.data.details.length > 0){
                    return {statuscode:200,data:res.data.details};
                }else{
                    return {statuscode:201};
                }
            }else{
                const bigigJobUrl = process.env.Begig_job_url+'api/v1/jobs/siteadmin/hired_feelancer_list';
                const res = await axios.post(bigigJobUrl, body ,{
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                if(res.data.details == undefined || res.data.details == null){
                    return {statuscode:201};
                }
                var fl_ids :any= [];
                for(let j=0;j< res.data.details.length;j++){
                    if(!fl_ids.includes(res.data.details[j].fl_id)){
                        fl_ids.push(res.data.details[j].fl_id)
                    }
                }

                var freelancerData :any = await getRepository(Freelancer)
                .createQueryBuilder("freelancer")
                .leftJoinAndSelect("freelancer.user", "user")
                .where("freelancer.id IN (:...ids)",{ ids: fl_ids })
                .select(['freelancer.id','user.id','user.first_name','user.last_name','user.email'])
                .getMany();

                for(let i=0;i< res.data.details.length;i++){
                    for(let j=0;j< freelancerData.length;j++){
                        if(res.data.details[i].fl_id == freelancerData[j].id){
                            res.data.details[i].freelancer = freelancerData[j]
                            break;
                        }
                    }
                }
                if(res.data.details.length > 0){
                    return {statuscode:200,data:res.data.details};
                }else{
                    return {statuscode:201};
                }
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async siteAdminClientDailyStatus(body:any,token:any): Promise<any> {
        try {
            var query_condition :any = "";
            var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+to+"";
            }     

            var totalClientRegistered :any ="";        
            if(query_condition != ""){
                totalClientRegistered = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.role = 1")
                .andWhere(query_condition)
                .getCount();
            }else{
                totalClientRegistered = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.role = 1")
                .getCount();
            }

            var json = "";
            if(filter_type){
                json = JSON.stringify({"filter_type": filter_type});
            }else{
                json = JSON.stringify({});
            }   
    
            const res = await axios.post(process.env.Begig_job_url+'api/v1/jobs/siteadmin/client/created/gigs/count', json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });
            return {statuscode:200,data:{totalClientRegistered:totalClientRegistered, clientCreateGigs:res.data.data }};
        }catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async siteAdminFreelancerDailyStatus(body:any,token:any): Promise<any> {
        try {
            var query_condition :any = "";
            var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "user.created_at >="+from+"  AND user.created_at < "+to+"";
            }     

            var totalFlRegistered :any ="";        
            if(query_condition != ""){
                totalFlRegistered = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.role = 0")
                .andWhere(query_condition)
                .getCount();
            }else{
                totalFlRegistered = await getRepository(User)
                .createQueryBuilder("user")
                .where("user.role = 0")
                .getCount();
            }

            var json = "";
            if(filter_type){
                json = JSON.stringify({"filter_type": filter_type});
            }else{
                json = JSON.stringify({});
            }   
    
            const res = await axios.post(process.env.Begig_job_url+'api/v1/jobs/siteadmin/freelancer/bidded/count', json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });
            return {statuscode:200,data:{TotalFlRegistered:totalFlRegistered, FreelancerBiddedCount:res.data.data }};
        }catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }



}
