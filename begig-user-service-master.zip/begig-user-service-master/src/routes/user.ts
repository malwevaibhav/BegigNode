import { Router } from 'express';
import UserController from '../controllers/UserController';
import FreelancerController from '../controllers/FreelancerController';
import CompanyController from '../controllers/CompanyController';
const multer = require('multer');
const {
    employerSingnupValidation,
    freelancerSingnupValidation,
    loginValidation,
    experienceValidation,
    basicDetailValidation,
    educationsValidation,
    skillsValidation
 } = require('../helper/validation.ts');
const varifyToken = require('../helper/varifyToken');
import SiteAdminController from '../controllers/SiteAdminController';
const router = Router();

var storage = multer.diskStorage({
    filename: (req:any, file:any, cb:any) => {
        cb(null, file.fieldname + "_" + Date.now()+file.originalname);
    }
});
var upload = multer({ storage: storage }).single('file');

var uploadMultiFiles = multer({ storage: storage }).array("multi_files");

// File updload on S3 Bucket.
router.post('/file/upload', upload, UserController.fileUpload);

// Multiple files upload on s3
router.post('/multiple/files/upload', uploadMultiFiles, UserController.multipleFilesUpload);

// Social Login
router.post('/social/login', UserController.socialLogin);

// Social Login
router.post('/social/login', UserController.socialLogin);

// Social singup
router.post('/social/singup', UserController.socialSignup);

// Signup employer
router.post('/employer/signup', employerSingnupValidation(), UserController.signupEmployer);

// Signup employer
router.post('/employer/add/admin', varifyToken, UserController.createEmployerAdmin);

// Login employer
router.post('/employer/login', loginValidation(), UserController.loginEmployer);

// Site admin login
router.post('/siteadmin/login', loginValidation(), UserController.siteAdinLogin);

// employer verify Otp
router.post('/employer/otp/verify',varifyToken, UserController.employerOTPVerify);

// employer resend Otp
router.get('/employer/otp/resend',varifyToken, UserController.employerOTPResend);

// Signup freelancer
router.post('/freelancer/signup', freelancerSingnupValidation(),  UserController.freelancerSignup);

// Login freelancer
router.post('/freelancer/login', loginValidation(), UserController.freelancerLogin);

// freelancer verifyOtp
router.post('/freelancer-verify-otp',varifyToken, UserController.verifyOtp);

// freelancer resendOtp
router.get('/freelancer-resend-otp',varifyToken, UserController.resendOtp);

// Get all admin list by company id in super admin settings page
router.post('/employer/admin/list',varifyToken, UserController.listOfCompanyAdmins);

// Get all education_qaulification
router.get('/get-all-educationqaulification', UserController.getEducationQaulification);

// Add basic details
router.post('/add-basic-details', varifyToken, basicDetailValidation(), UserController.addBasicDetails);

// Employer update address
router.post('/employer/update/address', varifyToken, UserController.employerUpdateAddress);

// Every user change password
router.post('/change/password', varifyToken, UserController.changePassword);


// Verify email for forget password
router.post('/forget/password/link', UserController.forgetPasswordLink);

// Reset password
router.put('/reset/password/:token', UserController.resetPassword);

// Every user can change mobile number
router.post('/change/mobile/number', varifyToken, UserController.changeMobileNumber);

// Add company & tax detials
router.post('/add/company/tax/details', varifyToken, CompanyController.companyTaxDetails);

// Freelancer bank details and billing address update
router.post('/freelancer/bankAndBiling/details/addUpdate', varifyToken, FreelancerController.bankAndBilingAddUpdate);

// Freelancer tax information
router.post('/add/freelancers/tax/information',varifyToken, FreelancerController.flTaxInformation);

// company back details
router.post('/add/company/bank/details',varifyToken, CompanyController.companyBankDetails);

// company update address
router.post('/company/update/address',varifyToken, CompanyController.companyUpdateAddress);

// Get Freelancer bank details and billing address
router.get('/freelancer/bankAndBiling/details', varifyToken, FreelancerController.getFlbankAndBiling);

// Get Freelancer tax information
router.get('/freelancers/tax/information',varifyToken, FreelancerController.getflTaxInformation);

// freelancer completed gigs
router.post('/freelancers/add/completed/gig',varifyToken, FreelancerController.updateGigCompletedCountForFl);


// freelancer completed gigs
router.get('/freelancers/alldata/:fl_id',varifyToken, FreelancerController.getFreelancerAllDetailsById);


// Get employer address
router.get('/employer/address',varifyToken, UserController.getEmployerAddress);

// Get company tax details
router.get('/company/tax/details',varifyToken, CompanyController.getCompanyTaxDetilas);


// Get company address
router.get('/company/address',varifyToken, CompanyController.getCompanyAddress);

// Get company bank details
router.get('/company/bank/details',varifyToken, CompanyController.getCompanyBankDetails);

// Add freelancer experience
router.post('/add-freelancer-experience', varifyToken, experienceValidation(), UserController.addfreelancerexperience);

// Add freelancer educations
router.post('/add-freelancer-educations', varifyToken, educationsValidation(), UserController.addfreelancereducation);

// Add freelancer skills
router.post('/add-freelancer-skills',varifyToken, skillsValidation(), UserController.addfreelancerskills);

// Add freelancer license & certificate
router.post('/add-freelancer-license', varifyToken, UserController.addfreelancerlicense);

// Get user data by Id
router.get('/get/user/:id',varifyToken, UserController.getUserByid);

router.get('/get/user/for/front_page/:id', UserController.getUserForFrontPageByid);

//send email to admin when he recive a bid on his gis
router.post('/send/bids/email',varifyToken, UserController.sendEmailToAdminForNewBid);

// Get multiper user data by Id
router.post('/get/users',varifyToken, UserController.getMultiUserByid);

// Get list of notification readAllNotification
router.post('/get/users/notifications',varifyToken, UserController.getNotificationList);

// read the notification
router.post('/get/users/notification/read',varifyToken, UserController.readNotification);

// read the all notification
router.post('/get/users/notification/read/all',varifyToken, UserController.readAllNotification);

// send push notification
router.post('/send/notifications', UserController.sendNotifications);

// send push notification
router.post('/send/notifications/fls', UserController.sendNotificationsFls);

router.post('/get/users/for/fontpage', UserController.getMultiUserForFrontPageByid);

// Get saved user count as good , top and basic saved users by gig ids
router.post('/gigs/saved/fls/count',varifyToken, UserController.saveFlCountByGigsIds);


// Search freelancer
router.post('/search/freelancer',varifyToken, FreelancerController.searchFreelancer);

// Get freelancer details by id
router.get('/freelancer/details/:id', varifyToken, FreelancerController.freelancerDetails);

// Get freelancer skills by id
router.get('/freelancer/skills/:id',varifyToken, FreelancerController.freelancerSkills);

// Get freelancer education by id
router.get('/freelancer/education/:id', varifyToken, FreelancerController.freelancerEducation);

// Get freelancer experience by id
router.get('/freelancer/experience/:id', varifyToken, FreelancerController.freelancerExperience);

// Get freelancer accomplishments by id
router.get('/freelancer/accomplishments/:id',varifyToken, FreelancerController.freelancerAccomplishments);

// save freelancer
router.post('/save/freelancer', varifyToken, FreelancerController.saveFreelancer);

// save freelancer  list.
router.get('/saved/freelancer/list/:gig_id',varifyToken, FreelancerController.savedFreelancersList);

// delete saved freelancer list
router.delete('/delete/saved/freelancer/:fl_id/:gig_id',varifyToken, FreelancerController.deleteSavedFreelancers);

// hired freelancer  list.
router.get('/hired/freelancer/list', varifyToken, FreelancerController.hiredFreelancersList);

// client feedback.
router.get('/freelancer/feedback/:id',varifyToken, FreelancerController.clientFeedback);

// Get multiper freelancer details by Id.
router.post('/get/freelancers/',varifyToken, FreelancerController.getMultiFreelancerByid);


// Resume parsing
router.post('/resume/parsing',varifyToken, UserController.resumeParsing);

// jd parsing
router.post('/jd/parsing',varifyToken, UserController.jdParsing);

// Recommended freelancers API.
router.post('/recommended/freelancers',varifyToken, UserController.recommendedFreelancers);

// Recommended gigs API.
router.post('/recommended/gigs',varifyToken, UserController.recommendedGigs);

// Recommended search gigs
router.post('/search_gigs', UserController.searchGigs);

// Match score
router.post('/match/score',varifyToken, UserController.matchScore);

//saved freelancer count
router.get('/admin/saved/freelancer/count', varifyToken,UserController.adminSaveFlCount);

//Get company super admin details for genrating invoice
router.post('/superadmin/account', varifyToken,UserController.getAdminAccountByUserId);

// Get company owner id
router.get('/comapny/ownerid/:company_id', varifyToken, UserController.getCompanyOwnerId);

router.get('/import/fls', UserController.insertFLs);

router.get('/import/employers', UserController.insertEmployers);


/************Begig Site Admin Start********************/
router.post('/GetTotalUnapprovedClientList',varifyToken,SiteAdminController.getTotalUnapprovedClientList);

router.post('/GetTotalApprovedClientList', varifyToken,SiteAdminController.getTotalApprovedClientList);

router.put('/ApproveClient/:id',varifyToken,SiteAdminController.approveClient);

router.put('/RejectClient/:id/:userid', varifyToken,SiteAdminController.rejectClient);

router.put('/update/profile/fname/lname/exp',varifyToken, UserController.updatePersonalDetails);

// super admin get his admin information
router.get('/admin/list/for/superdmin', varifyToken, SiteAdminController.adminInformation);


/************Begig Site Admin end********************/

router.post('/all/employer/list',varifyToken, SiteAdminController.getAllEmployer);

// Site admin api for open gigs list and count and its also include sorting searching.
router.post('/client/created/open/gigs',varifyToken, SiteAdminController.clientCreatedOpenGigs);

// Site admin api for ongoing gigs list and count and its also include sorting searching.
router.post('/client/created/ongoing/gigs',varifyToken, SiteAdminController.clientCreatedOngoingGigs);

// Site admin api for drafted gigs list and count and its also include sorting searching.
router.post('/client/created/drafted/gigs',varifyToken, SiteAdminController.clientCreatedDraftedGigs);

// freelancer hired list for site admin with searching and sorting
router.post('/siteadmin/freelancer/hired/list',varifyToken, SiteAdminController.freelancerHiredList);

// Site admin api for freelacer bid list and count and its also include sorting searching.
router.post('/freelacer/bid/list',varifyToken, SiteAdminController.freelacerBidList);

// Site admin api daily status count client registered and client create gigs count
router.post('/siteadmin/client/daily/status/count',varifyToken, SiteAdminController.siteAdminClientDailyStatus);

// Site admin api daily status count freelancer registered and freelancer bidded gigs
router.post('/siteadmin/freelancer/daily/status/count',varifyToken, SiteAdminController.siteAdminFreelancerDailyStatus);


////////////////////////change email for email///////////////////////////////////

router.post('/freelancer/change/email',varifyToken, FreelancerController.flChangeEmail);

router.post('/freelancer/verify/change/email',varifyToken, FreelancerController.flVerifyChangeEmail);

router.post('/review/to/freelancer',varifyToken, FreelancerController.reviewFl);

router.post('/freelancer/search', FreelancerController.freelancerSearch);

router.post('/freelancer/reviewlist',varifyToken, FreelancerController.freelancerListByGigID);

//saved freelancer count
router.get('/test',UserController.test);

// create zoho accounts for enterprises who having a gigs
//router.get('/create_zoho_account_for_enterprises',UserController.createZohoAccountForCompany);

// create zoho accounts for fls who working on any gigs or having bids
//router.get('/create_zoho_account_for_fls',UserController.createZohoAccountForFLs);



export default router;
