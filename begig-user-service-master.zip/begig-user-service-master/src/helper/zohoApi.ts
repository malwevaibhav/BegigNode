var axios = require('axios');
var FormData = require('form-data');
var {rollbar} = require('./rollbar');

async function zohoCreateAccessToekn(){

	var data = new FormData();
	data.append('client_id', process.env.ZOHO_CLIENT_ID);
	data.append('client_secret', process.env.ZOHO_CLIENT_SECRET);
	data.append('refresh_token', process.env.ZOHO_REFRESH_TOEKN);
	data.append('grant_type', process.env.ZOHO_GRANT_TYPE);

	var config = {
        method: 'post',
        url: 'https://accounts.zoho.in/oauth/v2/token',
		timeout:50000,
        headers: {
            ...data.getHeaders()
        },
        data : data
	};
	let res = await axios(config);
	return res.data;
}

const createZohoEnterpriseAccount = (token:any,Legal_name:any,Account_Name:any,Description:any,Account_Type:any,Shipping_State:any,Website:any,Industry:any,Phone:any,Billing_Country:any,Billing_Street:any,Billing_Code:any,Shipping_City:any,Shipping_Country:any,Shipping_Code:any,Billing_City:any,Billing_State:any,Shipping_Street:any,GSTN:any,GST_Treatment:any,Place_of_Supply:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                {
                    "Legal_name": Legal_name,
                    "Account_Name": Account_Name,
                    "Description": Description,
                    "Account_Type": Account_Type,
                    "Shipping_State": Shipping_State,
                    "Website": Website,
                    "Industry": Industry,
                    "Phone": Phone,
                    "Billing_Country": Billing_Country,
                    "Billing_Street": Billing_Street,
                    "Billing_Code": Billing_Code,
                    "Shipping_City": Shipping_City,
                    "Shipping_Country": Shipping_Country,
                    "Shipping_Code": Shipping_Code,
                    "Billing_City": Billing_City,
                    "Billing_State": Billing_State,
                    "Shipping_Street": Shipping_Street,
                    "GSTN": GSTN,
                    "GST_Treatment": GST_Treatment,
                    "Place_of_Supply": Place_of_Supply,
                    "Registered_on_Platform": true
                }
            ]
        });
        var config = {
            method: 'post',
            url: 'https://www.zohoapis.in/crm/v2/Accounts',
            timeout:30000,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in create zoho enterprise account", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const updateZohoEnterpriseAccount = (token:any,vendorId:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });

        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Accounts/'+vendorId,
            timeout:30000,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "error in update zoho enterprise account", data:{vendorId:vendorId, updateData:updateData}, error:error}
            rollbar.error(err);
            reject(error);          
        });

});

const createZohoContact = (token:any, zohoId:any,Email:any,Mailing_Zip:any,Other_Phone:any,Mailing_State:any,Mailing_Street:any,Salutation:any,First_Name:any,Last_Name:any,Department:any,Mailing_Country:any,Mailing_City:any,Title:any,Mobile:any,Lead_Source:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                {
                    "Account_Name": {
                        "id": zohoId
                    },
                    "Email": Email,
                    "Mailing_Zip": Mailing_Zip,
                    "Other_Phone": Other_Phone,
                    "Mailing_State": Mailing_State,
                    "Mailing_Street": Mailing_Street,
                    "Salutation": Salutation,
                    "First_Name": First_Name,
                    "Last_Name": Last_Name,
                    "Department": Department,
                    "Mailing_Country": Mailing_Country,
                    "Mailing_City": Mailing_City,
                    "Title": Title,
                    "Mobile": Mobile,
                    "Lead_Source": Lead_Source
                }
            ]
        });
        var config = {
            method: 'post',
            url: 'https://www.zohoapis.in/crm/v2/Contacts',
            timeout:30000,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };

        axios(config).then(function (response:any) {
            resolve(response.data);
        }).catch(function (error:any) {
            let err = {"error_msg": "Error in create zoho contact account", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const updateZohoContact = (token:any,id:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });
        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Contacts/'+id,
            timeout:30000,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "error in update zoho Contact account", data:{id:id, updateData:updateData}, error:error}
            rollbar.error(err);
            reject(error);
        });
});

const createZohoFreelancer = (token:any,Email:any,Category:any,Description:any,Vendor_Name:any,Website:any,City:any,Phone:any,State:any,GL_Account:any,Street:any,Country:any,Zip_Code:any,GSTN:any,Place_of_Supply:any,) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                {
                    "Email": Email,
                    "Category": Category,
                    "Description": Description,
                    "Vendor_Name": Vendor_Name,
                    "Website": Website,
                    "City": City,
                    "Phone": Phone,
                    "State": State,
                    "GL_Account": GL_Account,
                    "Street": Street,
                    "Country": Country,
                    "Zip_Code": Zip_Code,
                    "GSTN": GSTN,                   
                    "GST_Treatment":"Registered Business - Regular",
                    "Place_of_Supply":Place_of_Supply,
                    "Registered_on_Platform": true
                }
            ]
        });

        var config = {
            method: 'post',
            url: 'https://www.zohoapis.in/crm/v2/Vendors',
            timeout:30000,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in create zoho freelancer account", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });

});

const updateZohoFreelancer = (token:any,vendorId:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });
        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Vendors/'+vendorId,
            timeout:30000,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "error in update zoho freelancer account", data:{vendorId:vendorId, updateData:updateData}, error:error}
            rollbar.error(err);
            reject(error);
        });
});

module.exports = {
    zohoCreateAccessToekn,
    createZohoEnterpriseAccount,
    updateZohoEnterpriseAccount,
    createZohoContact,
    updateZohoContact,
    createZohoFreelancer,
    updateZohoFreelancer
}
