const AWS = require('aws-sdk');
const fs = require('fs');
require('dotenv').config();

const s3fileUpload = (file:any) =>
    new Promise(function (resolve, reject) {
        const s3 = new AWS.S3({
            accessKeyId: process.env.AWS_ACCESS_KEY_ID,
            secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
        });   
        const params = {
            ACL: 'public-read',
            Bucket: process.env.AWS_S3_BUCKET_NAME,
            Key: file.filename, // File name you want to save as in S3
            Body: fs.createReadStream(file.path),
        };
        s3.upload(params, function(err:any, data:any) {
            if (err) {
                return reject(err);
            }
            return resolve(data.Location);
        });    
});

const s3MultiplefileUpload = (files:any) => 
    new Promise( function(resolve, reject) {
        var multipalFils: any = [];   
        var index_Arr: number[] = [];
        for(let i=0;i < files.length; i++){
            index_Arr.push(i);
        }
        function cb(index:number,location:any){
            index_Arr.pop()
            multipalFils.push(location);
            if(index_Arr.length <= 0){
                resolve(multipalFils); 
            }
        }    
        for(let i=0;i < files.length; i++){
             const s3 = new AWS.S3({
                accessKeyId: process.env.AWS_ACCESS_KEY_ID,
                secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
            });   
            const params = {
                ACL: 'public-read',
                Bucket: process.env.AWS_S3_BUCKET_NAME,
                Key: files[i].filename, // File name you want to save as in S3
                Body: fs.createReadStream(files[i].path),
            };

            s3.upload(params, function(err:any, data:any) {
                if (err) {
                    return reject(err);
                }
                cb(i,data.Location);
            });    
        }   
});

module.exports = {
    s3fileUpload,
    s3MultiplefileUpload
}
