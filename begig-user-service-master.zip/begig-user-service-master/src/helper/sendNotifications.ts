const sendNotifications = (reciver_user_ids:any, message:any, meta_data:any) =>

    new Promise(function (resolve, reject) {
      var axios = require('axios');
     if(meta_data != ""){
       meta_data = meta_data;
     }else{
      meta_data = {};
     }

	var data = JSON.stringify({

		"app_id": "5d56589e-c581-448e-8a1b-8a58234c2f93",

		"include_external_user_ids": reciver_user_ids,

		"channel_for_external_user_ids": "push",

		"data": meta_data,

		"contents": {

		"en": message

		}

	});

      var config = {
        method: 'post',
        url: 'https://onesignal.com/api/v1/notifications',
        headers: {
          'Authorization': 'Basic ODQwZDg0M2EtZTgyMy00NTgwLThhZjQtYmQ4YWI3NjY0ODk4',
          'Content-Type': 'application/json'
        },
        data : data
      };

      axios(config).then(function (response:any) {console.log("response :- " +response);
        resolve(true);
      }).catch(function (error:any) {console.log("error :- " +error);
        resolve(false);
      });
});

exports.sendNotifications = sendNotifications;
