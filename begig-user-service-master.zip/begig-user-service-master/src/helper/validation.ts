const {check,body} = require('express-validator');


const employerSingnupValidation = () => {    
    return [  
        check('email', "Please provide a valid email address").isEmail().trim(),
        check('password', 'Please enter at least 6 characters').isLength({ min: 6}).trim(),
        check('first_name','More than one letter required').isLength({ min: 2}).matches(/^[A-Za-z\s]+$/).withMessage('Please enter only alphabets').custom((value: any)  => !/\s/.test(value)).withMessage('No space allowed'),
        check('last_name', 'More than one letter required').trim().isLength({ min: 2}).matches(/^[A-Za-z\s]+$/).withMessage('Please enter only alphabets').custom((value: any)  => !/\s/.test(value)).withMessage('No space allowed'),
        check('company_name', 'Please provide a valid company name').isLength({ min: 1})
    ]           
}

const freelancerSingnupValidation = () => {    
    return [  
        check('email', "Please provide a valid email address").isEmail().trim(),
        check('password', 'Please enter at least 6 characters').isLength({ min: 6}).trim(),
        check('first_name','More than one letter required').isLength({ min: 2}).matches(/^[A-Za-z\s]+$/).withMessage('Please enter only alphabets').custom((value: any)  => !/\s/.test(value)).withMessage('No space allowed'),
        check('last_name', 'More than one letter required').trim().isLength({ min: 2}).matches(/^[A-Za-z\s]+$/).withMessage('Please enter only alphabets').custom((value: any)  => !/\s/.test(value)).withMessage('No space allowed'),
        check('exprience', 'Exprience is required').not().isEmpty()
    ]           
}

const loginValidation = () => {    
    return [  
        check('email', "Please enter valid email address").trim().isEmail(),
        check('password', 'Invalid email or password').trim().isLength({ min: 6})
    ]            
}

const socialMediaUrlValidtion = () => {    
    return [  
        check('url', "Must be Url type").isURL(),
        check('type').isIn(['github', 'linkedin', 'other']).trim().withMessage('Type must be github,linkedin,other'),    
    ]           
}

const experienceValidation = () => {       
    return [                   
        body('expriences.*.designation','Designation is required').trim().not().isEmpty(),
        body('expriences.*.job_type','Job type is required').trim().not().isEmpty(),
        body('expriences.*.description','Description is required').trim().not().isEmpty() 
    ]           
}

const educationsValidation = () => {       
    return [                   
        body('educations.*.institution_name').trim().not().isEmpty().isString(),
        body('educations.*.start_date','Start date is required').trim().not().isEmpty(),
        body('educations.*.educationQualificationsId','Education Qualifications is required').trim().not().isEmpty(),
    ]           
}

const skillsValidation = () => {                        
    return [                   
        body('skills.*.skill','skill is required').not().isEmpty().isString(),
        body('skills.*.experience_in_month','Experience is required').not().isEmpty().isNumeric().withMessage('Experience must be number')
    ]           
}

const basicDetailValidation = () => {    
    return [     
        check('country','Please provide the country name').not().isEmpty(),
        check('english_proficiency','Please provide your language proficiency').not().isEmpty(),
        check('city','Please provide city name').not().isEmpty(),
        check('about_me','Please provide about me').not().isEmpty(),
        check('mobile_number','Mobile number is required').not().isEmpty().isNumeric()
        .withMessage('Mobile number must be number type'),
        check('freelancing_type','Please provide your freelancing type').not().isEmpty(), 
        check('rate_per_hour','Please provide your Rats is required').not().isEmpty().isNumeric()
        .withMessage('Rats per hour must be number type').custom((note:any) => note >= 1).withMessage('Rats should be greater than zero'),  
        check('availibity','Please provide your availibity').not().isEmpty()
    ]           
}

module.exports = {
    employerSingnupValidation,
    freelancerSingnupValidation,
    loginValidation,
    socialMediaUrlValidtion,
    experienceValidation,
    basicDetailValidation,
    educationsValidation,
    skillsValidation
}

