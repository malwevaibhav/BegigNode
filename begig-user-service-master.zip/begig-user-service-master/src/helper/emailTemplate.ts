const emailTemplate = 'Some very important secret.'

export { emailTemplate }