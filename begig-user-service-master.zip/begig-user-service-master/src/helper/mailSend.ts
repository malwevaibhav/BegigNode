var nodemailer = require('nodemailer');

const mailSendFunction = (reciver_address:any, message:any, subject:any,cc_address:any) =>

    new Promise(function (resolve, reject) {
      console.log();
        var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: process.env.SMTP_EMAIL,
              pass: process.env.SMTP_PASSWORD
            }
          });
          var mailOptions:any;
          if(cc_address == "" || cc_address == undefined){
             mailOptions = {
              from: 'no-reply@begig.io',
              to: reciver_address,
              subject: subject,
              html: message
            };
          }else{
            mailOptions = {
              from: 'no-reply@begig.io',
              to: reciver_address,
              cc:cc_address,
              subject: subject,
              html: message
            };
          }

        transporter.sendMail(mailOptions, function(error:any, info:any){
            if(error) {
              resolve(false);
            } else {
              resolve(true);
            }
        });

});

exports.mailSendFunction = mailSendFunction;
