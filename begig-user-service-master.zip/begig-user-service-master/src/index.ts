if (!process.env.ALREADY_SET) { require('dotenv').config(); }

import * as http from 'http';
import { app } from './app';
import { DatabaseService } from './services/databaseService';
import { AuthService } from './services/AuthService';
import { Logger } from './lib/logger';
var cron = require('node-cron');
// Composition root

const logger: any = new Logger();

DatabaseService.getConnection().then(() => {
  const server = http.createServer(app).listen(parseInt(process.env.PORT || '3000', 10));
    server.on('listening', async () => {
      logger.log('info', `Sample app listening on ${JSON.stringify(server.address())}`);
      const service = new AuthService();
      setTimeout(function(){
        service.createZohoToken();
      }, 10000);
      cron.schedule('* */55 * * * *', () => {
        service.createZohoToken();
      });      
    });
  logger.log('info', `Sample app listening on ${JSON.stringify(server.address())}`);
})
