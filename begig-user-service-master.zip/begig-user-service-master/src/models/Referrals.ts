import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {User} from "./User";

@Entity('referrals')
export class Referrals {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @OneToOne(() => User)
    @JoinColumn()
    public user!: User;

    @Column("varchar", { length: 255 })
    public targer_email!: string;

    @Column("varchar", { length: 255 })
    public referral_code!: string;

    // 0 = fl, 1 = employer
    @Column({type: "tinyint", default: 0 })
    public type!: number;
     
    // 0 = pending, 1 = joined
    @Column({type: "tinyint", default: 0 })
    public status!: number;

    @Column({type :"bigint", default: 0 })
    public referred_at!: number;

}