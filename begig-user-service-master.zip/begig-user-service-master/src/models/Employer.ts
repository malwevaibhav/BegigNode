import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {User} from "./User";
import {Company} from "./Company";

@Entity('employer')
export class Employer {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @OneToOne(() => User)
    @JoinColumn()
    public user!: User;

    @ManyToOne(() => Company)
    @JoinColumn()
    public company!: Company;

    @Column("varchar", { length: 255 })
    public location!: string;

    @Column("varchar", { length: 255 , default: ""})
    public city!: string;

    @Column("varchar", { length: 255 , default: ""})
    public country!: string;

    @Column("varchar", { length: 255 , default: ""})
    public complete_address!: string;
    
    // 0 = residence, 1 = tax residence
    @Column({type: "tinyint", default: 0 })
    public tax_residence!: number;

    @Column("varchar", { length: 255 , default: ""})
    public state!: string;

    @Column({type :"int" , default: 0  })
    public pin_code!: number;

    // 0 = company super admin, 1 = company admin
    @Column({type: "tinyint", default: 0 })
    public type!: number;

  

}