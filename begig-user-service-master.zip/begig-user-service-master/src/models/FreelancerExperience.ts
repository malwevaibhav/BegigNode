import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {Freelancer} from "./Freelancer";

@Entity('freelancer_experience')
export class FreelancerExperience {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column({type :"int" })
    public freelancerId!: number;

    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancerExperience) 
    public freelancer!: Freelancer;

    @Column("varchar", { length: 255 })
    public designation!: string;

    @Column("varchar", { length: 255 })
    public company_name!: string;

    @Column("varchar", { length: 255 })
    public start_date!: string;

    @Column("varchar", { length: 255 })
    public end_date!: string;
    
    // 0 = present , 1 = not present
    @Column({type: "tinyint"})
    public present_company!: number;
  
    @Column({type :"int" })
    public total_exp_in_month!: number;

    @Column("varchar", { length: 255 })
    public job_type!: string;
   
    @Column("text")
    public description!: string;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @Column({type:"bigint", default:0 })
    public updated_at!: number;


}