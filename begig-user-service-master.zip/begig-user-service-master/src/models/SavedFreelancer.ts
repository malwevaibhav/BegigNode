import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity('saved_freelancer')
export class SavedFreelancer {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column({type: "int"})
    public fl_id!: number;
 
    @Column({type: "int"})
    public employer_id!: number;

    @Column({type: "int"})
    public gig_id!: number;
    
    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public match_score!: number;

    @Column({type :"bigint", default: 0 })
    public saved_on!: number;

}