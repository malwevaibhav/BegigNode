import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';


@Entity('company')
export class Company {

  @PrimaryGeneratedColumn({ type: "int" })
  public id!: number;

  @Column("varchar", { length: 255 })
  public company_name!: string;

  @Column("varchar", { length: 255 })
  public location!: string;
   
  @Column("varchar", { length: 255 , default: ""})
  public complete_address!: string;

  @Column({type :"int" , default: 0  })
  public pin_code!: number;

  @Column("varchar", { length: 255 , default: ""})
  public city!: string;

  @Column("varchar", { length: 255 , default: ""})
  public state!: string;

  @Column("varchar", { length: 255 , default: ""})
  public country!: string;
 
  @Column("varchar", { length: 255 , default: "" })
  public gst_tin!: string;
  
  @Column("varchar", { length: 255 , default: "" })
  public gst_tin_url!: string;

  @Column("varchar", { length: 255, default: ""})
  public msme_number!: string;

  @Column("varchar", { length: 255 , default: "" })
  public msme_number_url!: string;
  
  @Column("varchar", { length: 255,  default: ""})
  public company_pan_number!: string;

  @Column("varchar", { length: 255 , default: "" })
  public company_pan_url!: string;

  @Column("varchar", { length: 255, default: "" })
  public company_reg_number!: string;

  @Column("varchar", { length: 255 , default: "" })
  public company_reg_url!: string;

  @Column({type :"int" })
  public created_by!: number;

  @Column({type :"int" })
  public updated_by!: number;

  @Column({type:"bigint", default: 0 })
  public created_at!: number;

  @Column({type:"bigint", default:0 })
  public updated_at!: number;

  @Column({type:"tinyint", default:0 })
  public is_deleted!: number;

  @Column({type:"bigint", default:0 })
  public zoho_enterprise_id!: number;
    
}