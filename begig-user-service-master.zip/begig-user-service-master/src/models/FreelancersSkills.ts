import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {Freelancer} from "./Freelancer";

@Entity('freelancers_skills')
export class FreelancersSkills {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;
    
    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancersSkills) 
    public freelancer!: Freelancer;

    @Column("varchar", { length: 255 , default: ""  })
    public skill!: string;

    @Column({type :"int" })
    public experience_in_month!: number;

    @Column({type :"int" })
    public created_by!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @Column({type:"bigint", default:0 })
    public updated_at!: number;

}