import {
  Column,
  Entity,
  JoinTable,
  ManyToMany,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Freelancer } from './Freelancer';
import { User } from './User';

@Entity('freelancer_feedback')
export class FreelancerFeedback {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column({type :"int" })
    public userId!: number;

    @Column({type :"int" })
    public fl_id!: number;

    @Column({type:"bigint" })
    public gig_id!: number;

    @Column({type :"int" , default: 0})
    public work_quality!: number;

    @Column({type :"int" , default: 0})
    public work_ethics!: number;

    @Column({type :"int" , default: 0 })
    public skill_knowledge!: number;

    @Column({type :"int" , default: 0 })
    public response_rates!: number;

    @Column({type :"int" , default: 0 })
    public delievry_response!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public average_rating!: number;

    @Column("varchar", { length: 255 })
    public feedback!: string;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancerFeedback)
    public freelancer!: Freelancer;

    @ManyToOne(() => User, user => user.freelancerFeedback)
    public user!: User;

}
