import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn
} from 'typeorm';
import {Freelancer} from "./Freelancer";

@Entity('freelancer_bank_details')
export class FreelancerBankDetails {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column("varchar", { length: 255 , default: "" })
    public bank_full_name!: string;

    @Column("varchar", { length: 255 , default: "" })
    public bank_account_number!: string;

    @Column("varchar", { length: 255 , default: "" })
    public ifsc_code!: string;

    @Column("varchar", { length: 255 , default: "" })
    public branch_name!: string;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;
 
    @Column({type :"int" })
    public created_by!: number;

    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancerBankDetails) 
    public freelancer!: Freelancer;

}
