import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {Freelancer} from "./Freelancer";
import {EducationQualifications} from "./EducationQualifications";

@Entity('freelancers_educations')
export class FreelancersEducations {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;
    
    @Column({type :"int" })
    public freelancerId!: number;

    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancersEducations) 
    public freelancer!: Freelancer;

    @ManyToOne(() => EducationQualifications, educationQualifications => educationQualifications.freelancersEducations) 
    public educationQualifications!: EducationQualifications;

    @Column({type :"int" })
    public educationQualificationsId!: number;

    @Column("varchar", { length: 255 })
    public specializaion!: string;

    @Column("varchar", { length: 255 })
    public institution_name!: string;
   
    @Column("varchar", { length: 255 })
    public start_date!: string;

    @Column("varchar", { length: 255 })
    public end_date!: string;

    // 0 = present , 1 = not studying
    @Column({type: "tinyint"})
    public currently_studying!: number; 
    
    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @Column({type:"bigint", default:0 })
    public updated_at!: number;


}