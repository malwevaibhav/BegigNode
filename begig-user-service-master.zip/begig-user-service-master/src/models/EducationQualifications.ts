import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Freelancer } from './Freelancer';
import { FreelancersEducations } from './FreelancerEducations';

@Entity('education_qualifications')
export class EducationQualifications{

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column("varchar", { length: 255 })
    public title!: string;

    @Column({type :"int" })
    public added_by!: number;

    @Column({type :"int"})
    public updated_by!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @Column({type:"bigint", default:0 })
    public updated_at!: number;

    @OneToMany(() => FreelancersEducations, freelancersEducations => freelancersEducations.educationQualifications) 
    public freelancersEducations!: FreelancersEducations[];

    @ManyToMany(() => Freelancer, freelancer => freelancer.educationQualifications)
    public freelancers!: Freelancer[];

}