 import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Freelancer } from './Freelancer';

import { FreelancerFeedback } from './FreelancerFeedback';
import { UserMeta } from './UserMeta';

@Entity('user')
export class User {
  @PrimaryGeneratedColumn()
  public id!: number;

  @Column("varchar", { length: 255 })
  public first_name!: string;

  @Column("varchar", { length: 255 })
  public last_name!: string;

  @Column("varchar", { length: 255 })
  public email!: string;

  //@Column("varchar", { length: 255, default: "123" })
  @Column({type: "varchar", length: 255, default: ""})
  public mobile_no!: string;

  @Column("varchar", { length: 255 })
  public password!: string;

  @Column("varchar", { length: 255 , default: "" })
  public profile_pic!: string;

  @Column("varchar", { length: 255, default: "" })
  public referral_code!: string;

  @Column("varchar", { length: 255, default: "" })
  public socail_id!: string;

  @Column("varchar", { length: 255, default: "" })
  public social_id_type!: string;

  @Column("varchar", { length: 255, default: "" })
  public otp!: string;

  @Column({type: "bigint"})
  public otp_expire_time!: number;

  @Column("varchar", { length: 255, default: "" })
  public resetToken!: string;

  @Column("varchar", { length: 255, default: "" })
  public temp_email!: string;

  @Column({type: "bigint", default: 0})
  public resetPasswordExpires!: number;

  @Column({type: "tinyint", default: 1 })
  public is_login_first_time!: number;

  //0 = fl, 1 = employer, 2 = begig admin, 3 = begig super admin
  @Column({type: "tinyint", default: 0 })
  public role!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
  public average_rating!: number;

  @Column({type: "tinyint" , default: 0})
  public is_deleted!: number;

  //0 = otp verification pending, 1 = profile verified and activated, 2 = temporary blocked, 3 = incomplete profile , 4 = profile verification pending and inactivated
  @Column({type: "tinyint" , default: 0})
  public status!: number;

  // 0 = no step is completed, 1,2,3... these steps are completed and rest are pending
  @Column({type: "tinyint" , default: 0})
  public steps_completed!: number;

  @Column("varchar", { length: 255, default: "" })
  public razorpay_customer_id!: string;

  @Column("varchar", { length: 255, default: "" })
  public razorpay_account_number!: string;

  @Column("varchar", { length: 255, default: "" })
  public razorpay_bank_account_number!: string;

  @Column("varchar", { length: 255, default: "" })
  public razorpay_ifsc_code!: string;

  @Column("varchar", { length: 255, default: "" })
  public razorpay_bank_account_name!: string;

  @Column("varchar", { length: 255, default: "" })
  public razorpay_bank_name!: string;

  @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
  public current_balance!: number;

  @Column({type:"bigint", default: 0 })
  public created_at!: number;

  @Column({type:"bigint", default:0 })
  public updated_at!: number;

  @Column({type:"bigint", default: 0 })
  public approved_at!: number;

  @OneToMany(() => FreelancerFeedback, freelancerFeedback => freelancerFeedback.user)
  public freelancerFeedback!: FreelancerFeedback[];

  @OneToMany(() => UserMeta, userMeta => userMeta.user)
  public userMeta!: UserMeta[];

  @Column({type: "tinyint" , default: 0})
  public is_imported_from_wp!: number;

  @Column({type: "tinyint" , default: 0})
  public is_email_sent!: number;

   //employer zoho contact id also a zoho_id
   @Column({type:"bigint", default:0 })
   public zoho_user_id!: number;
  
   @Column({type:"bigint", default:0 })
   public zoho_enterprise_id!: number;

  

}
