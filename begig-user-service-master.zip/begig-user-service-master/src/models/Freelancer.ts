import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToMany,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn
} from 'typeorm';
import { EducationQualifications } from './EducationQualifications';
import { FreelancersEducations } from './FreelancerEducations';
import { FreelancerExperience } from './FreelancerExperience';
import { FreelancersSkills } from './FreelancersSkills';
import { FreelancerFeedback } from './FreelancerFeedback';

import {User} from "./User";
import { FreelancerAccomplishments } from './FreelancerAccomplishments';
import { FreelancerBankDetails } from './FreelancerBankDetails';
import { FreelancerBillingAddress } from './FreelancerBillingAddress';

@Entity('freelancer')
export class Freelancer {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @OneToOne(() => User)
    @JoinColumn()
    public user!: User;

    @Column("varchar", { length: 255 , default: ""  })
    public city!: string;

    @Column("varchar", { length: 255 , default: ""  })
    public country!: string;

    @Column("varchar", { length: 255 , default: "" })
    public freelancing_type!: string;
 
    @Column("varchar", { length: 255 , default: ""  })
    public english_proficiency!: string;

    @Column({ type: 'double', default: 0.00 })
    public rate_per_hour!: number;

    @Column("varchar", { length: 255 , default: ""  })
    public availibity!: string;

    @Column("varchar", { length: 255 })
    public exprience_slots!: string;
    
    @Column("text")
    public about_me!: string;

    @Column("varchar", { length: 255 , default: "" })
    public resume_url!: string;

    @Column("varchar", { length: 255 , default: "" })
    public linkedin_url!: string;
    
    @Column("varchar", { length: 255 , default: "" })
    public github_url!: string;

    @Column("varchar", { length: 255 , default: "" })
    public other_url!: string;

    // 0 = indian citizen, 1 = not indian citizen
    @Column({type: "tinyint", default: 0 })
    public indian_citizen!: number;

    @Column("varchar", { length: 255 , default: "" })
    public pan_number!: string;
    
    @Column("varchar", { length: 255 , default: "" })
    public gst_number!: string;
    
    @Column("varchar", { length: 255 , default: "" })
    public passport_number!: string;

    @Column({type :"int" , default: 0  })
    public total_experience_in_month!: number;

    @Column({type: "tinyint", default: 0 })
    public is_kyc_verified!: number;

    @Column({type :"int", default: 0 })
    public ongoing_gigs!: number;

    @Column({type :"int", default: 0})
    public completed_gigs!: number;

    @Column({type :"int", default: 0 })
    public cancelled_gigs!: number;
    
    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public total_earning!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public avaliable_balance!: number;

    // freelancer education 
    @OneToMany(() => FreelancersEducations, freelancersEducations => freelancersEducations.freelancer) 
    public freelancersEducations!: FreelancersEducations[];

    @ManyToMany(() => EducationQualifications, educationQualifications => educationQualifications.freelancers)
    public educationQualifications!: EducationQualifications[];

    // freelancer experience 
    @OneToMany(() => FreelancerExperience, freelancerExperience => freelancerExperience.freelancer) 
    public freelancerExperience!: FreelancerExperience[];
 
    // freelancer skills
    @OneToMany(() => FreelancersSkills, freelancersSkills => freelancersSkills.freelancer) 
    public freelancersSkills!: FreelancersSkills[];

    //freelancer accomplishments
    @OneToMany(() => FreelancerAccomplishments, freelancerAccomplishments => freelancerAccomplishments.freelancer) 
    public freelancerAccomplishments!: FreelancerAccomplishments[];

    //freelancer feedback
    @OneToMany(() => FreelancerFeedback, freelancerFeedback => freelancerFeedback.freelancer)
    public freelancerFeedback!: FreelancerFeedback[];

    //freelancer bank details
    @OneToMany(() => FreelancerBankDetails, freelancerBankDetails => freelancerBankDetails.freelancer)
    public freelancerBankDetails!: FreelancerBankDetails[];

    //freelancer biling address
    @OneToMany(() => FreelancerBillingAddress, freelancerBillingAddress => freelancerBillingAddress.freelancer)
    public freelancerBillingAddress!: FreelancerBillingAddress[];

}