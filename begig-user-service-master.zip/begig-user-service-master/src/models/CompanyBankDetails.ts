import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn
} from 'typeorm';
import { Company } from './Company';

@Entity('company_bank_details')
export class CompanyBankDetails {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;
    
    @OneToOne(() => Company)
    @JoinColumn()
    public company!: Company;

    @Column("varchar", { length: 255 })
    public full_name!: string;

    @Column("varchar", { length: 255 })
    public bank_account_number!: string;

    @Column("varchar", { length: 255 })
    public ifsc_code!: string;

    @Column("varchar", { length: 255 })
    public branch_name!: string;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;
 
    @Column({type :"int" })
    public created_by!: number;

}