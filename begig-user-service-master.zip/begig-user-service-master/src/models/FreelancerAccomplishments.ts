import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {Freelancer} from "./Freelancer";
 
@Entity('freelancers_accomplishments')
export class FreelancerAccomplishments {
 
    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;
    
    @Column({type :"int" })
    public freelancerId!: number;
 
    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancerAccomplishments) 
    public freelancer!: Freelancer;
 
    @Column("varchar", { length: 255 })
    public name_of_license!: string;
 
    @Column("varchar", { length: 255 })
    public organisation_name!: string;
 
    @Column("varchar", { length: 255 })
    public url!: string;
   
    @Column("varchar", { length: 255 })
    public start_date!: string;

    @Column("varchar", { length: 255 })
    public end_date!: string;
 
    // 0 = certificate/license expire , 1 = certificate/license not expire
    @Column({type: "tinyint"})
    public license_staus!: number;
    
    @Column({type:"bigint", default: 0 })
    public created_at!: number;
 
    @Column({type:"bigint", default:0 })
    public updated_at!: number;
 
}