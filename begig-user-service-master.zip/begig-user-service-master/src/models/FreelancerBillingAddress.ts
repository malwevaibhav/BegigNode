
import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn
} from 'typeorm';
import {Freelancer} from "./Freelancer";

@Entity('freelancer_billing_address')
export class FreelancerBillingAddress {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column("varchar", { length: 255 , default: "" })
    public complete_address!: string;

    @Column("varchar", { length: 255 , default: "" })
    public pin_code!: string;

    @Column("varchar", { length: 255 , default: "" })
    public city!: string;

    @Column("varchar", { length: 255 , default: "" })
    public state!: number;

    @Column("varchar", { length: 255 , default: "" })
    public country!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;
 
    @Column({type :"int" })
    public created_by!: number;
 
    @ManyToOne(() => Freelancer, freelancer => freelancer.freelancerBillingAddress) 
    public freelancer!: Freelancer;

}