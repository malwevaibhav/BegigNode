import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import {User} from "./User";

@Entity('notifications')
export class Notifications {

    @PrimaryGeneratedColumn({ type: "int" })
    public id!: number;

    @Column({type: "int", default: 0 })
    public user_id!: number;

    @Column("varchar", { length: 255 })
    public message!: string;

    @Column("varchar", { length: 255 })
    public meta_data!: string;

    // 0 = pending, 1 = joined
    @Column({type: "tinyint", default: 0 })
    public is_read!: number;

    @Column({type :"bigint", default: 0 })
    public send_on!: number;

}
