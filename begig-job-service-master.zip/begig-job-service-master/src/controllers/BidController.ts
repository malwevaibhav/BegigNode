import { Request, response, Response } from 'express';
import { BidService } from '../services/BidService';
import { JobsService } from '../services/JobsService';
const jobsService = new JobsService();
const bidService = new BidService();

class BidController{

  public static sendBid = async(req:any,res:Response,next:any) => {
    if (!req.body.gig_id) {
      return res.status(400).json({message: "Gig id must be number"})
    }
    let result = await bidService.sendBid(req.body,req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Bid sent successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"You already bidded on this gig."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static bidListFL = async (req:any, res:Response, next:any) => {
    let result = await bidService.bidListFL(req.body,req.user,req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({message:"success",data:result.data});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No record found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static bidsListAdmin = async (req:any, res:Response, next:any) => {
    let result = await bidService.bidsListAdmin(req.body,req.user,req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({message:"success",data:result.data});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No record found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static acceptBidAdmin = async (req:any,res:Response,next:any) => {
    let result = await bidService.acceptBidAdmin(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Bid accepted."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"Milestone suggestion required from freelancer"});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static acceptBidFL = async (req:any,res:Response,next:any) => {
    let result = await bidService.acceptBidFL(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Bid accepted."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid  id."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"final offer required."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static sendFinalOffer = async (req:any,res:Response,next:any) => {
    let result = await bidService.sendFinalOffer(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Final offer send successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Final offer already send."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"Invalid Bid Id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static rejectBidFL = async (req:any,res:Response,next:any) => {
    let result = await bidService.rejectBidFL(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Bid rejected."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static rejectBidAdmin = async (req:any,res:Response,next:any) => {
    let result = await bidService.rejectBidAdmin(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Invitation rejected."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

}

export default BidController;
