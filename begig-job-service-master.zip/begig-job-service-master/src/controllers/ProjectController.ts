
import { Request, Response } from 'express';
import { ProjectService } from '../services/ProjectService';
const projectsService = new ProjectService();
class ProjectController {

    public static addProject = async (req:any,res:Response,next:any) => {
        if(req.body.title == ""){
            return res.status(400).json({message:"Title is required."});
        }
        if(req.user.role != 1){
            return res.status(403).json({message:"You are not authorize to access this content."});
        }else{
            let result = await projectsService.addProject(req.body,req.user);
            if(result.statuscode == 200){
                return res.status(200).json({project:result.projectData, message:"Project created successfully."});
            }else{
                return res.status(500).json({message:"Something went wrong."});
            }
        }
    }

    public static updateProject = async (req:any, res:Response,next:any) => {
        if(req.body.title == ""){
            return res.status(400).json({message:"Title is required."});
        }
        if(req.user.role != 1){
            return res.status(403).json({message:"You are not authorize to access this content."});
        }else{
            let result = await projectsService.updateProject(req.body,req.params.project_id,req.user);
            if(result.statuscode == 200){
                return res.status(200).json({message:"Project updated successfully."});
            }else if(result.statuscode == 201){
                return res.status(200).json({message:"Invalid Project id."});
            }else{
                return res.status(500).json({message:"Something went wrong."});
            }
        }
    }

    public static projectList = async (req:any,res:Response,next:any) => {
        let result = await projectsService.projectList(req.body, req.user);
        if(result.statuscode == 200){
          return res.status(200).json({list: result.data,message:"Project list by user id."});
        }else if(result.statuscode == 201){
          return res.status(201).json({message:"No data found."});
        }else{
          return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static draftedGigsList = async (req:any,res:Response,next:any) => {
      let result = await projectsService.draftedGigsList(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data,message:"Project list by user id."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
    }

    public static freelancerReviewList = async (req:any,res:Response,next:any) => {
        let result = await projectsService.freelancerReviewList(req.params.project_id,req.headers);
        if(result.statuscode == 200){
          return res.status(200).json({list: result.data,message:"Freelancer review list."});
        }else if(result.statuscode == 201){
          return res.status(201).json({message:"No data found."});
        }else{
          return res.status(500).json({message:"Something went wrong."});
        }
    }
    

}

export default ProjectController;
