import { Request, response, Response } from 'express';
import { InvitationService } from '../services/InvitationService';
import { JobsService } from '../services/JobsService';
const {check, validationResult } = require('express-validator');
const jobsService = new JobsService();
const inviteService = new InvitationService();
class JobController {

  static getAllDesignation(arg0: string, varifyToken: any, getAllDesignation: any) {
      throw new Error('Method not implemented.');
  }

  public static getAllGigs = async (req:any,res:Response,next:any) => {
    if (!req.body.project_id) {
      return res.status(400).json({message: "Project id is required."})
    }
    if (typeof(req.body.project_id) !== 'number') {
      return res.status(400).json({message: "Project id must be number."})
    }
    let result = await jobsService.getallgigs(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Gigs list."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static gigsdetails = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigdetails(req.body,req.params.id,req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data ,message:"Gig details."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static gigdetailsSuperAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigdetailsSuperAdmin(req.body,req.params.id,req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data ,message:"Gig details."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static gigdetailsWithFlDetails = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigdetailsWithFlDetails(req.body,req.params.id,req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data ,message:"Gig details."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static updateGigStatus = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigUpdateStatus(req.body,req.params.id, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Gig approved."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static rejectGigApproveReq = async (req:any,res:Response,next:any) => {
    let result = await jobsService.rejectGigApproveReq(req.body,req.params.id, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Gig request rejected."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static getUnapprovedGigs = async (req:any,res:Response,next:any) => {
    let result = await jobsService.listOfUnapprovedGigs(req.body, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"Unapproved gigs list."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static listOfOpenGigsForSuperAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.listOfOpenGigsForSuperAdmin(req.body, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"Open gigs list"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static listOfOngoingGigsForSuperAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.listOfOngoingGigsForSuperAdmin(req.body, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"Ongoing gigs list"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static listOfOverDueGigsForSuperAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.listOfOverDueGigsForSuperAdmin(req.body, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"OverDue gigs list"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static listOfClosedGigsForSuperAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.listOfClosedGigsForSuperAdmin(req.body, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"Closed gigs list"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static listOfAllGigsForSuperAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.listOfAllGigsForSuperAdmin(req.body, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"All gigs list"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static addGigs = async (req:any,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await jobsService.gigsAdd(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Gig added successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static editGigs = async (req:any,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await jobsService.gigsEdit(req.body,req.params.id, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Gig edited successfully."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static addGigsDraft = async (req:any,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await jobsService.addGigsDraft(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Drafted Gig added successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static editGigsDraft = async (req:any,res:Response,next:any) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json(({errors: errors.array()}));
    }
    let result = await jobsService.editGigsDraft(req.body,req.params.id, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Drafted Gig edited successfully."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static deleteGigsDraft = async (req:any,res:Response,next:any) => {
    let result = await jobsService.deleteGigsDraft(req.body,req.params.id,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Drafted Gig deleted successfully."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid Drafted Gig id."});
      }else{
        return res.status(500).json({message:"Something went wrong"});
    }
  }


  public static attachments = async (req:any,res:Response,next:any) => {
    if (!req.body.gigid) {
      return res.status(400).json({message: "Gig id is required."})
    }
    let result = await jobsService.attachmentsByGigId(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Attachment added."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static deleteAttachments = async(req:any,res:Response,next:any) => {
    let result = await jobsService.deleteAttachment(req.body,req.params.id,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Attachment deleted successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid attachment id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }


  public static unapprovedGigs = async (req:any,res:Response,next:any) => {
    if (!req.body.project_id) {
      return res.status(400).json({message: "Project id is required."})
    }
    if (typeof(req.body.project_id) !== 'number') {
      return res.status(400).json({message: "Project id must be number."})
    }
    let result = await jobsService.getAllUnapprovedGigsByProjectId(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Unapproved gigs list."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static draftedGigs = async (req:any,res:Response,next:any) => {
    if (!req.body.project_id) {
      return res.status(400).json({message: "Project id is required."})
    }
    if (typeof(req.body.project_id) !== 'number') {
      return res.status(400).json({message: "Project id must be number."})
    }
    let result = await jobsService.getAllDraftGigsByProjectId(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Drafted gigs list by project id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }


  public static deleteGigs = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigDelete(req.body,req.params.id,req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Gig deleted successfully."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid gig id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static draftedGigslistByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getAllDraftGigsByUserId(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Drafted gigs list by user id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static unapprovedGigslistByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getAllUnapprovedGigsByUserId(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Unapproved gigs list."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static openGigslist = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getallopenGigslist(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Gigs list."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static getallopenGigslistForSearch = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getallopenGigslistForSearch(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Gigs list."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }


  public static openGigslistByProject = async (req:any,res:Response,next:any) => {
    let result = await jobsService.openGigslistByProject(req.params.project_id, req.user, req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Gigs list."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid project id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }


  public static unapprovedGigslistByProject = async (req:any,res:Response,next:any) => {
    let result = await jobsService.unapprovedGigslistByProject(req.params.project_id, req.user, req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({list: result.data ,message:"Unapproved list."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid project id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }


  public static getDashboardStatusCountAdmin = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getDashboardStatusCountAdmin(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({count: result.data ,message:"Gigs count."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static superAdminGigsCount = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getSuperAdminGigsCount(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({count: result.data ,message:"Gigs count."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }


  public static gigsdetailsFL = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigdetailsFL(req.body,req.params.id, req.user,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data ,message:"Gig details."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static superAdminFeedback = async (req:any,res:Response,next:any) => {
    let result = await jobsService.superAdminFeedbackToGig(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Review added successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }


  /////////////////////////////New API 09-08-2021//////////////////////////////////

  //get ongoing gigs by user id
  public static onGoingGigByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.GigOnGoingByUserId(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Ongoing gigs."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static onGoingGigByUserIdFL = async (req:any,res:Response,next:any) => {
    let result = await jobsService.GigOnGoingByUserIdFL(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Ongoing gigs."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static GigClosedByUserIdFL = async (req:any,res:Response,next:any) => {
    let result = await jobsService.GigClosedByUserIdFL(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Ongoing gigs."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }



  //////////////////////////////////////////////////////////////////////////////////////////////////

  //get overdue gigs by project id
  public static overdueGigByProjectId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.overdueGigByProjectId(req.params.project_id, req.user, req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({details: result.data ,message:"Gigs details by project id."});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
    }else{
        return res.status(500).json({message:"Something went wrong"});
    }
  }

  //get overdue gigs by user id
  public static overdueGigByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.overdueGigByUserId(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Overdue gigs."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  //
  public static completedGigByProjectId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.completedGigByProjectId(req.params.project_id, req.user, req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({details: result.data ,message:"Gigs details by project id."});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }
  
  //get completed gigs by user id
  public static completedGigByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.completedGigByUserId(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Completed gigs."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  //get completed gigs by user id for freelancer
  public static completedGigByUserIdFL = async (req:any,res:Response,next:any) => {
    let result = await jobsService.completedGigByUserIdFL(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Completed gigs."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }


  // 42 - Get all MileStones for ongoging gigs for admin
  public static ongogingMileStonesByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.ongogingMileStonesByUserId(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Ongoing milestones by user id."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  // 43 - Get all overdue MileStones for admin
  public static overdueMileStonesByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.overdueMileStonesByUserId(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Overdue milestones by user id."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }


  // 44 - Get all ontrack MileStones for admin
  public static ontrackMileStonesByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.ontrackMileStonesByUserId(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Ontrack milestones by user id."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  // 45 - Get all unapproved MileStones for admin
  public static unapprovedMileStonesByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.unapprovedMileStonesByUserId(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Unapproved milestones by user id."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  // 46 - Get all closed MileStones for admin
  public static closedMileStonesByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.closedMileStonesByUserId(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Closed milestones by user id."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  // 47 - Get all upcoming MileStones for admin
  public static upcomingMileStonesByUserId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.upcomingMileStonesByUserId(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({list: result.data,message:"Upcoming milestones by user id."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  //get ongoing gigs by project id
  public static onGoingGigByProjectId = async (req:any,res:Response,next:any) => {
      let result = await jobsService.GigsOnGoingByProjectId(req.params.project_id, req.user, req.headers);
      if(result.statuscode == 200){
          return res.status(200).json({details: result.data ,message:"Gigs details by project id."});
      }else if(result.statuscode == 201){
          return res.status(201).json({message:"No data found."});
      }else{
          return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static getHiredFlsIdByEmployerId = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getHiredFlsIdByEmployerId(req.body, req.user, req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({data: result.data ,message:"freelancers founds."});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static getUnreviewedFls = async (req:any,res:Response,next:any) => {
    let result = await jobsService.getUnreviewedFls(req.body, req.user, req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({data: result.data ,message:"freelancers founds."});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static updateCommisionStatus = async(req:any,res:Response,next:any) => {
    let result = await jobsService.updateCommisionStatus(req.user,req.params.gig_id);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Updated commision status."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid gig id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static adminBidAndInviteCount = async(req:any,res:Response,next:any) => {
    let result = await jobsService.adminBidAndInviteCount(req.user);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Bid and invitation count."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static updateGigsAndMilestonesPaymentStatus = async (req:any,res:Response,next:any) => {
    let result = await jobsService.updateGigsAndMilestonesPaymentStatus(req.body);
      if(result.statuscode == 200){
        return res.status(200).json({message:"updated successfully."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static reviewFls = async(req:any,res:Response,next:any) => {
    let result = await jobsService.reviewFls(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Reviewed to freelancer successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static openGigsFreelancersStatusCount = async(req:any,res:Response,next:any) => {
    let result = await jobsService.openGigsFreelancersStatusCount(req.body, req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"sucess."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static dashbaordMilestoneCountSuperAdmin = async(req:any,res:Response,next:any) => {
    let result = await jobsService.dashbaordMilestoneCountSuperAdmin(req.user);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"sucess."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  };

  public static dashboardMilestoneDetailsAdmin = async(req:any,res:Response,next:any) => {
    let result = await jobsService.dashboardMilestoneDetailsAdmin(req.user);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Milestone details."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static dashboardGigStatusCountFL = async(req:any,res:Response,next:any) => {
    let result = await jobsService.dashboardGigStatusCountFL(req.user);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Status Counts FL."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static dashboardMilestoneDetailsFL = async(req:any,res:Response,next:any) => {
    let result = await jobsService.dashboardMilestoneDetailsFL(req.user);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Milestone details."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static savedGigs = async (req:any,res:Response,next:any) => {
    if (!req.body.gig_id) {
      return res.status(400).json({message: "Gig id is required."})
    }
    if (!req.body.match_score) {
      return res.status(400).json({message: "Match score is required."})
    }
    let result = await jobsService.savedGigs(req.body, req.user);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Gig saved successfully."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Gig already added."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static savedGigsList = async (req:any,res:Response,next:any) => {
    let result = await jobsService.savedGigsList(req.user,req.body,req.headers);
      if(result.statuscode == 200){
        return res.status(200).json({data: result.data,message:"Gig saved list."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Gigs not found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static ingnoreSavedGigsList = async (req:any,res:Response,next:any) => {
    let result = await jobsService.ingnoreSavedGigsList(req.user,req.params.id);
      if(result.statuscode == 200){
        return res.status(200).json({message:"Gig deleted successfully."});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"Invalid id."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static gigsDetails = async (req:any,res:Response,next:any) => {
    let result = await jobsService.gigsDetails(req.body);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"Gigs details"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static similarGigsDetails = async (req:any,res:Response,next:any) => {
    let result = await jobsService.similarGigsDetails(req.body);
      if(result.statuscode == 200){
        return res.status(200).json({details: result.data , message:"Gigs details"});
      }else if(result.statuscode == 201){
        return res.status(201).json({message:"No data found."});
      }else{
        return res.status(500).json({message:"Something went wrong."});
      }
  }

  public static saerchGigs = async (req: any, res: Response, next: any) => {
    let usercode = await jobsService.saerchGigs(req.body);
    if( usercode.statuscode == 200){
      return res.status(200).json({freelancerData: usercode.data,message: "Search Gigs data"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found"})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static importGigs = async (req: any, res: Response, next: any) => {
    let usercode = await jobsService.importGigs();
    if( usercode.statuscode == 200){
      return res.status(200).json({freelancerData: usercode.data,message: "Search Gigs data"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found"})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }

  public static importBids = async (req: any, res: Response, next: any) => {
    let usercode = await jobsService.importBids();
    if( usercode.statuscode == 200){
      return res.status(200).json({freelancerData: usercode.data,message: "Search Gigs data"})
    }else if( usercode.statuscode == 201){
      return res.status(201).json({message: "Data not found"})
    }else{
      return res.status(500).json({message: "Something went wroung."});
    }
  }




}

export default JobController;
