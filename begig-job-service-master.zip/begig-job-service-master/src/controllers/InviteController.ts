import { Request, response, Response } from 'express';
import { InvitationService } from '../services/InvitationService';
import { JobsService } from '../services/JobsService';
const jobsService = new JobsService();
const inviteService = new InvitationService();
class InviteController {

  public static inviteFlToGigs = async(req:any,res:Response,next:any) => {
    if (!req.body.fl_id) {
      return res.status(400).json({message: "FL id is required"})
    }
    if (!req.body.gig_id) {
      return res.status(400).json({message: "Gig id must be number"})
    }
    let result = await inviteService.inviteFlToGigs(req.body,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Invitation sent successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"This freelancer is already invited."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static invitationListFL = async (req:any, res:Response, next:any) => {
    let result = await inviteService.invitationListFL(req.body,req.user,req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({message:"success",data:result.data});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No record found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static invitationListAdmin = async (req:any, res:Response, next:any) => {
    let result = await inviteService.invitationListAdmin(req.body,req.user,req.headers);
    if(result.statuscode == 200){
        return res.status(200).json({message:"success",data:result.data});
    }else if(result.statuscode == 201){
        return res.status(201).json({message:"No record found."});
    }else{
        return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static acceptInvitation = async (req:any,res:Response,next:any) => {
    let result = await inviteService.acceptInvitation(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Invitation accepted."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid  id."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"Milestone suggestion / final offer required."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static rejectInvitation = async (req:any,res:Response,next:any) => {
    let result = await inviteService.rejectInvitation(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Invitation rejected."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static milestoneSuggestionFL = async (req:any,res:Response,next:any) => {
    let result = await inviteService.milestoneSuggestionFL(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone suggested successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static editMilestoneSuggestion = async(req:any,res:Response,next:any) => {
    let result = await inviteService.editMilestoneSuggestion(req.body,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone suggestion updated successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static deleteMilestoneSuggestion = async(req:any,res:Response,next:any) => {
    let result = await inviteService.deleteMilestoneSuggestion(req.body,req.params.id,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone suggestion deleted successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid milestone id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static acceptInvitationAdmin = async (req:any,res:Response,next:any) => {
    let result = await inviteService.acceptInvitationAdmin(req.body, req.user,req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Invitation accepted."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"Milestone suggestion required from freelancer"});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static rejectInvitationAdmin = async (req:any,res:Response,next:any) => {
    let result = await inviteService.rejectInvitationAdmin(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Invitation rejected."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static sendFinalOffer = async (req:any,res:Response,next:any) => {
    let result = await inviteService.sendFinalOffer(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Final offer send successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Final offer already send."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }




}

export default InviteController;
