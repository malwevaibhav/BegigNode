import { Request, response, Response } from 'express';
import { MilestoneService } from '../services/MilestoneService';
import { JobsService } from '../services/JobsService';
const {check, validationResult } = require('express-validator');
const jobsService = new JobsService();
const milestoneService = new MilestoneService();
class MilestoneController {


  public static saveMilestones = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.saveMilestones(req.body,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestones created successfully.",new_gigs_id:result.new_gigs_id});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Freelancer number can not be more than freelancer required in gigs."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"Invalid gig id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static editMilestones = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.editMilestones(req.body,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestones updated successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid Gig Id."});
    }else if(result.statuscode == 202){
      return res.status(202).json({message:"Milestones can not be updated."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static deleteMilestones = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.deleteMilestones(req.body,req.params.id,req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone deleted successfully."});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid milestone id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static startMilestoneFl = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.startMilestoneFl(req.body);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone started successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static submitWorkOnMilestoneFl = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.submitWorkOnMilestoneFl(req.body, req.user);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Work submitted successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static reworkMilestoneAdmin = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.reworkMilestoneAdmin(req.body);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone mark to rework successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static completeMilestoneAdmin = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.completeMilestoneAdmin(req.body, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({message:"Milestone approved successfully."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static getMilestoneAttachments = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.getMilestoneAttachments(req.params.milestone_id);
    if(result.statuscode == 200){
      return res.status(200).json({attachments: result.data, message:"Milestone attachments"});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"Invalid milestone id."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static getAllMilestonesBySuperAdmin = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.getAllMilestonesBySuperAdmin(req.body,req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Milestones List"});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static getAllMilestonesByEmployerId = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.getAllMilestonesByEmployerId(req.body,req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Milestones List"});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

  public static getAllMilestonesByFlId = async(req:any,res:Response,next:any) => {
    let result = await milestoneService.getAllMilestonesByFlId(req.body,req.user, req.headers);
    if(result.statuscode == 200){
      return res.status(200).json({data: result.data, message:"Milestones List"});
    }else if(result.statuscode == 201){
      return res.status(201).json({message:"No data found."});
    }else{
      return res.status(500).json({message:"Something went wrong."});
    }
  }

}


export default MilestoneController;
