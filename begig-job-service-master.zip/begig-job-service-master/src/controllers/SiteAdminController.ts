import { Request, response, Response } from 'express';
import { SiteAdminService } from '../services/SiteAdminService';
const siteAdminService = new SiteAdminService();

class SiteAdminController {

    public static GetAllOpenGigCount = async (req: any, res: Response, next: any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.getAllOpenGigCount();
        if (result.statuscode == 200) {
            return res.status(200).json({ Count: result.data, message: "Open Gigs Count." });
        } else {
            return res.status(500).json({ message: "Something went wrong." });
        }
    }

    public static GetTotalHiredFreelancerCount = async (req: any, res: Response, next: any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.GetTotalHiredFreelancerCount();
        if (result.statuscode == 200) {
            return res.status(200).json({ Count: result.data, message: "Total Hired Freelancer Count." });
        } else {
            return res.status(500).json({ message: "Something went wrong." });
        }
    }

    public static GetAllOverDueGigs = async (req: any, res: Response, next: any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.GetAllOverDueGigs(req.params.skip , req.params.take);
        if (result.statuscode == 200) {
            return res.status(200).json({ OverdueGigsList: result.data, message: "Total OverDue Gigs." });
        } else {
            return res.status(500).json({ message: "Something went wrong." });
        }
    }

    public static getAllApprovedGigs = async (req: any, res: Response, next: any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.getAllApprovedGigs(req.params.skip , req.params.take);
        if (result.statuscode == 200) {
            return res.status(200).json({ ApproveGigList: result.data, message: "Total Approved Gigs." });
        } else {
            return res.status(500).json({ message: "Something went wrong." });
        }
    }

    public static hiredFreelancerList = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.hiredFreelancerList(req.body, req.headers);
        if(result.statuscode == 200){
          return res.status(200).json({list: result.data,message:"Hired freelancer list with gigs."});
        }else if(result.statuscode == 201){
          return res.status(201).json({message:"Data not found."});
        }else{
          return res.status(500).json({message:"Something went wrong."});
        }
      }

    public static listOfOpenGigsForSiteAdmin = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.listOfOpenGigsForSiteAdmin(req.body,req.headers);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Open gigs list for site admin."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"Data not found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static arrayOfOpenGigCreatedBy = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.arrayOfOpenGigCreatedBy(req.body);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Array of open gig created_by."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static arrayOfOngoingGigCreatedBy = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.arrayOfOngoingGigCreatedBy(req.body);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Array of ongoing gig created_by."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static arrayOfDratedGigCreatedBy = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.arrayOfDratedGigCreatedBy(req.body);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Array of drafted gig created_by."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static freelancer_bid_View = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.freelancer_bid_View(req.body);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Array of freelancer_bid_View gig created_by."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static opneOrOngoingGigsView = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        if(req.body.user_id =="" || req.body.user_id == undefined){
            return res.status(403).json({success: false, message: 'Gig user id is required.'});
        }
        if(req.body.gig_type =="" || req.body.gig_type == undefined){
            return res.status(403).json({success: false, message: 'Gig type is required.'});
        }
        let result = await siteAdminService.opneOrOngoingGigsView(req.body,req.headers);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Open or ongoing gigs view."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static draftedGigsView = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        if(req.body.user_id =="" || req.body.user_id == undefined){
            return res.status(403).json({success: false, message: 'Gig user id is required.'});
        }
        let result = await siteAdminService.draftedGigsView(req.body);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Drafted gigs view."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static freelancerBidedViews = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        if(req.body.fl_id =="" || req.body.fl_id == undefined){
            return res.status(403).json({success: false, message: 'Gig user id is required.'});
        }
        let result = await siteAdminService.freelancerBidedViews(req.body,req.headers);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Freelancer bided view."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static openGiglistForSiteAdmin = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.openGiglistForSiteAdmin(req.body,req.headers);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Open gigs list for site admin."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static openGiglistBidCountView = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.openGiglistBidCountView(req.body,req.headers);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Open gigs list bid count view and bided data"});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static hiredFeelancerList = async (req:any,res:Response,next:any) => {
        if(req.user.role !=2 && req.user.role !=3){
            return res.status(403).json({success: false, message: 'You dont have to permission to access'})
        }
        let result = await siteAdminService.hiredFeelancerList(req.body);
        if(result.statuscode == 200){
            return res.status(200).json({details: result.data , message:"Hired freelacer list."});
        }else if(result.statuscode == 201){
            return res.status(201).json({message:"No data found."});
        }else{
            return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static siteAdminGigsPostedCount = async(req:any,res:Response,next:any) => {
        let result = await siteAdminService.siteAdminGigsPostedCount();
        if(result.statuscode == 200){
          return res.status(200).json({data: result.data, message:"Gigs post count."});
        }else{
          return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static clientCreatedGigsCount = async(req:any,res:Response,next:any) => {
        let result = await siteAdminService.clientCreatedGigsCount(req.body);
        if(result.statuscode == 200){
          return res.status(200).json({data: result.data, message:"Client create gigs count."});
        }else{
          return res.status(500).json({message:"Something went wrong."});
        }
    }

    public static freelancerBiddedCount = async(req:any,res:Response,next:any) => {
        let result = await siteAdminService.freelancerBiddedCount(req.body);
        if(result.statuscode == 200){
          return res.status(200).json({data: result.data, message:"Freelancer bidded count."});
        }else{
          return res.status(500).json({message:"Something went wrong."});
        }
    }

    

}

export default SiteAdminController;
