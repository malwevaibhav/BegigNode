import { Request, Response, Router } from 'express';
import jobs from './jobs';

const routes = Router();

routes.use('/v1/jobs', jobs);

export { routes };
