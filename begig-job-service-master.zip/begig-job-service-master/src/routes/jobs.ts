import { Router } from 'express';
import JobController from '../controllers/JobController';
import projectController from '../controllers/ProjectController';
import inviteController from '../controllers/InviteController';
import milestoneController from '../controllers/MilestoneController';
import biddingController from '../controllers/BidController';
import SiteAdminController from '../controllers/SiteAdminController';

const { addGigValidation, editGigValidation,addMilestonesValidation, addDraftGigValidation,editMilestonesValidation} = require('../helper/validation.ts');

const varifyToken = require('../helper/varifyToken');
const router = Router();

// 1 - Create project
router.post('/project/add', varifyToken,projectController.addProject);

// 2 - Update project
router.put('/project/update/:project_id',varifyToken, projectController.updateProject);

// 3 - Get all gigs
router.post('/project/gigs/list', varifyToken, JobController.getAllGigs);

// 4 - Get gigs details without freelancer for admin
router.get('/gigdetails/withoutfl/:id',varifyToken, JobController.gigsdetails);

// 4 - Get gigs details for super admin
router.get('/superadmin/gigdetails/:id',varifyToken, JobController.gigdetailsSuperAdmin);

// 4 - Get gigs details with freelancer for admin
router.get('/gigdetails/withfl/:id',varifyToken, JobController.gigdetailsWithFlDetails);

// 5 - Get unaproved gigs
router.post('/project/gigs/unapproved',varifyToken, JobController.unapprovedGigs);

// 6 - Get Draft gigs
router.post('/project/gigs/drafted',varifyToken, JobController.draftedGigs);

// 7 - Update status
router.put('/gig/status/update/:id', varifyToken, JobController.updateGigStatus);

// 7 - Reject gig approval request
router.put('/gig/status/reject/:id', varifyToken, JobController.rejectGigApproveReq);


// 8 - Get unaproved gigs for super admin
router.post('/unapproved/gigs',varifyToken, JobController.getUnapprovedGigs);


// 8 - Get open gigs for super admin
router.post('/superamdin/open/gigs',varifyToken, JobController.listOfOpenGigsForSuperAdmin);

// 8 - Get ongoing gigs for super admin
router.post('/superamdin/ongoing/gigs',varifyToken, JobController.listOfOngoingGigsForSuperAdmin);

// 8 - Get overdue gigs for super admin
router.post('/superamdin/overdue/gigs',varifyToken, JobController.listOfOverDueGigsForSuperAdmin);

// 8 - Get closed gigs for super admin
router.post('/superamdin/closed/gigs',varifyToken, JobController.listOfClosedGigsForSuperAdmin);

// 8 - Get all gigs for super admin
router.post('/superamdin/all/gigs',varifyToken, JobController.listOfAllGigsForSuperAdmin);



// 9 - Add gigs
router.post('/add/gigs',varifyToken, addGigValidation(), JobController.addGigs);

// 10 - Edit gigs
router.put('/edit/gigs/:id', varifyToken, editGigValidation(), JobController.editGigs);

// 10.1 - Add gigs draft
router.post('/add/draft/gigs', varifyToken, addDraftGigValidation(), JobController.addGigsDraft);

// 10.2 - Edit gigs draft
router.put('/edit/draft/gigs/:id', varifyToken, addDraftGigValidation(), JobController.editGigsDraft);

// 10.3 - Delete gigs draft
router.delete('/delete/draft/gigs/:id', varifyToken, JobController.deleteGigsDraft);

// 11 - Add attachments
router.post('/gigs/attachments/add', varifyToken, JobController.attachments);

// 12 - Delete attachments
router.delete('/gigs/attachments/delete/:id', varifyToken, JobController.deleteAttachments);


// 13 - Delete gigs
router.delete('/delete/gigs/:id', varifyToken, JobController.deleteGigs);

// 14 - All the drafted gigs list by userId
router.post('/gigs/drafted/list', varifyToken, JobController.draftedGigslistByUserId);

// 15 - Give all the unapproved gigs list by userId
router.post('/gigs/unapproved/list', varifyToken, JobController.unapprovedGigslistByUserId);


// 17 - API for status counter on dashboard on admin
router.get('/admin/dashboard/status/count',varifyToken, JobController.getDashboardStatusCountAdmin);


// 18 - API for super admin gigs count
router.get('/super/admin/gigs/count',varifyToken, JobController.superAdminGigsCount);

// 19 - create milestones
router.post('/gigs/milestones/add', varifyToken, addMilestonesValidation(), milestoneController.saveMilestones);

// 20 - delete milestones
router.delete('/gigs/milestone/delete/:id', varifyToken, milestoneController.deleteMilestones);

// 21 - edit milestones
router.put('/gigs/milestones/edit', varifyToken, editMilestonesValidation(),  milestoneController.editMilestones);

// 22 - Invite on Gigs
router.post('/gigs/invitation/sent',varifyToken, inviteController.inviteFlToGigs);

// 23 - Get gigs details FL View
router.get('/fl/View/gig/:id', varifyToken, JobController.gigsdetailsFL);

// 24 - get invitation list for freelancer
router.post('/fl/invitations',varifyToken, inviteController.invitationListFL);

// 25 - get admin gig invitations
router.post('/admin/gig/invitations',varifyToken, inviteController.invitationListAdmin);

// 26 - Super admin add review in gig
router.put('/super/admin/feedback',varifyToken, JobController.superAdminFeedback);

// 27 - Fl accept the gig invitaion
router.put('/fl/invite/accept',varifyToken, inviteController.acceptInvitation);

// 28 - Fl reject the gig invitaion
router.put('/fl/invite/reject',varifyToken, inviteController.rejectInvitation);




// 30 - Freelancer suggestion milstone to admin
router.post('/fl/milestone/suggestion',varifyToken, inviteController.milestoneSuggestionFL);


// Send final offer invite
router.post('/admin/invite/finaloffer/send',varifyToken, inviteController.sendFinalOffer);

// 32 - Edit milestone suggestion by fl
router.put('/fl/milestone/suggestion/edit',varifyToken, inviteController.editMilestoneSuggestion);

// 33 - delete milestones Suggestion
router.delete('/fl/mileston/suggestion/delete/:id', varifyToken, inviteController.deleteMilestoneSuggestion);


// 34 - Admin accept the fl offer from invite
router.put('/admin/invite/offer/accept',varifyToken, inviteController.acceptInvitationAdmin);

// 35 - Admin reject the freelancer offer from invitation
router.put('/admin/invite/offer/reject',varifyToken, inviteController.rejectInvitationAdmin);


/////////////////////////////New API 09-08-2021//////////////////////////////////

// 36 - Get ongoing gigs by project id  //JobController
router.get('/ongoing/gigs/:project_id',varifyToken, JobController.onGoingGigByProjectId);



// 36 - get hired freelancer id by employer id
router.get('/hired/freelancers/list',varifyToken, JobController.getHiredFlsIdByEmployerId);

// 36 - get list of unreviewed freelancer who completed the gigs
router.post('/unreviewed/freelancers/list',varifyToken, JobController.getUnreviewedFls);

// 37 - Get ongoing gigs by user id
router.post('/ongoing/gigs',varifyToken, JobController.onGoingGigByUserId);


// 37 - Get ongoing gigs by user id FL
router.post('/fl/ongoing/gigs',varifyToken, JobController.onGoingGigByUserIdFL);


// 37 - Get closed gigs by user id FL
router.post('/fl/closed/gigs',varifyToken, JobController.GigClosedByUserIdFL);

// 38 - Get overdue gigs by project id
router.get('/overdue/gigs/:project_id',varifyToken, JobController.overdueGigByProjectId);

// 39 - Get overdue gigs by user id
router.post('/overdue/gigs',varifyToken, JobController.overdueGigByUserId);

// 40 - List of completed gig by project id
router.get('/completed/gigs/:project_id',varifyToken, JobController.completedGigByProjectId);

// 41 - Get completed gigs by user id
router.post('/completed/gigs',varifyToken, JobController.completedGigByUserId);

// 41 - Get completed gigs by user id freelancer
router.post('/fl/completed/gigs',varifyToken, JobController.completedGigByUserIdFL);

// 16 - list of open gigs (which is approved but no FL is hired **status = 1)
router.post('/gigs/open/list', varifyToken, JobController.openGigslist);

// 16 - list of open gigs (which is approved but no FL is hired **status = 1)
router.post('/gigs/open/list/search', varifyToken, JobController.getallopenGigslistForSearch);

// 16 - list of open gigs by project id(which is approved but no FL is hired **status = 1)
router.get('/gigs/open/list/:project_id',varifyToken, JobController.openGigslistByProject);

// 16 - list of unapproved gigs by project id
router.get('/gigs/unapproved/list/:project_id',varifyToken, JobController.unapprovedGigslistByProject);


// project list by user id
router.post('/project/list/',varifyToken, projectController.projectList);

// drafted project list by user id
router.post('/project/list/drafted', varifyToken, projectController.draftedGigsList);

// update the payment status of gigs or milestones
router.post('/update/gigs/milestone/payment/status', JobController.updateGigsAndMilestonesPaymentStatus);

// 42 - Get all MileStones for ongoging gigs for admin
router.get('/ongoging/mileStones/', JobController.ongogingMileStonesByUserId);

// 43 - Get all overdue MileStones for admin
router.get('/overdue/mileStones/', JobController.overdueMileStonesByUserId);

// 44 - Get all onTrack MileStones for admin
router.get('/ontrack/mileStones/', JobController.ontrackMileStonesByUserId);

// 45 - Get all unapproved MileStones for admin
router.get('/unapproved/mileStones/', JobController.unapprovedMileStonesByUserId);

// 46 - Get all closed MileStones for admin
router.get('/closed/mileStones/', JobController.closedMileStonesByUserId);

// 47 - Get all upcoming MileStones for admin
router.get('/upcoming/mileStones/', JobController.upcomingMileStonesByUserId);


/*********** Bidding Routes Starts ***********/

router.post('/gigs/bid/sent',varifyToken, biddingController.sendBid);


// get bidding list for freelancers
router.post('/fl/bids',varifyToken, biddingController.bidListFL);

// getting the list of bidding for admin
router.post('/admin/bids',varifyToken, biddingController.bidsListAdmin);

// freelancers accepts the final offer sent by admin in bidding section
router.put('/fl/accept/bid/finaloffer',varifyToken, biddingController.acceptBidFL);

// freelancer reject the final offer sent by admin in bidding section
router.put('/fl/bid/reject',varifyToken, biddingController.rejectBidFL);

// admin Send final offer in bidding section
router.post('/admin/bid/finaloffer/send',varifyToken, biddingController.sendFinalOffer);

// admin accepts the fls bid
router.put('/admin/bid/offer/accept',varifyToken, biddingController.acceptBidAdmin);

// admin rejects the fls bids
router.put('/admin/bid/offer/reject',varifyToken, biddingController.rejectBidAdmin);

// update gig commision status
router.put('/gig/commision/status/update/:gig_id',varifyToken, JobController.updateCommisionStatus);

/*********** Bidding Roites Ends   ***********/

// 06-10-2021
// Gig milestone start by freelacer
router.put('/fl/gig/milestone/start',varifyToken, milestoneController.startMilestoneFl);

// freelancer milestone work submit
router.post('/fl/gig/milestone/work/submit',varifyToken, milestoneController.submitWorkOnMilestoneFl);

// admin milestone rework
router.put('/admin/gig/milestone/rework',varifyToken, milestoneController.reworkMilestoneAdmin);

// admin approve milestone
router.put('/admin/gig/milestone/approve',varifyToken, milestoneController.completeMilestoneAdmin);

// Get milestone attachments
router.get('/milestone/attachments/:milestone_id',varifyToken, milestoneController.getMilestoneAttachments);

// get all milestones by employer id
router.post('/admin/milestones/list',varifyToken, milestoneController.getAllMilestonesByEmployerId);

// get all milestones by super admin
router.post('/superadmin/milestones/list',varifyToken, milestoneController.getAllMilestonesBySuperAdmin);

// get all milestones by freelancer id
router.post('/fl/milestones/list',varifyToken, milestoneController.getAllMilestonesByFlId);

//admin dashboard bid invitation count api
router.get('/admin/dashboard/bid-invitation/count',varifyToken, JobController.adminBidAndInviteCount);

//admin getting the freelances status on the popup for open gigs for admin
router.post('/admin/open/gigs/fls/status',varifyToken, JobController.openGigsFreelancersStatusCount);

//admin gives review to fls on completed gigs
router.post('/admin/reviewed/to/fls',varifyToken, JobController.reviewFls);

//super admin dashboard milestone count
router.get('/superadmin/dashboard/milestone/count',varifyToken, JobController.dashbaordMilestoneCountSuperAdmin);


//admin dashboard milestone details
router.get('/admin/dashboard/milestone/details',varifyToken, JobController.dashboardMilestoneDetailsAdmin);

//admin dashboard milestone details
router.get('/fl/dashboard/gigs/count',varifyToken, JobController.dashboardGigStatusCountFL);

//admin dashboard milestone details
router.get('/fl/dashboard/milestone/details',varifyToken, JobController.dashboardMilestoneDetailsFL);

//////////////////////////////////Saved gigs////////////////////////////////////////////////////////


router.post('/saved/gigs',varifyToken, JobController.savedGigs);

router.post('/get/saved/gigs/list',varifyToken, JobController.savedGigsList);

router.delete('/ignore/saved/gigslist/:id',varifyToken, JobController.ingnoreSavedGigsList);


/************Begig Site Admin Start********************/
router.get('/getAllOpenGigs',varifyToken, SiteAdminController.GetAllOpenGigCount);

router.get('/getTotalHiredFreelancer',varifyToken, SiteAdminController.GetTotalHiredFreelancerCount);

router.get('/getAllOverDueGigs/:skip/:take',varifyToken, SiteAdminController.GetAllOverDueGigs);

router.get('/getAllApprovedGigs/:skip/:take',varifyToken, SiteAdminController.getAllApprovedGigs);

/************Begig Site Admin Start********************/

// Get ongoing gigs by user id
router.post('/siteadmin/hired/freelancer/list',varifyToken, SiteAdminController.hiredFreelancerList);

// Open gigs for siteadmin
router.post('/siteadmin/opengigs',varifyToken, SiteAdminController.listOfOpenGigsForSiteAdmin);


///////////////////////////////////////////new site admin api///////////////////////////////////////////


// Api return open gigs owner id in array and gig count for site admin pannle, screen - client create gig
router.post('/open_gig/owner_id/array',varifyToken,  SiteAdminController.arrayOfOpenGigCreatedBy);

// Api return ongoing gigs owner id in array and gig count for site admin pannle, screen - client create gig
router.post('/ongoing_gigs/owner_id/array',varifyToken,  SiteAdminController.arrayOfOngoingGigCreatedBy);

// Api return drafted gigs owner id in array and gig count for site admin pannle, screen - client create gig
router.post('/drafted_gigs/owner_id/array',varifyToken,  SiteAdminController.arrayOfDratedGigCreatedBy);

router.post('/freelancer_bid/owner_id/array',varifyToken,  SiteAdminController.freelancer_bid_View);

// Client created open,ongoing gigs view (with filter of without fliter)
router.post('/client_created/open_or_ongoing/gigs_view',varifyToken,  SiteAdminController.opneOrOngoingGigsView);

// Client created drafted gigs view (with filter of without fliter)
router.post('/client_created/drafted/gigs_view',varifyToken,  SiteAdminController.draftedGigsView);

/// freelancer bid view (with filter of without fliter) freelancre bided count screen
router.post('/freelancer_bid/view',varifyToken,  SiteAdminController.freelancerBidedViews);

router.post('/siteadmin/hired_feelancer_list',varifyToken,  SiteAdminController.hiredFeelancerList);

//siteadmin opengig list its include count and sort and fileter (search by id and title also include)
router.post('/siteadmin/opengigs/list',varifyToken, SiteAdminController.openGiglistForSiteAdmin);

//siteadmin open gig list bid count and its bid detial api.
router.post('/siteadmin/opengigs/bid-count-view',varifyToken, SiteAdminController.openGiglistBidCountView);

// list of gigs for without login user and login user
router.post('/front_page/gigs/details', JobController.gigsDetails);

router.post('/front_page/similar/gigs/details', JobController.similarGigsDetails);

router.post('/freelancer/gigs/saerch', JobController.saerchGigs);

// admin closed project freelancer review list api
router.get('/closed/project/freelancer/reviewlist/:project_id',varifyToken, projectController.freelancerReviewList);

//siteadmin gigs posted count
router.get('/siteadmin/gigs/posted/count',varifyToken,  SiteAdminController.siteAdminGigsPostedCount);

//siteadmin client create gigs count
router.post('/siteadmin/client/created/gigs/count',varifyToken, SiteAdminController.clientCreatedGigsCount);

//siteadmin freelancer bidded count
router.post('/siteadmin/freelancer/bidded/count', SiteAdminController.freelancerBiddedCount);


// admin closed project freelancer review list api
router.get('/import/gigs', JobController.importGigs);

// admin closed project freelancer review list api
router.get('/import/bids', JobController.importBids);




export default router;
