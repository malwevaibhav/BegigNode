import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Projects } from './Projects';

@Entity('drafted_gigs')
export class DraftedGigs {
    
    @PrimaryGeneratedColumn()
    public id!: number;

    @Column({ type:"int" })
    public created_by!: number;
      
    @Column("text")
    public gigs_details_json!: string;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;
  
    //many to one
    @ManyToOne(() => Projects, projects => projects.gigs) 
    public projects!: Projects;

  
}