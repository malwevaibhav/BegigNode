import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';

@Entity('user_meta')
export class UserMeta {
  @PrimaryGeneratedColumn()
  public id!: number;

  @Column({type: "int" , default: 0})
  public user_id!: number;

  @Column({type: "int" , default: 0})
  public fl_id!: number;

  @Column({type: "int" , default: 0})
  public company_id!: number;

  @Column("varchar", { length: 255,default:"" })
  public meta_key!: string;

  @Column("varchar", { length: 255,default:"" })
  public meta_value!: string;

}
