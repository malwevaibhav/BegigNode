
import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { GigsInvitation } from './GigsInvitation';
import { GigsMilestones } from './GigsMilestones';
import { GigsSkills } from './GigsSkills';
import { GigsAttachments } from './GigsAttachments';
import { Projects } from './Projects';
import { SavedGigs } from './SavedGigs';

@Entity('gigs')
export class Gigs {

    @PrimaryGeneratedColumn()
    public id!: number;

    //many to one
    @ManyToOne(() => Projects, projects => projects.gigs)
    public projects!: Projects;

    @OneToMany(() => SavedGigs, saved_gigs => saved_gigs.gig) 
    public gig!: SavedGigs[];

    @Column({ type:"int",default: 0 })
    public fl_id!: number;

    @Column("varchar", { length: 255, default:"" })
    public super_admin_feedback!: string;

    @Column("varchar", { length: 255, default:"" })
    public freedback_updated_on!: string;

    @Column("varchar", { length: 255, default:"" })
    public jd_url!: string;

    //many to one
    @Column({ type:"bigint" })
    public project_id!: number;

    @Column({ type:"int" })
    public created_by!: number;

    @Column({ type:"int" })
    public updated_by!: number;

    //0 = fl_pm_required_for_breakdown_only , 1 =fl_pm_required_for_e2e_delivery , 2 = no_assistance_required , 4 = contract_hiring
    @Column({ type:"tinyint", default: 0 })
    public type!: number;

    @Column("varchar", { length: 255 })
    public title!: string;

    @Column("text")
    public description!: string;

    @OneToMany(() => GigsSkills, gigs_skill => gigs_skill.gigs)
    public gigs_skills!: GigsSkills[];

    @OneToMany(() => GigsAttachments, gigs_attachments => gigs_attachments.gigs)
    public gigs_attachments!: GigsAttachments[];

    @Column("varchar", { length: 255 })
    public designation!: string;

    @Column({type:"int" })
    public education_id!: number;

    @Column({type:"int" , default: 0 })
    public required_exerience!: number;

    @Column({type:"int" , default: 1 })
    public estimated_duration!: number;

    //0 = hours , 1 = days , 2 = weeks , 3 = months , 4 = years
    @Column({type:"tinyint", default: 0 })
    public duration_unit!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public estimated_budget!: number;

    //0 = fixed , 1 = time_and_material , 2 = open_for_discussion
    @Column({type:"int" })
    public payment_type!: number;

    //in case of payment type is time & material
    @Column({type:"int" , default: 0})
    public hours_per_week!: number;

    //in case of payment type is time & material
    @Column({type:"int",default: 0 })
    public rate_per_hour!: number;

    //only use for super admin to show total budget incase of multiple freelacre required
    @Column({type:"int",default: 0 })
    public total_budget!: number;

    @Column({type:"int",default: 1 })
    public no_fl_required!: number;

    @Column({type:"int",default: 0 })
    public fl_hired!: number;

    @Column("text")
    public fl_payment_meta!: string;

    //0 = pending , 1 = approved , 2 = freelancerhired , 3 = completed , 4 = dispute , 5 = deleted
    @Column({type:"tinyint", default: 0 })
    public status!: number;

    @Column({type:"tinyint", default: 0 })
    public is_review_given_to_fl!: number;

    @Column({type:"tinyint", default: 0 })
    public is_created_by_pm!: number;

    @Column({type:"bigint", default: 0 })
    public expected_closer!: number;

    @Column({type:"bigint", default: 0 })
    public is_commission_paid!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @Column({type:"bigint", default:0 })
    public updated_at!: number;

    //employer zoho contact id also a zoho_id
    @Column({type:"bigint", default:0 })
    public zoho_user_id!: number;

    @Column({type:"bigint", default:0 })
    public zoho_enterprise_id!: number;

    @Column({type:"bigint", default:0 })
    public zoho_gigs_id!: number;

    @Column({type:"bigint", default:0 })
    public completed_on!: number;

    @OneToMany(() => GigsMilestones, gigs_milestones => gigs_milestones.gigs)
    public gigs_milestones!: GigsMilestones[];

    @OneToMany(() => GigsInvitation, gigs_invitations => gigs_invitations.gigs)
    public gigs_invitations!: GigsInvitation[];

    @Column({type: "tinyint" , default: 0})
    public is_imported_from_wp!: number;

    @Column({type: "int" , default: 0})
    public wp_id!: number;


}
