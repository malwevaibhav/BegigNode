import {
    Column,
    CreateDateColumn,
    Entity,
    ManyToOne,
    PrimaryGeneratedColumn,
    Unique,
    UpdateDateColumn,
  } from 'typeorm';
import { GigsMilestones } from './GigsMilestones';
  
  @Entity('milestone_attachments')
  export class MilestoneAttachments {
  
      @PrimaryGeneratedColumn()
      public id!: number;
  
      @Column({ type:"int" })
      public created_by!: number;
  
      @ManyToOne(() => GigsMilestones, gigsMilestones => gigsMilestones.milestone_attachments) 
      public milestones!: GigsMilestones;
  
      @Column("varchar", { length: 255 })
      public attachment_url!: string;

      @Column("varchar", { length: 255 })
      public fileType!: string;
  
      @Column({type:"bigint", default: 0 })
      public created_at!: number;
  
  }