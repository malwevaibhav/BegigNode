import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Bids } from './Bids';
import { Gigs } from './Gigs';
import { GigsSkills } from './GigsSkills';
import { Projects } from './Projects';

@Entity('milestones_suggetions_bids')
export class BidMilestoneSuggetions {

    @PrimaryGeneratedColumn()
    public id!: number;

    @ManyToOne(() => Bids, bids => bids.milestone_suggetions)
    public bids!: Bids;

    @Column("varchar", { length: 255 })
    public title!: string;

    @Column({type:"int" })
    public gig_id!: number;

    @Column("text")
    public description!: string;

    @Column({type:"int" , default: 1 })
    public estimated_duration!: number;

    //0 = fixed , 1 = time_and_material
    @Column({type:"int" })
    public payment_type!: number;

    //0 = hours , 1 = days , 2 = weeks , 3 = months , 4 = years
    @Column({type:"tinyint", default: 0 })
    public duration_unit!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public estimated_budget!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

}
