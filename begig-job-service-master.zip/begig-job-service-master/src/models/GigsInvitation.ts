
import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { FinalOfferInvite } from './FinalOfferInvite';
import { Gigs } from './Gigs';
import { InvitationMilestoneSuggetions } from './InvitationMilestoneSuggetions';
import { InviteMilestoneSuggestionAdmin } from './InviteMilestoneSuggestionAdmin';

@Entity('invite_fl_for_gigs')
export class GigsInvitation {

    @PrimaryGeneratedColumn()
    public id!: number;

    @Column({ type:"int" })
    public fl_id!: number;

    @Column({ type:"int" })
    public invite_by!: number;

    @Column({ type:"bigint" })
    public invite_on!: number;

    @Column({ type:"text" })
    public message!: string;

    @ManyToOne(() => Gigs, gigs => gigs.gigs_invitations)
    public gigs!: Gigs;

    @Column({ type:"tinyint" , default: 0 })
    public is_sent_by_pm!: number;

    // 0 = pending , 1 = accepted , 2 = rejected
    @Column({ type:"tinyint", default: 0  })
    public status!: number;

    @Column({ type:"tinyint" , default: 0 })
    public is_final_offer_send!: number;

    @Column("varchar", { length: 255 , default: ""})
    public action_by!: string; //fl / admin

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public match_score!: number;

    @OneToMany(() => InvitationMilestoneSuggetions, invatation_milestones_suggetions => invatation_milestones_suggetions.gigs_invitation)
    public milestone_suggetions!: InvitationMilestoneSuggetions[];

    @OneToMany(() => InviteMilestoneSuggestionAdmin, invatation_milestones_suggetions_admin => invatation_milestones_suggetions_admin.gigs_invitation)
    public milestone_suggetions_admin!: InviteMilestoneSuggestionAdmin[];

    @OneToMany(() => FinalOfferInvite, final_offer => final_offer.gigs_invitation)
    public final_offer!: FinalOfferInvite[];

}
