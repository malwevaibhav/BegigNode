import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { BidMilestoneSuggetions } from './BidMilestoneSuggetions';
import { FinalOfferBids } from './FinalOfferBids';
import { Gigs } from './Gigs';

@Entity('bids')
export class Bids{

  @PrimaryGeneratedColumn()
  public id!: number;

  @Column({ type:"int" })
  public fl_id!: number;

  @Column({ type:"text" })
  public message!: string;

  @ManyToOne(() => Gigs, gigs => gigs.gigs_invitations)
  public gigs!: Gigs;

  // 0 = pending , 1 = accepted , 2 = rejected
  @Column({ type:"tinyint", default: 0  })
  public status!: number;

  @Column({ type:"bigint" })
  public bidded_on!: number;

  @Column({ type:"tinyint" , default: 0 })
  public is_final_offer_send!: number;

  @Column("varchar", { length: 255 , default: ""})
  public action_by!: string; //fl / admin

  @Column({type:"int" , default: 1 })
  public estimated_duration!: number;

  //0 = hours , 1 = days , 2 = weeks , 3 = months , 4 = years
  @Column({type:"tinyint", default: 0 })
  public duration_unit!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
  public estimated_budget!: number;

  //in case of payment type is time & material
  @Column({type:"int" , default: 0})
  public hours_per_week!: number;

  //in case of payment type is time & material
  @Column({type:"int",default: 0 })
  public rate_per_hour!: number;

  @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
  public match_score!: number;

  @OneToMany(() => BidMilestoneSuggetions, bid_milestones_suggetions => bid_milestones_suggetions.bids)
  public milestone_suggetions!: BidMilestoneSuggetions[];

  @OneToMany(() => FinalOfferBids, final_offer_bids => final_offer_bids.bids)
  public final_offer!: FinalOfferBids[];

}
