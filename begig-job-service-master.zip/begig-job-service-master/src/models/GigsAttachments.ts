import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Gigs } from './Gigs';

@Entity('gigs_attachments')
export class GigsAttachments {

    @PrimaryGeneratedColumn()
    public id!: number;

    @Column({ type:"int" })
    public created_by!: number;

    @ManyToOne(() => Gigs, gigs => gigs.gigs_attachments) 
    public gigs!: Gigs;

    @Column("varchar", { length: 255 })
    public attachment_url!: string;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

}