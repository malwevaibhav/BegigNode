import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToMany,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';

@Entity('gigs_meta')
export class GigsMeta {
  @PrimaryGeneratedColumn()
  public id!: number;

  @Column({type: "int" , default: 0})
  public gig_id!: number;

  @Column("varchar", { length: 255,default:"" })
  public meta_key!: string;

  @Column("varchar", { length: 255,default:"" })
  public meta_value!: string;

}
