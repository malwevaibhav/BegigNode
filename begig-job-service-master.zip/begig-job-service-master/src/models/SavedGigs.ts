import {
    Column,
    Entity,
    JoinColumn,
    ManyToOne,
    OneToOne,
    PrimaryGeneratedColumn
  } from 'typeorm';
  import { Gigs } from './Gigs';
  
  @Entity('saved_gigs')
  export class SavedGigs {
  
      @PrimaryGeneratedColumn({ type: "int" })
      public id!: number;
  
      @Column({type: "int"})
      public fl_id!: number;
  
      @ManyToOne(() => Gigs, gigs => gigs.gig)
      public gig!: Gigs;
      
      @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
      public match_score!: number;
  
      @Column({type :"bigint", default: 0 })
      public created_at!: number;
  
  }
  