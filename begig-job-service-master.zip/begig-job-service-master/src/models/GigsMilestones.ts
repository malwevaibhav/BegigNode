
import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Gigs } from './Gigs';
import { GigsSkills } from './GigsSkills';
import { MilestoneAttachments } from './MilestoneAttachments';
import { Projects } from './Projects';

@Entity('gigs_milestones')
export class GigsMilestones {

    @PrimaryGeneratedColumn()
    public id!: number;

    @ManyToOne(() => Gigs, gigs => gigs.gigs_milestones)
    public gigs!: Gigs;

    @Column({ type:"int" })
    public created_by!: number;

    @Column({ type:"int" })
    public updated_by!: number;

    @Column({type:"tinyint", default: 0 })
    public payment_done_by_admin!: number;

    @Column({type:"tinyint", default: 0 })
    public is_invoice_raised_by_fl!: number;

    @Column({type:"tinyint", default: 0 })
    public is_payment_done_to_fl!: number;

    @Column({type:"bigint", default:0 })
    public end_date!: number;

    @Column({type:"bigint", default: 0 })
    public start_date!: number;

    @Column("varchar", { length: 255 })
    public title!: string;

    @Column("text")
    public description!: string;

    @Column({type:"int" , default: 1 })
    public estimated_duration!: number;

    //0 = hours , 1 = days , 2 = weeks , 3 = months , 4 = years
    @Column({type:"tinyint", default: 0 })
    public duration_unit!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public estimated_budget!: number;

    //0 = pending , 1 = started , 2 = work submited , 3 = work approved /complete , 4 = rework, 5 = dispute , 6 = deleted
    @Column({type:"tinyint", default: 0 })
    public status!: number;

    @Column({type:"tinyint", default: 0 })
    public is_payment_paid_by_admin!: number;

    @Column({type:"tinyint", default: 0 })
    public is_payment_paid_to_fl!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

    @Column({type:"bigint", default:0 })
    public updated_at!: number;

    @OneToMany(() => MilestoneAttachments, milestone_attachments => milestone_attachments.milestones)
    public milestone_attachments!: MilestoneAttachments[];

    @Column({type: "tinyint" , default: 0})
    public is_imported_from_wp!: number;

    @Column({type: "int" , default: 0})
    public wp_id!: number;

    @Column({type:"bigint", default:0 })
    public zoho_milestones_id!: number;


}
