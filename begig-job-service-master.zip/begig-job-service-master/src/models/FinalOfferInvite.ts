import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Gigs } from './Gigs';
import { GigsInvitation } from './GigsInvitation';
import { GigsSkills } from './GigsSkills';
import { Projects } from './Projects';

@Entity('final_offer_invite')
export class FinalOfferInvite {

    @PrimaryGeneratedColumn()
    public id!: number;

    @ManyToOne(() => GigsInvitation, gigs_invitations => gigs_invitations.final_offer) 
    public gigs_invitation!: GigsInvitation;

    @Column("varchar", { length: 255 })
    public title!: string;

    @Column({type:"int" })
    public gig_id!: number;

    //0 = fixed , 1 = time_and_material 
    @Column({type:"int" })
    public payment_type!: number;
      
    @Column("text")
    public description!: string;

    @Column({type:"int" , default: 1 })
    public estimated_duration!: number;
    
    //0 = hours , 1 = days , 2 = weeks , 3 = months , 4 = years
    @Column({type:"tinyint", default: 0 })
    public duration_unit!: number;

    @Column({ type: 'decimal', precision: 10, scale: 2,default: 0.00 })
    public estimated_budget!: number;

    @Column({type:"bigint", default: 0 })
    public created_at!: number;

}