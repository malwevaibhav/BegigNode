import {
    Column,
    Entity,
    PrimaryGeneratedColumn,
  } from 'typeorm';
  
  @Entity('zohoinfo')
  export class ZohoInfo {
  
      @PrimaryGeneratedColumn({ type: "int" })
      public id!: number;
  
      @Column("varchar", { length: 255, default: "" })
      public accesstoken!: string;
  
      @Column({type :"bigint", default: 0 })
      public expire_time!: number;
  
  }