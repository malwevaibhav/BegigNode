
import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Gigs } from './Gigs';

@Entity('gigs_skills')
export class GigsSkills {

    @PrimaryGeneratedColumn()
    public id!: number;

    @ManyToOne(() => Gigs, gigs => gigs.gigs_skills) 
    public gigs!: Gigs;

    @Column("varchar", { length: 255, default:"" })
    public skills!: string;

}