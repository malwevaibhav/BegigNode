import { IsNotEmpty, Length } from 'class-validator';
import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { Gigs } from './Gigs';
import { DraftedGigs } from './DraftedGigs';

@Entity('projects')
export class Projects {
  @PrimaryGeneratedColumn()
  public id!: number;

  //one to many
  @Column("varchar", { length: 255 })
  public title!: string;

  @Column({type:"int", default: 0 })
  public company_id!: number;

  @Column({type:"int", default: 0 })
  public created_by!: number;
  
  @Column({type:"int", default: 0 })
  public updated_by!: number;
  
  //0 = pending , 1 = running , 2 = completed 
  @Column({type:"tinyint", default: 0 })
  public status!: number;
  
  @Column({type:"tinyint", default: 0 })
  public give_access_to_hired_pm!: number;

  @Column({type:"tinyint", default: 0 })
  public is_deleted!: number;

  @Column({type:"bigint", default: 0 })
  public created_at!: number;

  @Column({type:"bigint", default:0 })
  public updated_at!: number;

  //employer zoho contact id also a zoho_id
  @Column({type:"bigint", default:0 })
  public zoho_user_id!: number;

  @Column({type:"bigint", default:0 })
  public zoho_enterprise_id!: number;

  @Column({type:"bigint", default:0 })
  public zoho_project_id!: number;
  
  // Project gigs
  @OneToMany(() => Gigs, gigs => gigs.projects) 
  public gigs!: Gigs[];

  // DraftedGigs gigs
  @OneToMany(() => DraftedGigs, draftedGigs => draftedGigs.projects) 
  public draftedGigs!: DraftedGigs[];

}
