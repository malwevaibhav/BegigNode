import EventEmitter = require('events');
import { createConnection } from 'typeorm';
import config from '../config/config';
import { Logger } from '../lib/logger';
import { Projects } from '../models/Projects';
import { Gigs } from '../models/Gigs';
import { GigsSkills } from '../models/GigsSkills';
import { GigsMilestones } from '../models/GigsMilestones';
import { GigsInvitation } from '../models/GigsInvitation';
import { InvitationMilestoneSuggetions } from '../models/InvitationMilestoneSuggetions';
import { GigsAttachments } from '../models/GigsAttachments';
import { DraftedGigs } from '../models/DraftedGigs';
import { FinalOfferInvite } from '../models/FinalOfferInvite';
import { InviteMilestoneSuggestionAdmin } from '../models/InviteMilestoneSuggestionAdmin';
import { Bids } from '../models/Bids';
import { BidMilestoneSuggetions } from '../models/BidMilestoneSuggetions';
import { FinalOfferBids } from '../models/FinalOfferBids';
import { MilestoneAttachments } from '../models/MilestoneAttachments';
import { SavedGigs } from '../models/SavedGigs';
import { UserMeta } from '../models/UserMeta';
import { GigsMeta } from '../models/GigsMeta';
import { ZohoInfo } from '../models/ZohoInfo';


class DatabaseService {

  public static emitter: EventEmitter = new EventEmitter();
  public static isConnected = false;
  public static logger: any = new Logger();

  public static async getConnection(callback = null, wait = false) {
    DatabaseService.handleConnectionError();
    return await DatabaseService.createConnection();
  }

  public static async createConnection() {
    const dbConfig = config[`${process.env.ENV}`];
    return await createConnection({
      type: 'mysql',
      host: dbConfig.host,
      port: parseInt(dbConfig.port),
      username: dbConfig.username,
      password: dbConfig.password,
      database: dbConfig.database,
      entities: [
        Projects,Gigs,GigsSkills,GigsMilestones,GigsInvitation,InvitationMilestoneSuggetions,GigsAttachments,DraftedGigs,FinalOfferInvite,InviteMilestoneSuggestionAdmin,Bids,BidMilestoneSuggetions,FinalOfferBids,MilestoneAttachments,SavedGigs,UserMeta,GigsMeta,ZohoInfo
      ],
    }).then(() => {
      DatabaseService.isConnected = true;
      DatabaseService.logger.log('info', 'database connected successfully');
    }).catch((err: Error) => {
      console.log("database error " , err);
      DatabaseService.logger.log('info', 'database connection error...retrying');
      DatabaseService.emitter.emit('DB_CONNECT_ERROR');
    });
  }
  public static async handleConnectionError() {
    DatabaseService.emitter.on('DB_CONNECT_ERROR', async () => {
      DatabaseService.logger.log('info', 'database connection error...retrying');
      setTimeout(async () => {
        await DatabaseService.createConnection();
      }, 3000)
    });
  }
}

export { DatabaseService };
