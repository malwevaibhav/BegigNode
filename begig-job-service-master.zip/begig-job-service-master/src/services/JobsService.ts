import { Gigs } from "../models/Gigs";
import { Projects } from "../models/Projects";
import { Brackets, getManager } from 'typeorm';
import { getRepository, LessThan, MoreThan, MoreThanOrEqual, Not } from 'typeorm';
import { GigsSkills } from "../models/GigsSkills";
import { GigsMilestones } from "../models/GigsMilestones";
import { GigsAttachments } from "../models/GigsAttachments";
import { DraftedGigs } from "../models/DraftedGigs";
import { Bids } from "../models/Bids";
import { GigsInvitation } from "../models/GigsInvitation";
import { SavedGigs } from "../models/SavedGigs";
import { UserMeta } from "../models/UserMeta";
import e from "express";
import { ZohoInfo } from "../models/ZohoInfo";
import { updateRestTypeNode } from "typescript";
const {zohoCreateAccessToekn,createGigOnZoho,updateGigOnZoho} = require('../helper/zohoApi');
const axios = require('axios');
var bcrypt = require('bcryptjs');
require('dotenv').config()
const jwt = require('jsonwebtoken')
const util = require('util');
const fs = require('fs');
const {rollbar} = require('../helper/rollbar');

export class JobsService {

    async listOfUnapprovedGigs(body: any, user: any, token:any): Promise<any>{
        try{
          const page_number = body.page_number || 0;
          const number_of_record = body.number_of_record || 10;
          const gigsDetail : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .leftJoinAndSelect("gigs.projects", "projects")
          .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
          .where("gigs.status = 0")
          .andWhere("company_id ="+ user.company_id)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
          if(gigsDetail.length > 0){
            let id : any = [];
            for(let i=0;i<gigsDetail.length;i++){
                if(!id.includes(gigsDetail[i].created_by)){
                  id.push(gigsDetail[i].created_by);
                }
            }

            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';

            const json = JSON.stringify({"id": id});
            const res = await axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });

            for(let i=0;i<gigsDetail.length;i++){
                let gigId = gigsDetail[i].created_by;
                for(let j=0;j< res.data.userData.length;j++){
                    if(gigId == res.data.userData[j].user.id){
                        var admin : any = {
                            first_name : res.data.userData[j].user.first_name,
                            last_name : res.data.userData[j].user.last_name,
                            profile_pic : res.data.userData[j].user.profile_pic,
                            average_rating : res.data.userData[j].user.average_rating,
                            company_name : res.data.userData[j].company.company_name,
                            empId:res.data.userData[j].id
                        }
                        gigsDetail[i].admin = admin
                        break;
                    }
                }
            }
            return {statuscode:200,data:gigsDetail};
          }else{
            return {statuscode:201};
          }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async listOfOpenGigsForSuperAdmin(body: any, user: any, token:any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 5
            const gigsDetail : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .where("gigs.status = 1")
            .andWhere("company_id ="+ user.company_id)
            .limit(number_of_record)   // page number
            .offset(page_number * number_of_record)   // offset (from where we want to get record)
            .getMany();
            if(gigsDetail.length > 0){
              let id : any = [];
              for(let i=0;i<gigsDetail.length;i++){
                  if(!id.includes(gigsDetail[i].created_by)){
                    id.push(gigsDetail[i].created_by);
                  }
              }

              const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';

              const json = JSON.stringify({"id": id});
              const res = await axios.post(bigigUserUrl, json, {
                  headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `${token.authorization}`
                  }
              });

              for(let i=0;i<gigsDetail.length;i++){
                  let gigId = gigsDetail[i].created_by;
                  for(let j=0;j< res.data.userData.length;j++){
                      if(gigId == res.data.userData[j].user.id){
                          var admin : any = {
                              first_name : res.data.userData[j].user.first_name,
                              last_name : res.data.userData[j].user.last_name,
                              profile_pic : res.data.userData[j].user.profile_pic,
                              average_rating : res.data.userData[j].user.average_rating,
                              company_name : res.data.userData[j].company.company_name,
                          }
                          gigsDetail[i].admin = admin
                          break;
                      }
                  }
              }
              return {statuscode:200,data:gigsDetail};
            }else{
              return {statuscode:201};
            }

        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async listOfOngoingGigsForSuperAdmin(body: any, user: any, token:any): Promise<any>{
        try{
            var time = Date.now()/1000;
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 5
            const gigsDetail : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .where("gigs.status = 2")
            .andWhere("(gigs.expected_closer >= "+time+" OR gigs.expected_closer = 0)")
            .andWhere("company_id ="+ user.company_id)
            .limit(number_of_record)   // page number
            .offset(page_number * number_of_record)   // offset (from where we want to get record)
            .getMany();
            if(gigsDetail.length > 0){
              let id : any = [];
              for(let i=0;i<gigsDetail.length;i++){
                  if(!id.includes(gigsDetail[i].created_by)){
                    id.push(gigsDetail[i].created_by);
                  }
              }

              const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';

              const json = JSON.stringify({"id": id});
              const res = await axios.post(bigigUserUrl, json, {
                  headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `${token.authorization}`
                  }
              });

              for(let i=0;i<gigsDetail.length;i++){
                  let gigId = gigsDetail[i].created_by;
                  for(let j=0;j< res.data.userData.length;j++){
                      if(gigId == res.data.userData[j].user.id){
                          var admin : any = {
                              first_name : res.data.userData[j].user.first_name,
                              last_name : res.data.userData[j].user.last_name,
                              profile_pic : res.data.userData[j].user.profile_pic,
                              average_rating : res.data.userData[j].user.average_rating,
                              company_name : res.data.userData[j].company.company_name,
                          }
                          gigsDetail[i].admin = admin
                          break;
                      }
                  }
              }
              return {statuscode:200,data:gigsDetail};
            }else{
              return {statuscode:201};
            }

        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async listOfOverDueGigsForSuperAdmin(body: any, user: any, token:any): Promise<any>{
        try{
            var time = Date.now()/1000;
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 5
            const gigsDetail : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .where("gigs.status = 2 AND gigs.expected_closer < "+time+" AND gigs.expected_closer > 0")
            .andWhere("company_id ="+ user.company_id)
            .limit(number_of_record)   // page number
            .offset(page_number * number_of_record)   // offset (from where we want to get record)
            .getMany();
            if(gigsDetail.length > 0){
              let id : any = [];
              for(let i=0;i<gigsDetail.length;i++){
                  if(!id.includes(gigsDetail[i].created_by)){
                    id.push(gigsDetail[i].created_by);
                  }
              }

              const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';

              const json = JSON.stringify({"id": id});
              const res = await axios.post(bigigUserUrl, json, {
                  headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `${token.authorization}`
                  }
              });

              for(let i=0;i<gigsDetail.length;i++){
                  let gigId = gigsDetail[i].created_by;
                  for(let j=0;j< res.data.userData.length;j++){
                      if(gigId == res.data.userData[j].user.id){
                          var admin : any = {
                              first_name : res.data.userData[j].user.first_name,
                              last_name : res.data.userData[j].user.last_name,
                              profile_pic : res.data.userData[j].user.profile_pic,
                              average_rating : res.data.userData[j].user.average_rating,
                              company_name : res.data.userData[j].company.company_name,
                          }
                          gigsDetail[i].admin = admin
                          break;
                      }
                  }
              }
              return {statuscode:200,data:gigsDetail};
            }else{
              return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async listOfClosedGigsForSuperAdmin(body: any, user: any, token:any): Promise<any>{
        try{
          var time = Date.now()/1000;
          const page_number = body.page_number || 0
          const number_of_record = body.number_of_record || 5
          const gigsDetail : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .leftJoinAndSelect("gigs.projects", "projects")
          .where("gigs.status = 3")
          .andWhere("company_id ="+ user.company_id)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
          if(gigsDetail.length > 0){
            let id : any = [];
            for(let i=0;i<gigsDetail.length;i++){
                if(!id.includes(gigsDetail[i].created_by)){
                  id.push(gigsDetail[i].created_by);
                }
            }

            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';

            const json = JSON.stringify({"id": id});
            const res = await axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });

            for(let i=0;i<gigsDetail.length;i++){
                let gigId = gigsDetail[i].created_by;
                for(let j=0;j< res.data.userData.length;j++){
                    if(gigId == res.data.userData[j].user.id){
                        var admin : any = {
                            first_name : res.data.userData[j].user.first_name,
                            last_name : res.data.userData[j].user.last_name,
                            profile_pic : res.data.userData[j].user.profile_pic,
                            average_rating : res.data.userData[j].user.average_rating,
                            company_name : res.data.userData[j].company.company_name,
                        }
                        gigsDetail[i].admin = admin
                        break;
                    }
                }
            }
            return {statuscode:200,data:gigsDetail};
          }else{
            return {statuscode:201};
          }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async listOfAllGigsForSuperAdmin(body: any, user: any, token:any): Promise<any>{
        try{
          var time = Date.now()/1000;
          const page_number = body.page_number || 0
          const number_of_record = body.number_of_record || 5
          const gigsDetail : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .leftJoinAndSelect("gigs.projects", "projects")
          .where("gigs.status != 5")
          .andWhere("company_id ="+ user.company_id)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
          if(gigsDetail.length > 0){
            let id : any = [];
            for(let i=0;i<gigsDetail.length;i++){
                if(!id.includes(gigsDetail[i].created_by)){
                  id.push(gigsDetail[i].created_by);
                }
            }

            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';

            const json = JSON.stringify({"id": id});
            const res = await axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });

            for(let i=0;i<gigsDetail.length;i++){
                let gigId = gigsDetail[i].created_by;
                for(let j=0;j< res.data.userData.length;j++){
                    if(gigId == res.data.userData[j].user.id){
                        var admin : any = {
                            first_name : res.data.userData[j].user.first_name,
                            last_name : res.data.userData[j].user.last_name,
                            profile_pic : res.data.userData[j].user.profile_pic,
                            average_rating : res.data.userData[j].user.average_rating,
                            company_name : res.data.userData[j].company.company_name,
                        }
                        gigsDetail[i].admin = admin
                        break;
                    }
                }
            }
            return {statuscode:200,data:gigsDetail};
          }else{
            return {statuscode:201};
          }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async getallgigs(body: any, user: any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 10
            const gigsRepository = getRepository(Gigs);
            const gigs :any = await gigsRepository.find({ where: { project_id:body.project_id, status:Not(5)} , skip: page_number*number_of_record, take: number_of_record});
            return {statuscode:200,data:gigs};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getAllUnapprovedGigsByProjectId(body: any, user: any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 10
            const gigsRepository = getRepository(Gigs);
            const gigs : any = await gigsRepository.find({ where: { project_id:body.project_id, status : 0},relations:["gigs_attachments"], skip: page_number*number_of_record, take: number_of_record});
            return {statuscode:200,data:gigs};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getAllDraftGigsByProjectId(body: any, user: any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 10
            const draftedGigsRepository = getRepository(DraftedGigs);
            const gigs : any = await draftedGigsRepository.find({ where: { projects:body.project_id}, skip: page_number*number_of_record, take: number_of_record});
            var obj = [];
            for(let i =0; i< gigs.length; i++){
               obj[i] = JSON.parse(gigs[i].gigs_details_json);
               obj[i].id = gigs[i].id;
               obj[i].created_at = gigs[i].created_at;
            }
            return {statuscode:200,data:obj};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigdetails(body: any,  id: any, user: any,token :any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDetails : any = await gigsRepository.find({ where: { id: id}, relations:["gigs_skills", "gigs_attachments",'gigs_milestones'] });
            if(gigDetails.length>0){
                return {statuscode:200,data: gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigdetailsSuperAdmin(body: any,  id: any, user: any,token :any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDetails : any = await gigsRepository.find({ where: { id: id}, relations:["gigs_skills", "gigs_attachments",'gigs_milestones'] });
            const res = await axios.get(process.env.Begig_user_url+'api/v1/user/get/user/'+gigDetails[0].created_by , {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });
            var admin : any= {
                emp_id : res.data.userData[0].id,
                first_name : res.data.userData[0].user.first_name,
                last_name : res.data.userData[0].user.last_name,
                profile_pic : res.data.userData[0].user.profile_pic,
                average_rating : res.data.userData[0].user.average_rating,
                company_name : res.data.userData[0].company.company_name,
            }

            if(gigDetails.length>0){
                gigDetails[0].admin = admin
                return {statuscode:200,data: gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigdetailsWithFlDetails(body: any,  id: any, user: any,token :any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDetails : any = await gigsRepository.find({ where: { id: id}, relations:["gigs_skills", "gigs_attachments",'gigs_milestones'] });
            if(gigDetails[0].fl_id != 0){
                const json = JSON.stringify({"id": [gigDetails[0].fl_id]});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                var freelancer : any = {
                    first_name : res.data.freelancerData[0].user.first_name,
                    last_name : res.data.freelancerData[0].user.last_name,
                    profile_pic : res.data.freelancerData[0].user.profile_pic,
                    average_rating : res.data.freelancerData[0].user.average_rating,
                    freelancing_type : res.data.freelancerData[0].freelancing_type,
                    rate_per_hour : res.data.freelancerData[0].rate_per_hour,
                    availibity : res.data.freelancerData[0].availibity
                }
                if(gigDetails.length > 0){
                    gigDetails[0].freelancer = freelancer
                }
            }
            if(gigDetails.length>0){
                return {statuscode:200,data: gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }



    async gigUpdateStatus(body: any,  id: any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigsSkilsRepository = getRepository(GigsSkills);
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            const gigDetails = await gigsRepository.find({ where:{id: id } , relations:["gigs_skills", "gigs_attachments","projects"]});
            var created_by = gigDetails[0].created_by;
            if(gigDetails.length > 0){
                var fl_payment_meta = [];
                if(gigDetails[0].fl_payment_meta != ""){
                    fl_payment_meta = JSON.parse(gigDetails[0].fl_payment_meta);
                }
                if(gigDetails[0].no_fl_required > 0){
                    let res = [];
                    for(let i=0;i<fl_payment_meta.length;i++){
                        if(i == 0){
                            res.push([fl_payment_meta[i]]);
                        }else{
                            let index = -1;
                            for(let k = 0;k<res.length;k++){
                                if(res[k][0].estimated_budget == fl_payment_meta[i].estimated_budget){
                                    index = k;
                                    break;
                                }
                            }
                            if(index > -1){
                                res[index].push(fl_payment_meta[i]);
                            }else{
                                res.push([fl_payment_meta[i]]);
                            }
                        }
                    }
                    if(res.length > 0){
                        for(let i=0;i<res.length;i++){
                            if(i==0){
                                if(res[i].length == 1){
                                const statusUpdated = await gigsRepository.update({id: id },{status:1,    no_fl_required:1,
                                        estimated_duration:res[i][0].estimated_duration,
                                        duration_unit:res[i][0].duration_unit,
                                        estimated_budget:res[i][0].estimated_budget,
                                        rate_per_hour:res[i][0].rate_per_hour,
                                        hours_per_week:res[i][0].hours_per_week,
                                        total_budget:res[i][0].estimated_budget,
                                        fl_payment_meta:JSON.stringify(res[i])
                                     });
                                }else{
                                    let total_budget = 0;
                                    res[i].forEach((item, index) => {
                                       total_budget = total_budget+item.estimated_budget
                                    });
                                   const statusUpdated = await gigsRepository.update({id: id },{status:1, no_fl_required:res[i].length,estimated_budget:total_budget,total_budget:total_budget,fl_payment_meta:JSON.stringify(res[i])});
                                }
                            } else {
                                    let gigs = new Gigs()
                                    gigs.created_by = gigDetails[0].created_by;
                                    gigs.updated_by = gigDetails[0].updated_by;
                                    gigs.created_at = gigDetails[0].created_at;
                                    gigs.updated_at = gigDetails[0].updated_at;
                                    gigs.status = 1;
                                    gigs.project_id = gigDetails[0].project_id;
                                    gigs.projects = gigDetails[0].projects;
                                    gigs.type = gigDetails[0].type; //(0 = fl_pm_required_for_breakdown_only , 1 =fl_pm_required_for_e2e_delivery , 2 =no_assistance_required , 4 = contract_hiring)
                                    gigs.title = gigDetails[0].title;
                                    gigs.description = gigDetails[0].description;
                                    gigs.designation = gigDetails[0].designation;
                                    gigs.education_id = gigDetails[0].education_id;
                                    gigs.fl_hired = gigDetails[0].fl_hired;
                                    gigs.required_exerience = gigDetails[0].required_exerience;
                                    gigs.payment_type = gigDetails[0].payment_type; //(0 = fixed , 1 = time_and_material , 2=open_for_discussion)
                                    gigs.is_created_by_pm = gigDetails[0].is_created_by_pm;
                                    if(res[i].length == 1){
                                        gigs.no_fl_required = 1;
                                        gigs.fl_payment_meta = "";
                                        gigs.estimated_duration = res[i][0].estimated_duration;
                                        gigs.duration_unit = res[i][0].duration_unit;
                                        gigs.estimated_budget = res[i][0].estimated_budget;
                                        gigs.hours_per_week = res[i][0].hours_per_week;
                                        gigs.rate_per_hour = res[i][0].rate_per_hour;
                                        gigs.total_budget = res[i][0].estimated_budget;
                                    }else{
                                        let total_budget = 0;
                                        res[i].forEach((item, index) => {
                                        total_budget = total_budget+item.estimated_budget
                                        });
                                        gigs.no_fl_required = res[i].length;
                                        gigs.fl_payment_meta = JSON.stringify(res[i]);
                                        gigs.estimated_duration = res[i][0].estimated_duration;
                                        gigs.duration_unit = res[i][0].duration_unit;
                                        gigs.estimated_budget = res[i][0].estimated_budget;
                                        gigs.hours_per_week = res[i][0].hours_per_week;
                                        gigs.rate_per_hour = res[i][0].rate_per_hour;
                                        gigs.total_budget = total_budget;
                                    }
                                    let savedGigs = await gigsRepository.save(gigs);

                                    for(let z = 0 ; z< gigDetails[0].gigs_skills.length; z++){
                                        let gigsSkills = new GigsSkills()
                                        gigsSkills.gigs = savedGigs;
                                        gigsSkills.skills = gigDetails[0].gigs_skills[z].skills;
                                        let savedGigSkill = await gigsSkilsRepository.save(gigsSkills);
                                    }

                                    for(let z = 0 ; z< gigDetails[0].gigs_attachments.length; z++){
                                        let gigsAttach = new GigsAttachments()
                                        gigsAttach.created_by = gigDetails[0].gigs_attachments[z].created_by;
                                        gigsAttach.gigs = savedGigs;
                                        gigsAttach.attachment_url =  gigDetails[0].gigs_attachments[z].attachment_url;
                                        gigsAttach.created_at = gigDetails[0].gigs_attachments[z].created_at;
                                        let savedAttachment = await gigsGigsAttachmentsRepository.save(gigsAttach);
                                    }
                            }
                        }
                    }else{
                        const statusUpdated = await gigsRepository.update({id: id },{status:1});
                    }
                }else{
                   const statusUpdated = await gigsRepository.update({id: id },{status:1});
                }
                let ids : any = [created_by];
                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications';
                let meta_data = {"project_id":gigDetails[0].projects.id,"gig_id":gigDetails[0].id,"redirect_on":"hire_freelancer","view":"admin","fl_id":null,"created_by":null,"notification_type":"gig_approved"}
                const json = JSON.stringify({"ids": ids,"message":"PROJECT APPROVED, Thank you for being a part of Begig!","meta_data":meta_data});
                axios.post(bigigUserUrl, json, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async rejectGigApproveReq(body: any, id: any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDelete = await gigsRepository.update({ id:id}, {status:5});
            if(gigDelete.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigsAdd(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigsSkilsRepository = getRepository(GigsSkills);
            const zohoInfoRepo = getRepository(ZohoInfo);
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            const projectRepository = getRepository(Projects);
            var time = Date.now()/1000;
            let gigs = new Gigs()
                    gigs.created_by = user.id;
                    gigs.updated_by = user.id;
                    gigs.created_at = time;
                    gigs.updated_at = time;
                    gigs.status = 0;
                    if(user.employer_type == 0){
                      gigs.status = 1;
                    }
                    gigs.project_id = body.project_id;
                    gigs.projects = body.project_id;
                    gigs.type = body.type; //(0 = fl_pm_required_for_breakdown_only , 1 =fl_pm_required_for_e2e_delivery , 2 =no_assistance_required , 4 = contract_hiring)
                    gigs.title = body.title;
                    gigs.jd_url = body.jd_url;
                    gigs.description = body.description;
                    gigs.designation = body.designation;
                    gigs.education_id = body.education_id;
                    gigs.no_fl_required = body.no_fl_required;
                    gigs.fl_hired = 0;
                    gigs.fl_payment_meta = "";
                    if(body.payment_type == 2){
                        gigs.estimated_duration = 0;
                        gigs.duration_unit = 0; // (0 = hours , 1 = days , 2 = weeks , 3 =months , 4 = years)
                        gigs.estimated_budget = 0;
                        gigs.hours_per_week = 0;
                        gigs.rate_per_hour = 0;
                        gigs.total_budget = 0;
                    }else {
                        if(body.no_fl_required > 1){
                            gigs.fl_payment_meta = JSON.stringify(body.fls_payments_distribution);
                            gigs.estimated_duration = body.fls_payments_distribution[0].estimated_duration;
                            gigs.duration_unit = body.fls_payments_distribution[0].duration_unit; // (0 = hours , 1 = days , 2 = weeks , 3 =months , 4 = years)
                            gigs.estimated_budget = body.total_budget;
                            gigs.hours_per_week = body.fls_payments_distribution[0].rate_per_hour;
                            gigs.rate_per_hour = body.fls_payments_distribution[0].hours_per_week;
                            gigs.total_budget = body.total_budget;
                        }else{
                            if(body.payment_type == 0){
                                gigs.fl_payment_meta = JSON.stringify(body.fls_payments_distribution);
                                gigs.estimated_duration = body.fls_payments_distribution[0].estimated_duration;
                                gigs.duration_unit = body.fls_payments_distribution[0].duration_unit; // (0 = hours , 1 = days , 2 = weeks , 3 =months , 4 = years)
                                gigs.estimated_budget = body.total_budget;
                                gigs.hours_per_week = body.fls_payments_distribution[0].rate_per_hour;
                                gigs.rate_per_hour = body.fls_payments_distribution[0].hours_per_week;
                                gigs.total_budget = body.total_budget;
                            }else{
                                gigs.fl_payment_meta = JSON.stringify(body.fls_payments_distribution);
                                gigs.estimated_duration = body.fls_payments_distribution[0].estimated_duration;
                                gigs.duration_unit = body.fls_payments_distribution[0].duration_unit; // (0 = hours , 1 = days , 2 = weeks , 3 =months , 4 = years)
                                gigs.estimated_budget = body.total_budget;
                                gigs.hours_per_week = body.fls_payments_distribution[0].hours_per_week;
                                gigs.rate_per_hour = body.fls_payments_distribution[0].rate_per_hour;
                                gigs.total_budget = body.total_budget;
                            }
                        }
                    }
                    gigs.required_exerience = body.required_exerience;
                    gigs.payment_type = body.payment_type; //(0 = fixed , 1 = time_and_material , 2 =open_for_discussion)

                    gigs.is_created_by_pm = body.is_created_by_pm;

            var savedGigs = await gigsRepository.save(gigs);

            for(let i = 0 ; i< body.gigs_skills.length; i++){
                let gigsSkills = new GigsSkills()
                    gigsSkills.gigs = savedGigs;
                    gigsSkills.skills = body.gigs_skills[i]
                gigsSkilsRepository.save(gigsSkills);
            }

            for(let i = 0 ; i< body.attachment_url.length; i++){
                let gigsAttach = new GigsAttachments()
                    gigsAttach.created_by = user.id;
                    gigsAttach.gigs = savedGigs;
                    gigsAttach.attachment_url =  body.attachment_url[i]
                    gigsAttach.created_at = time;
                gigsGigsAttachmentsRepository.save(gigsAttach);
            }

            if(user.employer_type == 0){
                  // Create gig on zoho
                try{
                    var zoho_gig_duration = "";
                if(body.fls_payments_distribution[0].duration_unit = 0){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' hours';
                }else if(body.fls_payments_distribution[0].duration_unit = 1){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' days';
                }else if(body.fls_payments_distribution[0].duration_unit = 2){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' weeks';
                }else if(body.fls_payments_distribution[0].duration_unit = 3){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' months';
                }else{
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' years';
                }

                let projectData :any= await projectRepository.find({id:body.project_id,created_by:user.id});
                var Deal = projectData[0].zoho_project_id;
                var Description = body.description;
                var Name = body.title;
                var Gig_Status = "Pending";
                var Gigs_Id = savedGigs.id.toString();
                var Gig_duration = zoho_gig_duration;
                var Gig_budget = body.total_budget;
                var zohoToken :any = await zohoInfoRepo.findOne();

                var createGigsOnZoho :any = await createGigOnZoho(zohoToken.accesstoken,Deal,Description,Name,Gig_Status,Gigs_Id,Gig_duration,Gig_budget);

                gigsRepository.update({ created_by:user.id,project_id:body.project_id}, {zoho_user_id:user.zoho_user_id, zoho_enterprise_id:user.zoho_enterprise_id, zoho_gigs_id:createGigsOnZoho.data[0].details.id});

                }catch(error){
                    console.log(error);
                }

                this.gigUpdateStatus({},savedGigs.id,{});
            }else{
              const jsn = JSON.stringify({"user_id":user.id});
              const re = await axios.post(process.env.Begig_user_url+'api/v1/user/superadmin/account', jsn, {
                  headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `${token.authorization}`
                  }
              });
              let ids : any = [re.data.data.owner_id];
              const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications';
              let meta_data = {"project_id":body.project_id,"gig_id":savedGigs.id,"redirect_on":"under_review","view":"super_admin","fl_id":null,"created_by":user.id,"notification_type":"gig_waiting_for_approval"}
              const json = JSON.stringify({"ids": ids,"message":"Waiting for Approval "+body.title+" requested by {{admin_name}}","meta_data":meta_data});
              axios.post(bigigUserUrl, json, {
                  headers: {
                      'Content-Type': 'application/json'
                  }
              });
            }

            return {statuscode:200};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigsEdit(body: any,id:any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigsSkilsRepository = getRepository(GigsSkills);
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var time = Date.now()/1000;
            var gigs = {
                updated_by:user.id,
                updated_at:time,
                status:0,
                type: body.type,
                title:body.title,
                description: body.description,
                designation: body.designation,
                education_id: body.education_id,
                required_exerience:body.required_exerience,
                payment_type:body.payment_type,
                no_fl_required : body.no_fl_required,
                fl_hired : 0,
                fl_payment_meta : "",
                estimated_duration: 0,
                duration_unit : 0, // (0 = hours , 1 = days , 2 = weeks , 3 =months , 4 = years)
                estimated_budget : 0,
                hours_per_week : 0,
                rate_per_hour : 0,
                total_budget : 0
            }
            if(body.payment_type != 2){
                if(body.no_fl_required > 1){
                    gigs.fl_payment_meta = JSON.stringify(body.fls_payments_distribution);
                    gigs.total_budget = body.total_budget;
                }else{
                    if(body.payment_type == 0){
                        gigs.estimated_budget = body.total_budget;
                        gigs.total_budget = body.total_budget;
                    }else{
                        gigs.estimated_budget = body.total_budget;
                        gigs.hours_per_week = body.fls_payments_distribution[0].hours_per_week;
                        gigs.rate_per_hour = body.fls_payments_distribution[0].rate_per_hour;
                        gigs.total_budget = body.total_budget;
                    }
                }
            }
            const savedDetails =  await gigsRepository.update({ id:  id }, gigs);
            await gigsSkilsRepository.delete({gigs:id})
            for(let i = 0 ; i< body.gigs_skills.length; i++){
                let gigsSkills = new GigsSkills()
                    gigsSkills.gigs = id;
                    gigsSkills.skills = body.gigs_skills[i]
                let savedGigSkill = await gigsSkilsRepository.save(gigsSkills);
            }
            await gigsGigsAttachmentsRepository.delete({gigs:id})
            for(let i = 0 ; i< body.attachment_url.length; i++){
                let gigsAttach = new GigsAttachments()
                    gigsAttach.created_by = user.id;
                    gigsAttach.gigs = id;
                    gigsAttach.attachment_url =  body.attachment_url[i]
                    gigsAttach.created_at = time;
                let savedAttachment = await gigsGigsAttachmentsRepository.save(gigsAttach);
            }
            //Update gig on zoho
            try{
                var zoho_gig_duration = "";
                if(body.fls_payments_distribution[0].duration_unit = 0){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' hours';
                }else if(body.fls_payments_distribution[0].duration_unit = 1){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' days';
                }else if(body.fls_payments_distribution[0].duration_unit = 2){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' weeks';
                }else if(body.fls_payments_distribution[0].duration_unit = 3){
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' months';
                }else{
                    zoho_gig_duration = body.fls_payments_distribution[0].estimated_duration + ' years';
                }
                let gigsData :any= await gigsRepository.find({id:id});
                var zohoGigId = gigsData[0].zoho_gigs_id;
                var updateData = {
                    Description: body.description,
                    Name:body.title,
                    Gig_duration: zoho_gig_duration,
                    Gig_budget : body.total_budget
                }
                var zohoToken :any = await zohoInfoRepo.findOne();
                await updateGigOnZoho(zohoToken.accesstoken,zohoGigId,updateData);

            }catch(error){
                console.log(error);
            }
            ////////////////////////////////////////////////////////
            return {statuscode:200};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async addGigsDraft(body: any, user: any): Promise<any>{
        try{
            const draftedGigsRepository = getRepository(DraftedGigs);
            let draftedGigs = new DraftedGigs();
            draftedGigs.created_by = user.id;
            draftedGigs.gigs_details_json = JSON.stringify(body);
            draftedGigs.projects = body.project_id;
            draftedGigs.created_at =  Date.now()/1000;
            let savedDraftedGigs = await draftedGigsRepository.save(draftedGigs);
            return {statuscode:200};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async editGigsDraft(body: any, id:any, user: any): Promise<any>{
        try{
            const draftedGigsRepository = getRepository(DraftedGigs);
            const editGigsDraft =  await draftedGigsRepository.update({ created_by:user.id, id:id }, {gigs_details_json : JSON.stringify(body), projects : body.project_id});
            if(editGigsDraft.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async deleteGigsDraft(body: any, id: any, user: any): Promise<any>{
        try{
            const draftedGigsRepository = getRepository(DraftedGigs);
            const draftedGigDelete = await draftedGigsRepository.delete({ created_by:user.id, id:id});
            if(draftedGigDelete.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async attachmentsByGigId(body: any,user: any): Promise<any>{
        try{
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            var time = Date.now()/1000;
            for(let i = 0 ; i< body.attachment_url.length; i++){
                let gigsAttach = new GigsAttachments()
                    gigsAttach.created_by = user.id;
                    gigsAttach.gigs = body.gigid;
                    gigsAttach.attachment_url =  body.attachment_url[i]
                    gigsAttach.created_at = time;
                let savedAttachment = await gigsGigsAttachmentsRepository.save(gigsAttach);
            }
            return {statuscode:200};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async deleteAttachment(body:any,id:any,user:any):Promise<any> {
        try{
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            let res:any = await gigsGigsAttachmentsRepository.delete(
                {
                    id:id,
                    created_by:user.id
                });
            if(res.affected > 0){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigdetailsFL(body: any,  id: any, user: any,token :any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const savedGigsRepository = getRepository(SavedGigs);
            const gigDetails : any = await gigsRepository.find({ where: { id: id}, relations:["gigs_skills","gigs_attachments",'gigs_milestones'] });
            var is_saved :any= 0;
            const saveFlData :any= await savedGigsRepository.find({ where: {fl_id :user.freelancer_id,gig:id}});
            if(saveFlData.length > 0){              
                is_saved = 1;
            }
            if(gigDetails.length > 0){
                const res = await axios.get(process.env.Begig_user_url+'api/v1/user/get/user/'+gigDetails[0].created_by , {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                var admin = {
                    id : res.data.userData[0].user.id,
                    emp_id : res.data.userData[0].id,
                    first_name : res.data.userData[0].user.first_name,
                    last_name : res.data.userData[0].user.last_name,
                    profile_pic : res.data.userData[0].user.profile_pic,
                    average_rating : res.data.userData[0].user.average_rating,
                    company_name : res.data.userData[0].company.company_name,
                }
                gigDetails[0].admin = admin,
                gigDetails[0].is_saved = is_saved
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigDelete(body: any, id: any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDelete = await gigsRepository.update({ created_by:user.id, id:id}, {status:5});
            if(gigDelete.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getAllDraftGigsByUserId(body: any, user: any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 10
            const draftedGigsRepository = getRepository(DraftedGigs);
            const gigs = await draftedGigsRepository.find({ where: { created_by:user.id} , skip: page_number*number_of_record, take: number_of_record,relations:["projects"]});
            var obj = [];
            for(let i =0; i< gigs.length; i++){
               obj[i] = JSON.parse(gigs[i].gigs_details_json);
               obj[i].projects = gigs[i].projects;
               obj[i].id = gigs[i].id;
               obj[i].created_at = gigs[i].created_at;
            }
            return {statuscode:200,data:obj};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getAllUnapprovedGigsByUserId(body: any, user: any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 10
            const gigsRepository = getRepository(Gigs);
            const gigs = await gigsRepository.find({ where: { created_by:user.id, status : 0} , skip: page_number*number_of_record, take: number_of_record,relations:["projects","gigs_milestones","gigs_attachments"]});
            return {statuscode:200,data:gigs};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getallopenGigslist(body: any, user: any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 10
            const gigsRepository = getRepository(Gigs);
            const gigs = await gigsRepository.find({ where: {created_by:user.id, status:1} , skip: page_number*number_of_record, take: number_of_record,relations:["projects","gigs_milestones","gigs_skills"]});
            return {statuscode:200,data:gigs};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async openGigslistByProject(project_id: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigs:any = await gigsRepository.find({ where: { project_id: project_id,status:1} ,relations:["projects","gigs_skills"]});
            if(gigs.length > 0){
                return {statuscode:200,data:gigs};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async unapprovedGigslistByProject(project_id: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigs:any = await gigsRepository.find({ where: { project_id: project_id,status:0} ,relations:["projects","gigs_skills","gigs_attachments"]});
            if(gigs.length > 0){
                return {statuscode:200,data:gigs};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async getDashboardStatusCountAdmin(body: any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;


            const submittedMilestoneReq = await getRepository(GigsMilestones)
                                    .createQueryBuilder("gigs_milestones")
                                    .where("gigs_milestones.gigs IN (select id from gigs where created_by = "+user.id+" AND status = 2)")
                                    .andWhere("gigs_milestones.status = 3")
                                    .getCount();

            const unapprovedGig = await getRepository(Gigs)
                                    .createQueryBuilder("gigs")
                                    .where("gigs.status = 0")
                                    .andWhere("gigs.created_by ="+ user.id)
                                    .getCount();

            const draftGig = await getRepository(DraftedGigs)
                                    .createQueryBuilder("gigs")
                                    .where("gigs.created_by ="+ user.id)
                                    .getCount();

            const aprrovedGig = await getRepository(Gigs)
                                    .createQueryBuilder("gigs")
                                    .where("gigs.status = 1")
                                    .andWhere("gigs.created_by ="+ user.id)
                                    .getCount();

            const completed = await getRepository(Gigs)
                                    .createQueryBuilder("gigs")
                                    .where("gigs.status = 3")
                                    .andWhere("gigs.created_by ="+ user.id)
                                    .getCount();

            const ongoing : any = await getRepository(Gigs)
                                    .createQueryBuilder("gigs")
                                    .leftJoinAndSelect("gigs.projects", "projects")
                                    .where("gigs.created_by = "+user.id)
                                    .andWhere("gigs.status = 2")
                                    .andWhere("(gigs.expected_closer > :time OR gigs.expected_closer = 0)",{time:time})
                                    .getCount();

            const overdue : any = await getRepository(Gigs)
                                    .createQueryBuilder("gigs")
                                    .leftJoinAndSelect("gigs.projects", "projects")
                                    .where("gigs.created_by = "+user.id)
                                    .andWhere("gigs.status = 2")
                                    .andWhere("(gigs.expected_closer < :time AND gigs.expected_closer > 0)",{time:time})
                                    .getCount();

            const pendingReviwToFl: any = await getRepository(Gigs)
                                    .createQueryBuilder("gigs")
                                    .where("(gigs.status = 3 AND gigs.is_review_given_to_fl =0)")
                                    .andWhere("gigs.created_by ="+ user.id)
                                    .getCount();

           return {statuscode:200,data: {unapprovedGig,draftGig ,aprrovedGig, ongoing,overdue,completed,pendingReviwToFl,submittedMilestoneReq}};

        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getSuperAdminGigsCount(body: any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time :any = Date.now()/1000;
            const completed = await getRepository(Gigs)
                                .createQueryBuilder("gigs")
                                .leftJoinAndSelect("gigs.projects", "projects")
                                .where("gigs.status = 3")
                                .andWhere("company_id ="+ user.company_id)
                                .getCount();

            const open = await getRepository(Gigs)
                                .createQueryBuilder("gigs")
                                .leftJoinAndSelect("gigs.projects", "projects")
                                .where("gigs.status = 1")
                                .andWhere("company_id ="+ user.company_id)
                                .getCount();
            const overdue = await getRepository(Gigs)
              .createQueryBuilder("gigs")
              .leftJoinAndSelect("gigs.projects", "projects")
              .where("gigs.status = 2")
              .andWhere("gigs.expected_closer <= "+time+" AND gigs.expected_closer > 0")
              .andWhere("company_id ="+ user.company_id)
              .getCount();
              const ontrack = await getRepository(Gigs)
              .createQueryBuilder("gigs")
              .leftJoinAndSelect("gigs.projects", "projects")
              .where("gigs.status = 2")
              .andWhere("(gigs.expected_closer > "+time+" OR gigs.expected_closer = 0)")
              .andWhere("company_id ="+ user.company_id)
              .getCount();
              const unapprovedGig = await getRepository(Gigs)
              .createQueryBuilder("gigs")
              .leftJoinAndSelect("gigs.projects", "projects")
              .where("gigs.status = 0")
              .andWhere("company_id ="+ user.company_id)
              .getCount();

            return {statuscode:200,data: {ontrack:ontrack,overdue:overdue ,open:open, completed:completed,unapprovedGig:unapprovedGig}};

        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async superAdminFeedbackToGig(body: any, user: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time :any = Date.now()/1000;
            const gigFeedback = await gigsRepository.update({id: body.Gigid },{super_admin_feedback: body.super_admin_feedback, freedback_updated_on:time});
            if(gigFeedback.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    /////////////////////////////New API 09-08-2021//////////////////////////////////

    //get ongoing gigs by user id
    async GigOnGoingByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const page_number = body.page_number || 0
            const number_of_record = body.number_of_record || 5
            var time = Date.now()/1000;

            const gigDetails : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .where("gigs.created_by = "+user.id)
            .andWhere("gigs.status = 2")
            .andWhere("(gigs.expected_closer > :time OR gigs.expected_closer = 0)",{time:time})
            .limit(number_of_record)   // page number
            .offset(page_number * number_of_record)   // offset (from where we want to get record)
            .getMany();

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                       id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    //get ongoing gigs by user id FL
    async GigOnGoingByUserIdFL(body: any, user: any,token:any): Promise<any>{
      try{
          const gigsRepository = getRepository(Gigs);
          var time = Date.now()/1000;
          const page_number = body.page_number || 0
          const number_of_record = body.number_of_record || 10
          const gigDetails : any = await gigsRepository.find({ where: { fl_id: user.freelancer_id,status:2 }, relations:["projects"],skip: page_number*number_of_record, take: number_of_record, order: {created_at: "DESC"}});
          if(gigDetails.length>0){
            let id : any = [];
            for(let i=0;i<gigDetails.length;i++){
                if(!id.includes(gigDetails[i].created_by)){
                    id.push(gigDetails[i].created_by);
                }
            }
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
            const json = JSON.stringify({"id": id});
            const res = await axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });

            for(let i=0;i<gigDetails.length;i++){
              let created_by = gigDetails[i].created_by;
              for(let j=0;j< res.data.userData.length;j++){
                if(created_by == res.data.userData[j].user.id){
                  var admin : any = {
                    first_name : res.data.userData[j].user.first_name,
                    last_name : res.data.userData[j].user.last_name,
                    profile_pic : res.data.userData[j].user.profile_pic,
                    average_rating : res.data.userData[j].user.average_rating,
                    company_name : res.data.userData[j].company.company_name,
                  }
                  gigDetails[i].admin = admin
                  break;
                }
              }
            }
            return {statuscode:200,data:gigDetails};
          }else{
              return {statuscode:201};
          }
      }catch(err){
          console.log(err);
          if(process.env.ENV != "development"){
            rollbar.error(err);
          } 
          return {statuscode:500};
      }
    }


    //get completed gigs by user id
    async GigClosedByUserIdFL(body: any, user: any,token:any): Promise<any>{
      try{
          const gigsRepository = getRepository(Gigs);
          var time = Date.now()/1000;
          const page_number = body.page_number || 0
          const number_of_record = body.number_of_record || 5
          const gigDetails : any = await gigsRepository.find({ where: { fl_id: user.freelancer_id,status:3 }, relations:["projects"],skip: page_number, take: number_of_record});
          if(gigDetails.length>0){
            let id : any = [];
            for(let i=0;i<gigDetails.length;i++){
                if(!id.includes(gigDetails[i].created_by)){
                    id.push(gigDetails[i].created_by);
                }
            }
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
            const json = JSON.stringify({"id": id});
            const res = await axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });
            for(let i=0;i<gigDetails.length;i++){
              let created_by = gigDetails[i].created_by;
              for(let j=0;j< res.data.userData.length;j++){
                if(created_by == res.data.userData[j].user.id){
                  var admin : any = {
                    first_name : res.data.userData[j].user.first_name,
                    last_name : res.data.userData[j].user.last_name,
                    profile_pic : res.data.userData[j].user.profile_pic,
                    average_rating : res.data.userData[j].user.average_rating,
                    company_name : res.data.userData[j].company.company_name,
                  }
                  gigDetails[i].admin = admin
                  break;
                }
              }
            }
            return {statuscode:200,data:gigDetails};
          }else{
              return {statuscode:201};
          }
      }catch(err){
          console.log(err);
          if(process.env.ENV != "development"){
            rollbar.error(err);
          } 
          return {statuscode:500};
      }
    }




    //get overdue gigs by project id
    async overdueGigByProjectId(project_id: any, user: any,token:any) {
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .where("gigs.project_id ="+project_id)
            .andWhere("gigs.status = 2")
            .andWhere("gigs.expected_closer < " + time)
            .andWhere("gigs.expected_closer > 0")
            .getMany();
            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async overdueGigByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 5;
            const gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .where("gigs.created_by ="+user.id)
                .andWhere("gigs.status = 2")
                .andWhere("gigs.expected_closer < " + time)
                .andWhere("gigs.expected_closer > 0")
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)
                .getMany();
            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                       id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async completedGigByProjectId(project_id: any, user: any,token:any) {
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await gigsRepository.find({ where: { project_id: project_id,status:3}, relations:["projects"] });
            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async completedGigByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            const gigDetails : any = await gigsRepository.find({ where: { created_by: user.id,status:3}, relations:["projects"],skip: page_number*number_of_record, take: number_of_record });
            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                       id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async completedGigByUserIdFL(body: any, user: any,token:any): Promise<any>{
      try{
          const gigsRepository = getRepository(Gigs);
          var time = Date.now()/1000;
          const page_number = body.page_number || 0;
          const number_of_record = body.number_of_record || 10;
          const gigDetails : any = await gigsRepository.find({ where: { fl_id: user.freelancer_id,status:3}, relations:["projects"],skip: page_number*number_of_record, take: number_of_record });
          if(gigDetails.length>0){
              let id : any = [];
              for(let i=0;i<gigDetails.length;i++){
                  if(!id.includes(gigDetails[i].created_by)){
                     id.push(gigDetails[i].created_by);
                  }
              }
              const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
              const json = JSON.stringify({"id": id});
              const res = await axios.post(bigigUserUrl, json, {
                  headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `${token.authorization}`
                  }
              });
              for(let i=0;i<gigDetails.length;i++){
                let created_by = gigDetails[i].created_by;
                for(let j=0;j< res.data.userData.length;j++){
                  if(created_by == res.data.userData[j].user.id){
                    var admin : any = {
                      first_name : res.data.userData[j].user.first_name,
                      last_name : res.data.userData[j].user.last_name,
                      profile_pic : res.data.userData[j].user.profile_pic,
                      average_rating : res.data.userData[j].user.average_rating,
                      company_name : res.data.userData[j].company.company_name,
                    }
                    gigDetails[i].admin = admin
                    break;
                  }
                }
              }

              return {statuscode:200,data:gigDetails};
          }else{
              return {statuscode:201};
          }
      }catch(err){
          console.log(err);
          if(process.env.ENV != "development"){
            rollbar.error(err);
          } 
          return {statuscode:500};
      }
  }



    // 42 - Get all MileStones for ongoging gigs for admin
     async ongogingMileStonesByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await gigsRepository.find({ where: { created_by: 6, status:Not(5) }, relations:["gigs_milestones"] });
            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    // 43 - Get all overdue MileStones for admin
    async overdueMileStonesByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .where("gigs.created_by = 6")
                .andWhere("gigs.status !="+ 5)
                .andWhere("gigs_milestones.expected_closer >="+ time)
                .getMany();

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id) && gigDetails[i]){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    // 44 - Get all ontrack MileStones for admin
    async ontrackMileStonesByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .where("gigs.created_by = 6")
                .andWhere("gigs.status !="+ 5)
                .andWhere("gigs_milestones.expected_closer <="+ time)
                .andWhere("gigs_milestones.start_date >="+ time)
                .getMany();

            console.log("gigDetails " , gigDetails );

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id) && gigDetails[i]){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    // 45 - Get all unapproved MileStones for admin
    async unapprovedMileStonesByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .where("gigs.created_by = 6")
                .andWhere("gigs.status !="+ 5)
                .andWhere("gigs_milestones.status ="+ 2)
                .getMany();

            console.log("gigDetails " , gigDetails );

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id) && gigDetails[i]){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    // 46 - Get all closed MileStones for admin
    async closedMileStonesByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .where("gigs.created_by = 6")
                .andWhere("gigs.status !="+ 5)
                .andWhere("gigs_milestones.status ="+ 4)
                .getMany();

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id) && gigDetails[i]){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    // 47 - Get all upcoming MileStones for admin
    async upcomingMileStonesByUserId(body: any, user: any,token:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .where("gigs.created_by = 6")
                .andWhere("gigs.status !="+ 5)
                .andWhere("gigs_milestones.status ="+ 1)
                .andWhere("gigs_milestones.start_date >="+ time)
                .getMany();

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id) && gigDetails[i]){
                        id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    //get ongoing gigs by project id
    async GigsOnGoingByProjectId(project_id: any, user: any,token:any) {
        try{
            var time = Date.now()/1000;
            const gigDetails : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .where("gigs.project_id = "+project_id)
            .andWhere("gigs.status = 2")
            .getMany();
            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                       id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async getHiredFlsIdByEmployerId(body: any, user: any,token:any): Promise<any>{
      try{
        const gigsDetail : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.created_by = "+user.id)
            .getMany();
        var fl_ids: string | any[] = [];
        for(let i = 0;i<gigsDetail.length;i++){
          let fl_id = gigsDetail[i].fl_id;
          if(fl_ids.indexOf(fl_id) == -1){
            fl_ids.push(fl_id)
          }
        }
        if(fl_ids.length > 0){
          return {status:200,data:fl_ids}
        }else{
          return {status:201}
        }
      }catch(err){
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500};
      }
    }


    async updateCommisionStatus(user:any,gig_id: any, ): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigFeedback = await gigsRepository.update({id: gig_id },{is_commission_paid: 1});
            if(gigFeedback.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async adminBidAndInviteCount(user:any): Promise<any> {
        try {
            var top_bid = 0;
            var good_bid = 0;
            var basic_bid = 0;
            var top_invite = 0;
            var good_invite = 0;
            var basic_invite = 0;

            top_bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .where("bids.gigs IN (select id from gigs where created_by ="+user.id+" AND status = 1)")
            .andWhere("bids.match_score >= 80")
            .getCount();

            good_bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .where("bids.gigs IN (select id from gigs where created_by ="+user.id+" AND status = 1)")
            .andWhere("bids.match_score >= 50 AND bids.match_score < 80")
            .getCount();

            basic_bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .where("bids.gigs IN (select id from gigs where created_by ="+user.id+" AND status = 1)")
            .andWhere("bids.match_score < 50")
            .getCount();

            top_invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .where("invite_fl_for_gigs.gigs IN (select id from gigs where created_by ="+user.id+" AND status = 1)")
            .andWhere("invite_fl_for_gigs.match_score >= 80")
            .getCount();

            good_invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .where("invite_fl_for_gigs.gigs IN (select id from gigs where created_by ="+user.id+" AND status = 1)")
            .andWhere("invite_fl_for_gigs.match_score >= 50 AND invite_fl_for_gigs.match_score < 80")
            .getCount();

            basic_invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .where("invite_fl_for_gigs.gigs IN (select id from gigs where created_by ="+user.id+" AND status = 1)")
            .andWhere("invite_fl_for_gigs.match_score < 50")
            .getCount();

            return {statuscode:200,data:{top_bid:top_bid, good_bid:good_bid, basic_bid:basic_bid,top_invite:top_invite,good_invite:good_invite,basic_invite:basic_invite}};

        }
        catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async reviewFls(body:any, user:any,token:any):Promise<any>{
      try{
        var employer_id = user.employer_id;
        var fl_id = body.fl_id;
        var gig_id = body.gig_id;
        var rate = body.rate;
        var review = body.review;
        const json = JSON.stringify({"fl_id": fl_id,gig_id:gig_id,rate:rate,review:review});
        const res = axios.post(process.env.Begig_user_url+'api/v1/user/review/to/freelancer', json, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `${token.authorization}`
            }
        });
        const gigsRepository = getRepository(Gigs);
        const gigFeedback = await gigsRepository.update({id: gig_id },{is_review_given_to_fl: 1});
        return {statuscode:200};
      }catch(err){
        console.log(err)
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500};
      }
    };

    async getUnreviewedFls(body:any, user:any,token:any): Promise<any>{
      try{
        const page_number = body.page_number || 0
        const number_of_record = body.number_of_record || 5
        var time = Date.now()/1000;

        const gigDetails : any = await getRepository(Gigs)
        .createQueryBuilder("gigs")
        .where("gigs.created_by = "+user.id)
        .andWhere("gigs.status = 3")
        .andWhere("(gigs.is_review_given_to_fl = 0)")
        .limit(number_of_record)   // page number
        .offset(page_number * number_of_record)   // offset (from where we want to get record)
        .getMany();

        if(gigDetails.length>0){
            let id : any = [];
            for(let i=0;i<gigDetails.length;i++){
                if(!id.includes(gigDetails[i].fl_id)){
                   id.push(gigDetails[i].fl_id);
                }
            }
            const json = JSON.stringify({"id": id});
            const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });

            for(let i=0;i<gigDetails.length;i++){
                let fl_id = gigDetails[i].fl_id;
                for(let j=0;j< res.data.freelancerData.length;j++){
                    if(fl_id == res.data.freelancerData[j].id){
                        var freelancer : any = {
                            first_name : res.data.freelancerData[j].user.first_name,
                            last_name : res.data.freelancerData[j].user.last_name,
                            profile_pic : res.data.freelancerData[j].user.profile_pic,
                            average_rating : res.data.freelancerData[j].user.average_rating,
                            freelancing_type : res.data.freelancerData[j].freelancing_type,
                            rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                            availibity : res.data.freelancerData[j].availibity
                        }
                        gigDetails[i].freelancer = freelancer
                        break;
                    }
                }
            }

            return {statuscode:200,data:gigDetails};
        }else{
            return {statuscode:201};
        }
      }catch(err){
          console.log(err);
          if(process.env.ENV != "development"){
            rollbar.error(err);
          } 
          return {statuscode:500};
      }
    }

    async openGigsFreelancersStatusCount(body:any,user:any, token:any):Promise<any>{
      try{
        const page_number = body.page_number || 0
        const number_of_record = body.number_of_record || 5
        const gigDetails : any = await getRepository(Gigs)
        .createQueryBuilder("gigs")
        .leftJoinAndSelect("gigs.projects", "projects")
        .where("gigs.created_by = "+user.id)
        .andWhere("gigs.status = 1")
        .limit(number_of_record)   // page number
        .offset(page_number * number_of_record)   // offset (from where we want to get record)
        .getMany();
        var main_arr :any = [];
        var gig_ids_arr :any = [];
        async function getStatusCount(index:any){
          let gig_id = gigDetails[index].id;
          let top_bid = 0;
          let good_bid = 0;
          let basic_bid = 0;
          let top_invite = 0;
          let good_invite = 0;
          let basic_invite = 0;
          top_bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .where("bids.gigs  = "+gig_id)
            .andWhere("bids.match_score >= 80")
            .getCount();

          good_bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .where("bids.gigs  = "+gig_id)
            .andWhere("bids.match_score >= 50 AND bids.match_score < 80")
            .getCount();

          basic_bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .where("bids.gigs  = "+gig_id)
            .andWhere("bids.match_score < 50")
            .getCount();

          top_invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .where("invite_fl_for_gigs.gigs  = "+gig_id)
            .andWhere("invite_fl_for_gigs.match_score >= 80")
            .getCount();

          good_invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .where("invite_fl_for_gigs.gigs = "+gig_id)
            .andWhere("invite_fl_for_gigs.match_score >= 50 AND invite_fl_for_gigs.match_score < 80")
            .getCount();

          basic_invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .where("invite_fl_for_gigs.gigs = "+gig_id)
            .andWhere("invite_fl_for_gigs.match_score < 50")
            .getCount();
          gigDetails[index].basic_invite = basic_invite;
          gigDetails[index].good_invite = good_invite;
          gigDetails[index].top_invite = top_invite;
          gigDetails[index].basic_bid = basic_bid;
          gigDetails[index].good_bid = good_bid;
          gigDetails[index].top_bid = top_bid;
          main_arr.push(gigDetails[index]);
          if(main_arr.length == gigDetails.length){console.log("dsa");
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/gigs/saved/fls/count';
            const json = JSON.stringify({"gig_ids": gig_ids_arr});
            const res = await axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });

            for(let i=0;i<main_arr.length;i++){
              let gigId = main_arr[i].id;
              for(let j=0;j< res.data.savedUserData.length;j++){
                  if(gigId == res.data.savedUserData[j].gig_id){
                    main_arr[i].top_saved_fls = res.data.savedUserData[j].top_saved;
                    main_arr[i].good_saved_fls = res.data.savedUserData[j].good_saved;
                    main_arr[i].basic_saved_fls = res.data.savedUserData[j].basic_saved;
                    break;
                  }
              }
            }
            if(main_arr.length > 0){
              return {statuscode:200,data:main_arr};
            }else{
              return {statuscode:201};
            }
          }
        }

        for(let i=0;i<gigDetails.length;i++){
          gig_ids_arr.push(gigDetails[i].id);
          let data = await getStatusCount(i);
          if(data){
            return data;
          }
        }
      }catch(err){
        console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500};
      }
    }

    async dashbaordMilestoneCountSuperAdmin(user:any):Promise<any>{
      try{
      var time = Date.now()/1000;
      var upcoming_milestones = await getRepository(GigsMilestones)
        .createQueryBuilder("gigs_milestones")
        .where("gigs_milestones.gigs IN (select id from gigs where project_id in (select id from projects where company_id = "+user.company_id+") AND fl_id != 0) and gigs_milestones.status = 0")
        .getCount();console.log(upcoming_milestones);

      var ontrack_milestones = await getRepository(GigsMilestones)
        .createQueryBuilder("gigs_milestones")
        .where("gigs_milestones.gigs IN (select id from gigs where project_id in (select id from projects where company_id = "+user.company_id+") AND fl_id != 0) and gigs_milestones.status in (1,4) and gigs_milestones.end_date > "+time)
        .getCount();
      var overdue_milestones = await getRepository(GigsMilestones)
          .createQueryBuilder("gigs_milestones")
          .where("gigs_milestones.gigs IN (select id from gigs where project_id in (select id from projects where company_id = "+user.company_id+") AND fl_id != 0) and gigs_milestones.status in (1,4) and gigs_milestones.end_date <= "+time)
         .getCount();

      var completed_milestones = await getRepository(GigsMilestones)
         .createQueryBuilder("gigs_milestones")
         .where("gigs_milestones.gigs IN (select id from gigs where project_id in (select id from projects where company_id = "+user.company_id+") AND fl_id != 0) and gigs_milestones.status = 3")
        .getCount();
        return {statuscode:200,data:{completed_milestones:completed_milestones,overdue_milestones:overdue_milestones,ontrack_milestones:ontrack_milestones,upcoming_milestones:upcoming_milestones}};
      }catch(err){
        console.log(err);
        if(process.env.ENV != "development"){
            rollbar.error(err);
        } 
        return {statuscode:500};
      }
    }


    async dashboardMilestoneDetailsAdmin(user:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var finalData = [];
            const gigDetails : any = await gigsRepository.find({ where: { status: 2,created_by:user.id},order: {projects: "DESC"}, relations:["projects", "gigs_milestones"]});
            var k = 0;
            var currenctProject_id = 0;
            for(let i =0; i< gigDetails.length ;i++){
                if(i==0){
                    let obj :any= {project:gigDetails[i].projects};
                    obj.project.gigs = [];
                    currenctProject_id = gigDetails[i].projects.id;
                    delete gigDetails[i]["projects"];
                    obj.project.gigs.push(gigDetails[i]);
                    finalData.push(obj);
                }else{
                    if(currenctProject_id == gigDetails[i].projects.id){
                        delete gigDetails[i]["projects"];
                        finalData[k].project.gigs.push(gigDetails[i]);
                    }else{
                        let obj :any= {project:gigDetails[i].projects};
                        obj.project.gigs = [];
                        currenctProject_id = gigDetails[i].projects.id;
                        delete gigDetails[i]["projects"];
                        obj.project.gigs.push(gigDetails[i]);
                        finalData.push(obj);
                        k = k+1;
                    }
                }
            }

            if(finalData.length > 0){
                return {statuscode:200,data:finalData};
            }else {
                return {statuscode:201};
            }

        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    async dashboardGigStatusCountFL(user:any): Promise<any> {
        try {
            var bid = 0;
            var invite = 0;
            var saved = 0;
            var closed = 0;
            var total_earning:any = 0;

            saved = await getRepository(SavedGigs)
            .createQueryBuilder("saved_gigs")
            .leftJoinAndSelect("saved_gigs.gig", "gig")
            .where("saved_gigs.fl_id =:fl_id",{fl_id: user.freelancer_id })
            .getCount();

            bid = await getRepository(Bids)
            .createQueryBuilder("bids")
            .leftJoinAndSelect("bids.gigs", "gigs")
            .where("bids.fl_id = "+user.freelancer_id+" and bids.status = 0 and gigs.status = 1")
            .getCount();

            invite = await getRepository(GigsInvitation)
            .createQueryBuilder("invite_fl_for_gigs")
            .leftJoinAndSelect("invite_fl_for_gigs.gigs", "gigs")
            .where("invite_fl_for_gigs.fl_id = "+user.freelancer_id+" and invite_fl_for_gigs.status = 0 and gigs.status = 1")
            .getCount();

            closed = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.fl_id = "+user.freelancer_id)
            .andWhere("gigs.status = 3")
            .getCount();

            total_earning = await getRepository(GigsMilestones)
                .createQueryBuilder("gigs_milestones")
                .select("SUM(gigs_milestones.estimated_budget)", "sum")
                .where("gigs_milestones.gigs IN (select id from gigs where fl_id ="+user.freelancer_id+")")
                .andWhere("gigs_milestones.status = 3")
                .getRawOne();
            if(total_earning.sum != null){console.log(total_earning.sum)
                total_earning = total_earning.sum;
            }else{
                total_earning = 0;
            }

            return {statuscode:200,data:{bid:bid, invite:invite, closed:closed,saved:saved,total_earning:total_earning}};

        }catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }           
            return {statuscode:500};
        }
    }

    async dashboardMilestoneDetailsFL(user:any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDetails : any = await gigsRepository.find({ where: { status: 2,fl_id:user.freelancer_id},order: {projects: "DESC"}, relations:["gigs_milestones"]});
            if(gigDetails.length > 0){
                return {statuscode:200,data:gigDetails};
            }else {
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async savedGigs(body:any,user:any): Promise<any>{
        try {
            const savedGigs = getRepository(SavedGigs);
            const saveFlData :any= await savedGigs.find({ where: {fl_id :user.freelancer_id ,gig:body.gig_id}});
            if(saveFlData.length > 0){
                return {statuscode:201};
            }else{
                let currentTime = Date.now() / 1000;
                let savedata = new SavedGigs();
                    savedata.fl_id = user.freelancer_id;
                    savedata.gig = body.gig_id;
                    savedata.match_score = body.match_score || 0;
                    savedata.created_at = currentTime;
                const savedData = await savedGigs.save(savedata);
                return {statuscode:200};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async savedGigsList(user:any,body:any,token:any): Promise<any>{
        try {
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            const saveFlData :any= await getRepository(SavedGigs)
            .createQueryBuilder("saved_gigs")
            .leftJoinAndSelect("saved_gigs.gig", "gig")
            .leftJoinAndSelect("gig.gigs_skills", "gigs_skills")
            .where("saved_gigs.fl_id =:fl_id",{fl_id: user.freelancer_id })
            .limit(number_of_record)   // page number
            .offset(page_number * number_of_record)   // offset (from where we want to get record)
            .getMany();
            if(saveFlData.length > 0){
                let id : any = [];
                for(let i=0;i<saveFlData.length;i++){
                    if(!id.includes(saveFlData[i].gig.created_by)){
                       id.push(saveFlData[i].gig.created_by);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/users', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<saveFlData.length;i++){
                    let gigId = saveFlData[i].gig.created_by;
                    for(let j=0;j< res.data.userData.length;j++){
                        if(gigId == res.data.userData[j].user.id){
                            var admin : any = {
                                first_name : res.data.userData[j].user.first_name,
                                last_name : res.data.userData[j].user.last_name,
                                profile_pic : res.data.userData[j].user.profile_pic,
                                average_rating : res.data.userData[j].user.average_rating,
                                company_name : res.data.userData[j].company.company_name,
                            }
                            saveFlData[i].admin = admin
                            break;
                        }
                    }
                }
                return {statuscode:200,data:saveFlData};
            }else {
                return {statuscode:201};
            }
        }
        catch (error) {
            console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async ingnoreSavedGigsList(user:any,id:any): Promise<any>{
        try{
            const savedGigsRepository = getRepository(SavedGigs);
            let res:any = await savedGigsRepository.delete({id:id,fl_id: user.freelancer_id});
            if(res.affected > 0){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async gigsDetails(body: any): Promise<any>{
        try{
            const gigsRepository = getRepository(Gigs);
            var gig_id:any = body.gig_id;
            var fl_id:any = body.fl_id;
            const gigDetails : any = await gigsRepository.find({ where: { id: gig_id}, relations:["gigs_skills","gigs_attachments",'gigs_milestones'] });
            if(gigDetails.length > 0){
                const res = await axios.get(process.env.Begig_user_url+'api/v1/user/get/user/for/front_page/'+gigDetails[0].created_by , {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                var admin = {
                    id : res.data.userData[0].user.id,
                    emp_id : res.data.userData[0].id,
                    first_name : res.data.userData[0].user.first_name,
                    last_name : res.data.userData[0].user.last_name,
                    profile_pic : res.data.userData[0].user.profile_pic,
                    average_rating : res.data.userData[0].user.average_rating,
                    company_name : res.data.userData[0].company.company_name,
                }
                gigDetails[0].admin = admin
                if(fl_id == 0){
                    return {statuscode:200,data:gigDetails};
                }else{
                    let gigs_id :any = [];
                    for(let i=0;i<gigDetails.length;i++){
                        gigs_id.push(gigDetails[i].id);
                    }
                    return {statuscode:200,data:gigDetails};
                }
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async similarGigsDetails(body: any): Promise<any>{
        try{
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            const gigsDetail : any = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .leftJoinAndSelect("gigs.projects", "projects")
            .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
            .andWhere("gigs_skills.skills IN (:...skill)",{ skill: body.skills })
            .limit(number_of_record)   // page number
            .offset(page_number * number_of_record)   // offset (from where we want to get record)
            .getMany();
            if(gigsDetail.length > 0){
              let id : any = [];
              for(let i=0;i<gigsDetail.length;i++){
                  if(!id.includes(gigsDetail[i].created_by)){
                    id.push(gigsDetail[i].created_by);
                  }
              }

              const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users/for/fontpage';
              const json = JSON.stringify({"id": id});
              const res = await axios.post(bigigUserUrl, json, {
                  headers: {
                      'Content-Type': 'application/json'
                  }
              });

              for(let i=0;i<gigsDetail.length;i++){
                  let gigId = gigsDetail[i].created_by;
                  for(let j=0;j< res.data.userData.length;j++){
                      if(gigId == res.data.userData[j].user.id){
                          var admin : any = {
                              first_name : res.data.userData[j].user.first_name,
                              last_name : res.data.userData[j].user.last_name,
                              profile_pic : res.data.userData[j].user.profile_pic,
                              average_rating : res.data.userData[j].user.average_rating,
                              company_name : res.data.userData[j].company.company_name,
                          }
                          gigsDetail[i].admin = admin
                          break;
                      }
                  }
              }
              if(body.fl_id == 0){
                  return {statuscode:200,data:gigsDetail};
              }else{
                  let gigs_id :any = [];
                  for(let i=0;i<gigsDetail.length;i++){
                      gigs_id.push(gigsDetail[i].id);
                  }
                  return {statuscode:200,data:gigsDetail};
              }
            }else{
              return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

  async saerchGigs(body: any): Promise<any>{
    try{
      var page_number :any= body.page_number || 0;
      var number_of_record:any = body.number_of_record || 10;
      var search_str :any = body.search_str || "";
      var gigsData : any = "";
      if(search_str == ""){
        gigsData = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .where("gigs.status = 1")
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
      }else{
        gigsData = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
          .where("gigs.status = 1")
          .andWhere( new Brackets( qb => {
            qb.orWhere("gigs.title like '%"+search_str+"%' or gigs.description like '%"+search_str+"%'")
                .orWhere("gigs_skills.skills like :search_str", { search_str: `%${search_str}%` })
            }
          ))
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)   // offset (from where we want to get record)
          .getMany();
      }
      if(gigsData.length > 0){
        let id : any = [];
        for(let i=0;i<gigsData.length;i++){
            if(!id.includes(gigsData[i].created_by)){
                id.push(gigsData[i].created_by);
            }
        }
        const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users/for/fontpage';
        const json = JSON.stringify({"id": id});
        const res = await axios.post(bigigUserUrl, json, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        for(let i=0;i<gigsData.length;i++){
          let created_by = gigsData[i].created_by;
          for(let j=0;j< res.data.userData.length;j++){
            if(created_by == res.data.userData[j].user.id){
              var admin : any = {
                first_name : res.data.userData[j].user.first_name,
                last_name : res.data.userData[j].user.last_name,
                profile_pic : res.data.userData[j].user.profile_pic,
                average_rating : res.data.userData[j].user.average_rating,
                company_name : res.data.userData[j].company.company_name,
              }
              gigsData[i].admin = admin
              break;
            }
          }
        }
        return {statuscode:200,data:gigsData};
      }else{
        return {statuscode:201};
      }
    }catch(error){console.log(error);
        if(process.env.ENV != "development"){
            rollbar.error(error);
        } 
        return {statuscode:500};
    }
  }

  async getallopenGigslistForSearch(body: any, user: any): Promise<any>{
    try{
        const page_number = body.page_number || 0
        const number_of_record = body.number_of_record || 10
        const fl_id = body.fl_id || 0
        const gigsRepository = getRepository(Gigs);
        const gigs = await gigsRepository.find({ where: {created_by:user.id, status:1} , skip: page_number*number_of_record, take: number_of_record,relations:["projects","gigs_skills"]});
        return {statuscode:200,data:gigs};
    }catch(error){console.log(error);
        if(process.env.ENV != "development"){
            rollbar.error(error);
        } 
        return {statuscode:500};
    }
  }

    async updateGigsAndMilestonesPaymentStatus(body:any):Promise<any>{
        try{
        var type = body.type;
        var item_id = body.item_id;
        const gigsRepo = getRepository(Gigs);
        const milestonesRepo = getRepository(GigsMilestones);
        if(type == "gigs_payment"){
            await gigsRepo.update({id:item_id},{is_commission_paid:1});
        }else{
            await milestonesRepo.update({id:item_id},{is_payment_paid_by_admin:1});
        }
        return {statuscode:200};
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async testCron(){
        const zohoInfoRepo = getRepository(ZohoInfo);
        try{
            var zohoToken :any = await zohoInfoRepo.findOne();
            var time = Date.now()/1000;
            if(zohoToken){
                if(time > zohoToken.expire_time){
                    var createNewAcceessToken =  await zohoCreateAccessToekn();
                    await zohoInfoRepo.update({ accesstoken:zohoToken.accesstoken }, {accesstoken:createNewAcceessToken.access_token, expire_time:time+3500});
                }
            }else{
                var createNewAcceessToken =  await zohoCreateAccessToekn();
                const zohoInfo = new ZohoInfo();
                    zohoInfo.accesstoken = createNewAcceessToken.access_token;
                    zohoInfo.expire_time = time+3500;
                const savedfreelancer:any = await zohoInfoRepo.save(zohoInfo);
            }
        }catch(error){
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            console.log(error);
        }
    }

  async importBids():Promise<any>{
    /*try{
      const readFile = util.promisify(fs.readFile);
      var json_str_bids  = await readFile('freelancers_8000_15877_proposals_new.json','utf8');
      var json_bids = JSON.parse(json_str_bids);
      var result_bids:any = [];
      for(var i in json_bids){
        for(var k in json_bids[i].proposals){
          if(isNaN(json_bids[i].proposals[k])){
            result_bids.push(json_bids[i].proposals[k]);
          }
        }
      }
      const gigsRepository = getRepository(Gigs);
      const userMetaRepo = getRepository(UserMeta);
      const bidRepo = getRepository(Bids);
      async function save_bids(index:any){
        try{
          let wp_fl_id = result_bids[index].author_id;
          let wp_gig_id = result_bids[index].project_id;
          let gig = await gigsRepository.findOne({ where: { wp_id:wp_gig_id}});
          if(gig){
            let gig_id:any = gig.id;
            let bids = new Bids();
            let flMetaData:any = await userMetaRepo.findOne({ where: { meta_key:"wordpress_user_id", meta_value:wp_fl_id}});
            if(flMetaData){
              bids.fl_id = flMetaData.fl_id;
            }else{
              bids.fl_id = 0;
            }
            bids.bidded_on = new Date(result_bids[index].basic.post_date).getTime()/1000;
            bids.gigs = gig_id;
            bids.message = result_bids[index].basic.post_content;
            bids.match_score = 0;
            if(result_bids[index].proposal_hiring_status == ""){
              bids.status = 0;
            }else if(result_bids[index].proposal_hiring_status == "approved"){
              bids.status = 1;
              bids.action_by = "admin";
            }else{
              bids.status = 2;
              bids.action_by = "admin";
            }
            let estimated_budget = 0;
            let estimated_duration = 0;
            let duration_unit = 0;
            let hours_per_week = 0;
            let rate_per_hour = 0;
            if(result_bids[index].proposal_duration_and_amount.project_type == "hourly"){
              rate_per_hour = parseInt(result_bids[index].proposal_duration_and_amount.per_hour_amount);
              hours_per_week = parseInt(result_bids[index].proposal_duration_and_amount.estimeted_time);
              estimated_duration = result_bids[index].proposal_duration_and_amount.estimeted_time;
              duration_unit = 0;
              estimated_budget = rate_per_hour * hours_per_week;
            }else if(result_bids[index].proposal_duration_and_amount.project_type == "default"){
              if(result_bids[index].proposal_duration_and_amount.proposed_amount != "" && result_bids[index].proposal_duration_and_amount.proposed_amount != 0 && result_bids[index].proposal_duration_and_amount.proposed_amount != "0000" && result_bids[index].proposal_duration_and_amount.proposed_amount != "00"){
                estimated_budget = parseInt(result_bids[index].proposal_duration_and_amount.proposed_amount);
              }else{
                estimated_budget = gig.estimated_budget;
              }
              estimated_duration = gig.estimated_duration;
              duration_unit = gig.duration_unit;
              hours_per_week = gig.hours_per_week;
              rate_per_hour = gig.rate_per_hour;
            }else if(result_bids[index].proposal_duration_and_amount.project_type == "fixed"){
              if(result_bids[index].proposal_duration_and_amount.proposed_amount != "" && result_bids[index].proposal_duration_and_amount.proposed_amount != 0 && result_bids[index].proposal_duration_and_amount.proposed_amount != "0000" && result_bids[index].proposal_duration_and_amount.proposed_amount != "00"){
                estimated_budget = parseInt(result_bids[index].proposal_duration_and_amount.proposed_amount);
              }else{
                estimated_budget = gig.estimated_budget;
              }
              hours_per_week = 0;
              rate_per_hour = 0;
              if(result_bids[index].proposal_duration_and_amount.proposed_duration == "three_month"){
                estimated_duration = 3;
                duration_unit = 3;
              }else if(result_bids[index].proposal_duration_and_amount.proposed_duration == "weekly"){
                estimated_duration = 3;
                duration_unit = 2;
              }else if(result_bids[index].proposal_duration_and_amount.proposed_duration == "six_month"){
                estimated_duration = 6;
                duration_unit = 3;
              }else if(result_bids[index].proposal_duration_and_amount.proposed_duration == "more_than_six"){
                estimated_duration = 7;
                duration_unit = 3;
              }else if(result_bids[index].proposal_duration_and_amount.proposed_duration == "yearly"){
                estimated_duration = 1;
                duration_unit = 4;
              }else if(result_bids[index].proposal_duration_and_amount.proposed_duration == "monthly"){
                estimated_duration = 1;
                duration_unit = 3;
              }else if(result_bids[index].proposal_duration_and_amount.proposed_duration == "days"){
                estimated_duration = 10;
                duration_unit = 1;
              }else{
                estimated_duration = 1;
                duration_unit = 3;
              }
            }
            bids.estimated_budget = estimated_budget;
            bids.estimated_duration = estimated_duration;
            bids.duration_unit = duration_unit;
            bids.hours_per_week = hours_per_week;
            bids.rate_per_hour = rate_per_hour;
            let savedBids = await bidRepo.save(bids);
          }
        }catch(er){
          console.log(er)
        }
      }
      for(let i = 0;i<result_bids.length-1;i++){
        save_bids(i);
      }
      return {statuscode:200,data:result_bids};
    }catch(err){
      console.log(err);
      return {statuscode:500};
    }*/
  }

  async importGigs():Promise<any>{
    /*try{
      const readFile = util.promisify(fs.readFile);
      var json_str_gigs  = await readFile('employeer_project_gigs.json','utf8');
      var json_gigs = JSON.parse(json_str_gigs);
      var result_gigs:any = [];
      for(var i in json_gigs){
        if(json_gigs[i].job_status != "cancelled" && json_gigs[i].job_status != "draft"){
          result_gigs.push(json_gigs [i]);
        }
      }
      var json_str_mls = await readFile('proposals_milstones.json','utf8');
      var json_mls = JSON.parse(json_str_mls);
      var result_mls:any = [];
      for(var i in json_mls){
        result_mls.push(json_mls [i]);
      }
      //console.log(result_mls);
      //console.log(result_gigs[0]);
      console.log(result_mls.length);
      const gigsRepository = getRepository(Gigs);
      const gigsSkilsRepository = getRepository(GigsSkills);
      const projectsRepository = getRepository(Projects);
      const gigsMilestoneRepository = getRepository(GigsMilestones);
      const userMetaRepo = getRepository(UserMeta);
      async function save_gigs(index:any){
        try{
          let re = result_gigs[index];
          let gigs_wp_id = re.basic.ID;
          if(gigs_wp_id != 2155 && gigs_wp_id != 137155 && gigs_wp_id != 137218 && gigs_wp_id != 137238 && gigs_wp_id != 1622 && gigs_wp_id != 1630 && gigs_wp_id != 1966 && gigs_wp_id != 2193 && gigs_wp_id != 30683 && gigs_wp_id != 30840){
            let milestones:any = [];
            for(let i = 0;i<result_mls.length;i++){
              if(result_mls[i].project_id == gigs_wp_id){
                milestones.push(result_mls[i]);
              }
            }
            let wp_created_by = re.author_id;
            let userMetaData:any = await userMetaRepo.findOne({ where: { meta_key:"wordpress_user_id", meta_value:wp_created_by}});
            if(userMetaData){
              let created_by = userMetaData.user_id;
              let company_id = userMetaData.company_id;
              let project = new Projects();
              project.company_id = company_id;
              project.created_by = created_by;
              project.updated_by = created_by;
              project.created_at = new Date(re.basic.post_date).getTime()/1000;
              project.updated_at = new Date(re.basic.post_date).getTime()/1000;
              project.title = re.basic.post_title;
              project.give_access_to_hired_pm = 0;
              if(re.job_status == 'completed'){
                project.status = 2;
              }else if(re.job_status == 'hired'){
                project.status = 1;
              }else{
                project.status = 0;
              }
              let savedProject = await projectsRepository.save(project);
              let gigs = new Gigs();
              gigs.created_by = created_by;
              gigs.updated_by = created_by;
              gigs.created_at = new Date(re.basic.post_date).getTime()/1000;
              gigs.updated_at = new Date(re.basic.post_date).getTime()/1000;
              if(re.job_status == 'completed'){
                gigs.status = 3;
              }else if(re.job_status == 'hired'){
                gigs.status = 2;
              }else{
                gigs.status = 1;
              }
              gigs.project_id = savedProject.id;
              gigs.projects = savedProject;
              gigs.type = 0
              gigs.title = re.basic.post_title;
              gigs.jd_url = "";
              gigs.description = re.basic.post_content.replace( /(<([^>]+)>)/ig, '');
              if(re.designation == null){
                gigs.designation = "";
              }else{
                gigs.designation = re.designation;
              }
              gigs.education_id = 0;
              gigs.no_fl_required = 1;
              if(re.job_status == 'completed' || re.job_status == 'hired'){
                gigs.fl_hired = 1;
                let flMetaData:any = await userMetaRepo.findOne({ where: { meta_key:"wordpress_user_id", meta_value:milestones[0].freelancer_id}});
                if(flMetaData){
                  gigs.fl_id = flMetaData.fl_id;
                }else{
                  gigs.fl_id = 0;
                }
              }else{
                gigs.fl_hired = 0;
                gigs.fl_id = 0;
              }
              gigs.fl_payment_meta = "";
              let cost = 0;
              gigs.payment_type = 1;
              if(re.project_type.gadget == "fixed"){
                gigs.payment_type = 0;
                if(re.project_type.fixed.max_price == "" || re.project_type.fixed.max_price == undefined || re.project_type.fixed.max_price == null){
                  cost = re.project_type.fixed.project_cost;
                }else{
                  cost = re.project_type.fixed.max_price;
                }
              }else{
                cost = parseInt(re.project_type.hourly.hourly_rate) * parseInt(re.project_type.hourly.estimated_hours);
              }
              let duration = 1;
              let unit = 1;
              if(re.project_duration_in == "three_month"){
                duration = 3;
                unit = 3;
              }else if(re.project_duration_in == "weekly"){
                duration = 3;
                unit = 2;
              }else if(re.project_duration_in == "six_month"){
                duration = 6;
                unit = 3;
              }else if(re.project_duration_in == "more_than_six"){
                duration = 7;
                unit = 3;
              }else if(re.project_duration_in == "yearly"){
                duration = 1;
                unit = 4;
              }else if(re.project_duration_in == "monthly"){
                duration = 1;
                unit = 3;
              }else if(re.project_duration_in == "days"){
                duration = 10;
                unit = 1;
              }else{
                duration = 1;
                unit = 3;
              }
              if(gigs.payment_type == 0){
                  gigs.estimated_duration = duration;
                  gigs.duration_unit = unit;
                  gigs.estimated_budget = cost;
                  gigs.hours_per_week = 0;
                  gigs.rate_per_hour = 0;
                  gigs.total_budget = cost;
              }else{
                  gigs.estimated_duration = duration;
                  gigs.duration_unit = unit;
                  gigs.estimated_budget = cost;
                  gigs.hours_per_week = re.project_type.hourly.hourly_rate;
                  gigs.rate_per_hour = re.project_type.hourly.estimated_hours;
                  gigs.total_budget = cost;
              }
              gigs.is_imported_from_wp = 1;
              gigs.wp_id = gigs_wp_id;
              if(re.expiry_date != ""){
                gigs.expected_closer = new Date(re.expiry_date).getTime()/1000;
              }else{
                gigs.expected_closer = 0;
              }
              let savedGigs = await gigsRepository.save(gigs);

              for(let i = 0 ; i< re.skills.length; i++){
                let gigsSkills = new GigsSkills()
                    gigsSkills.gigs = savedGigs;
                    gigsSkills.skills = re.skills[i].name;
                let savedGigSkill = await gigsSkilsRepository.save(gigsSkills);
              }


              for(let k = 0;k<milestones.length;k++){
                let gigsMilestones = new GigsMilestones();
                gigsMilestones.created_at = new Date(milestones[k].basic.post_date).getTime()/1000;
                gigsMilestones.updated_at = new Date(milestones[k].basic.post_date).getTime()/1000;
                gigsMilestones.created_by = created_by;
                gigsMilestones.updated_by = created_by;
                gigsMilestones.description = milestones[k].basic.post_content;
                gigsMilestones.title = milestones[k].basic.post_title;
                gigsMilestones.gigs = savedGigs;
                gigsMilestones.estimated_duration = 0;
                gigsMilestones.duration_unit = 0;
                gigsMilestones.estimated_budget = milestones[k].milstone_price_single;
                if(re.job_status == 'completed'){
                  gigsMilestones.status = 3;
                }else if(milestones[k].milstone_status == "pending"){
                  gigsMilestones.status = 0;
                }else{
                  gigsMilestones.status = 1;
                }
                if(milestones.length == 1){
                  gigsMilestones.estimated_duration = gigs.estimated_duration;
                  gigsMilestones.duration_unit = gigs.duration_unit;
                }else{
                  if(gigs.estimated_duration == 5 && gigs.duration_unit == 1){
                    gigsMilestones.estimated_duration = 5;
                    gigsMilestones.duration_unit = 1;
                  }else if(gigs.estimated_duration == 3 && gigs.duration_unit == 3){
                    gigsMilestones.estimated_duration = 1;
                    gigsMilestones.duration_unit = 2;
                  }else if(gigs.estimated_duration == 3 && gigs.duration_unit == 3){
                    gigsMilestones.estimated_duration = 3;
                    gigsMilestones.duration_unit = 1;
                  }else if(gigs.estimated_duration == 1 && gigs.duration_unit == 4){
                    gigsMilestones.estimated_duration = 2;
                    gigsMilestones.duration_unit = 3;
                  }else{
                    gigsMilestones.estimated_duration = gigs.estimated_duration;
                    gigsMilestones.duration_unit = gigs.duration_unit;
                  }
                }
                gigsMilestones.is_imported_from_wp = 1;
                gigsMilestones.wp_id = milestones[k].basic.ID;
                let saveMilestone = await gigsMilestoneRepository.save(gigsMilestones);
              }

            }



          }
        }catch(er){
          console.log(er);
        }
      }
      for(let i = 0;i<result_gigs.length-1;i++){
        save_gigs(i);
      }


      return {statuscode:200,data:result_gigs};
    }catch(error){
      console.log(error);
      return {statuscode:500};
    }*/
  }

}
