import { Projects } from "../models/Projects";
import { getRepository, LessThan, MoreThan, MoreThanOrEqual, Not } from 'typeorm';
import { JobsService } from '../services/JobsService';
import e from "express";
import { Gigs } from "../models/Gigs";
import { DraftedGigs } from "../models/DraftedGigs";
import { ZohoInfo } from "../models/ZohoInfo";
import { resolve } from "bluebird";
import { rejects } from "assert";
const {createProjectOnZoho,updateProjectOnZoho} = require('../helper/zohoApi');
var bcrypt = require('bcryptjs');
const axios = require('axios');
require('dotenv').config()
const jwt = require('jsonwebtoken')
const {rollbar} = require('../helper/rollbar');


export class ProjectService {

    async updateProject(body: any, project_id: any, user: any) {
        try{
            const projectRepository = getRepository(Projects);
            const zohoInfoRepo = getRepository(ZohoInfo);
            let company_id = user.company_id;
            let updated_data = await projectRepository.update({id:project_id,company_id:company_id},{title:body.title,updated_by:user.id,updated_at:Date.now()/1000});
             //update project title on zoho
             try{
                let projectData :any= await projectRepository.find({id:project_id,company_id:company_id});
                var updateData = {
                    Deal_Name: body.title
                }
                var zohoToken :any = await zohoInfoRepo.findOne();
                await updateProjectOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,updateData);
            }catch(error){
                console.log(error);
            }
            if(updated_data.affected){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async addProject(body: any, user: any) {
        try{
            const zohoInfoRepo = getRepository(ZohoInfo);
            let created_by = user.id;
            let company_id = user.company_id;
            let title = body.title;
            var time = Date.now()/1000;
            let project = new Projects();
            const projectRepository = getRepository(Projects);

            project.company_id = company_id;
            project.created_by = created_by;
            project.updated_by = created_by;
            project.created_at = time;
            project.updated_at = time;
            project.title = title;
            project.give_access_to_hired_pm = 0;
            project.status = 0;

            let savedProject = await projectRepository.save(project);
             //Create project on zoho
             try{
                var zohoToken :any = await zohoInfoRepo.findOne();
                var Account_Name = user.zoho_enterprise_id;
                var Contact_Name = user.zoho_user_id;
                var Type = user.zoho_enterprise_id;
                var Description = user.title;
                var Deal_Name = title;
                var Amount = "";
                var Stage = "Pending";
                var Lead_Source = "";
                var Closing_Date = ""
                var createZohoProject :any = await createProjectOnZoho(zohoToken.accesstoken,Account_Name,Contact_Name,Type,Description,Deal_Name,Amount,Stage,Lead_Source,Closing_Date);

                //Upate zoho project id in project table
                projectRepository.update({id: savedProject.id},{zoho_project_id:createZohoProject.data[0].details.id, zoho_user_id:user.zoho_user_id, zoho_enterprise_id:user.zoho_enterprise_id});

            }catch(error){
                console.log(error);
            }
            ////////////////////////////////////////////////////////////////////////
            return {statuscode:200, projectData:{id: savedProject.id,title: savedProject.title}};

        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

    async projectList(body: any, user: any): Promise<any>{
        try{
            var status = body.project_type;
            const projectsRepo = getRepository(Projects);
            const gigsRepository = getRepository(Gigs);
            var data = [];
            if(status == 0){
                var project :any = await projectsRepo
                .createQueryBuilder("projects")
                .where("projects.created_by = :id AND projects.is_deleted = 0 AND (projects.status = 0 OR projects.status = 1)" , { id: user.id}).orderBy('projects.created_at', 'DESC')
                .getMany();

                for(let i = 0; i< project.length; i++){
                    if(project[i].status == 1){
                        console.log(project[i].id);
                        let check = await gigsRepository.find({ where:{projects:project[i].id, status:1}});
                        if(check.length > 0){
                            data.push(project[i]);
                        }
                    }else{
                        data.push(project[i]);
                    }
                }

            }else if(status == 1){
                var  projectdata:any = await projectsRepo.find({ where: {created_by:user.id, status: 1, is_deleted:0}, order: {created_at: "DESC"}});

                data = projectdata

            } else{
                var  projectdata:any = await projectsRepo.find({ where: {created_by:user.id, status: 2, is_deleted:0}, order: {created_at: "DESC"}});
                data = projectdata
            }
            if(data.length>0){
                return {statuscode:200,data:data};
            }else {
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }
            return {statuscode:500};
        }
    }

    async draftedGigsList(body: any, user: any): Promise<any>{
        try{
            const draftedGigsRepository = getRepository(DraftedGigs);
            const projectsRepo = getRepository(Projects);
            const gigs = await draftedGigsRepository.find({where: { created_by:user.id},relations:["projects"]});
            var project_ids: number[] = [];
            for(let i = 0;i<gigs.length;i++){
                let prj_id = gigs[i].projects.id;
                if(project_ids.indexOf(prj_id) == -1){
                project_ids.push(prj_id);
                }
            }
            const projects = await projectsRepo.createQueryBuilder("projects").where("projects.id IN (:...ids)", { ids: project_ids }).getMany();
            if(projects.length>0){
                return {statuscode:200,data:projects};
            }else {
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }
        }
    }

    async freelancerReviewList(project_id: any,token:any): Promise<any> {
        try{
            const gigsRepository = getRepository(Gigs);
            const gigDetails:any = await gigsRepository.find({where: { project_id: project_id }, select: ["id","title", "description", "fl_id"] });
            let gig_id : any = [];
            for(let i=0;i<gigDetails.length;i++){
                if(!gig_id.includes(gigDetails[i].id)){
                    gig_id.push(gigDetails[i].id);
                }
            }
            const json = JSON.stringify({"gig_id": gig_id});
            const res = await axios.post(process.env.Begig_user_url+'api/v1/user/freelancer/reviewlist', json, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `${token.authorization}`
                }
            });
            if(res.data.freelancerData == undefined || res.data.freelancerData == null){
                return {statuscode:201};
            }
            for(let i=0;i<gigDetails.length;i++){
                let id = gigDetails[i].id;
                for(let j=0;j< res.data.freelancerData.length;j++){
                    if(id == res.data.freelancerData[j].freelancerFeedback[0].gig_id){
                        var freelancer : any = {
                            first_name : res.data.freelancerData[j].user.first_name,
                            last_name : res.data.freelancerData[j].user.last_name,
                            profile_pic : res.data.freelancerData[j].user.profile_pic,
                            average_rating : res.data.freelancerData[j].freelancerFeedback[0].average_rating
                        }
                        gigDetails[i].freelancer = freelancer
                        break;
                    }
                }
            }
            if(gigDetails.length>0){
                return {statuscode:200,data:gigDetails};
            }else {
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

}
