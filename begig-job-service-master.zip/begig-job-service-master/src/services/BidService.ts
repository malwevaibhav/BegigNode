import { Gigs } from "../models/Gigs";
import { Projects } from "../models/Projects";
import { getRepository, LessThan, MoreThan, MoreThanOrEqual, Not } from 'typeorm';
import { GigsSkills } from "../models/GigsSkills";
import { GigsMilestones } from "../models/GigsMilestones";
import { GigsInvitation } from "../models/GigsInvitation";
import { InvitationMilestoneSuggetions } from "../models/InvitationMilestoneSuggetions";
import { InviteMilestoneSuggestionAdmin } from "../models/InviteMilestoneSuggestionAdmin";
import { GigsAttachments } from "../models/GigsAttachments";
import { FinalOfferInvite } from "../models/FinalOfferInvite";
import { Bids } from "../models/Bids";
const {createMilestonesOnZoho,updateProjectOnZoho,updateGigOnZoho,createGigOnZoho} = require('../helper/zohoApi');
import { ZohoInfo } from "../models/ZohoInfo";
import { BidMilestoneSuggetions } from "../models/BidMilestoneSuggetions";
import { FinalOfferBids } from "../models/FinalOfferBids";
var bcrypt = require('bcryptjs');
const axios = require('axios');
require('dotenv').config()
const jwt = require('jsonwebtoken')
const {rollbar} = require('../helper/rollbar');

export class BidService {

    async sendBid(body: any, user: any, token:any): Promise<any>{
        try{
            const fl_id = user.freelancer_id;
            const gig_id = body.gig_id;
            const estimated_duration = body.estimated_duration;
            const duration_unit = body.duration_unit;
            const estimated_budget = body.estimated_budget;
            const hours_per_week = body.hours_per_week || 0;
            const rate_per_hour = body.rate_per_hour || 0;
            const bidRepo = getRepository(Bids);
            const bidMilestoneSuggestionAdminRepo = getRepository(BidMilestoneSuggetions);
            let check = await bidRepo.find({fl_id:fl_id,gigs:gig_id});
            if(check.length > 0){ // already bid sent
                return {statuscode:201};
            }else{
                let match_score = body.match_score || 0;
                let bids = new Bids();
                var time = Date.now()/1000;
                bids.fl_id = fl_id;
                bids.bidded_on = time;
                bids.gigs = gig_id;
                bids.message = body.message;
                bids.estimated_budget = estimated_budget;
                bids.estimated_duration = estimated_duration;
                bids.duration_unit = duration_unit;
                bids.hours_per_week = hours_per_week;
                bids.rate_per_hour = rate_per_hour;
                bids.match_score = match_score;
                let savedBids = await bidRepo.save(bids);
                for(let i=0;i<body.milestones.length;i++){
                    let bidMilestoneSuggetions = new BidMilestoneSuggetions();
                    bidMilestoneSuggetions.created_at = time;
                    bidMilestoneSuggetions.description = body.milestones[i].description;
                    bidMilestoneSuggetions.bids = savedBids;
                    bidMilestoneSuggetions.gig_id = gig_id;
                    bidMilestoneSuggetions.title = body.milestones[i].title;
                    bidMilestoneSuggetions.estimated_duration = body.milestones[i].estimated_duration;
                    bidMilestoneSuggetions.duration_unit = body.milestones[i].duration_unit;
                    bidMilestoneSuggetions.payment_type = body.milestones[i].payment_type;
                    bidMilestoneSuggetions.estimated_budget = body.milestones[i].estimated_budget;
                    let saveMilestone = await bidMilestoneSuggestionAdminRepo.save(bidMilestoneSuggetions);
                }
                /* send email to gig admin starts */
                const gigRepository = getRepository(Gigs);
                var gig_data:any = await gigRepository.findOne({where:{id:gig_id}});
                let created_by = gig_data.created_by;
                let gig_name = gig_data.title;
                let project_id = gig_data.project_id;
                const json = JSON.stringify({"created_by": created_by,"gig_name":gig_name,"gig_id":gig_id,"project_id":project_id,"fl_id":fl_id});
                const res = axios.post(process.env.Begig_user_url+'api/v1/user/send/bids/email', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                /* send email to gig admin ends */
                let ids : any = [created_by];
                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications';
                let meta_data = {"project_id":project_id,"gig_id":gig_data.id,"redirect_on":"hire_freelancer","view":"admin","notification_type":"bid_recived",fl_id:fl_id,created_by:gig_data.created_by}
                const json2 = JSON.stringify({"ids": ids,"message":"A bid is Received on "+gig_name+" from {{fl_name}}","meta_data":meta_data});
                axios.post(bigigUserUrl, json2, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                return {statuscode:200};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            }  
            return {statuscode:500};
        }
    }

    async bidListFL(body: any, user: any, token:any): Promise<any>{
        try{
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            const bidsRepo = getRepository(Bids);

            let data : any = await getRepository(Bids)
                .createQueryBuilder("bids")
                .leftJoinAndSelect("bids.gigs", "gigs")
                .leftJoinAndSelect("bids.milestone_suggetions", "milestone_suggetions")
                .leftJoinAndSelect("bids.final_offer", "final_offer")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("bids.fl_id = "+user.freelancer_id+" and bids.status = 0 and gigs.status = 1")
                .skip(page_number*number_of_record)
                .take(number_of_record)
                .orderBy('bids.bidded_on', 'DESC')
                .getMany();

            if(data.length>0){
                let id : any = [];
                for(let i=0;i<data.length;i++){
                    if(!id.includes(data[i].gigs.created_by)){
                    id.push(data[i].gigs.created_by);
                    }
                }

                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/users', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<data.length;i++){
                    let gigId = data[i].gigs.created_by;
                    for(let j=0;j< res.data.userData.length;j++){

                        if(gigId == res.data.userData[j].user.id){
                            var admin : any = {
                                first_name : res.data.userData[j].user.first_name,
                                last_name : res.data.userData[j].user.last_name,
                                profile_pic : res.data.userData[j].user.profile_pic,
                                average_rating : res.data.userData[j].user.average_rating,
                                company_name : res.data.userData[j].company.company_name,
                            }
                            data[i].gigs.admin = admin
                            break;
                        }
                    }
                }

                return {statuscode:200,data:data};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }  
            return {statuscode:500};
        }
    }

    async bidsListAdmin(body: any, user: any, token:any): Promise<any>{
        try{
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            const bidsRepo = getRepository(Bids);
            let data :any = await bidsRepo.find({where:{gigs:body.gig_id,status:0}, relations:["milestone_suggetions","final_offer"], skip: page_number*number_of_record, take: number_of_record});
            if(data.length>0){
                let id : any = [];
                for(let i=0;i<data.length;i++){
                    if(!id.includes(data[i].fl_id)){
                    id.push(data[i].fl_id);
                    }
                }

                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<data.length;i++){
                    let fl_id = data[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){

                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            data[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:data};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async acceptBidAdmin(body: any, user: any, token:any): Promise<any>{
        try{
            const bidId =  body.bid_id;
            const admin_id = user.id;
            const bidsRepo = getRepository(Bids);
            const gigRepository = getRepository(Gigs);
            const gigsSkilsRepository = getRepository(GigsSkills);
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            const projectRepository = getRepository(Projects);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var zohoToken :any = await zohoInfoRepo.findOne();
            let data : any = await bidsRepo.find({where:{id:bidId,status:0},relations:["milestone_suggetions","gigs"]});

            if(data.length > 0){
                if(data[0].milestone_suggetions.length > 0){
                    const gigsMilestoneRepository = getRepository(GigsMilestones);
                    let res:any = await gigsMilestoneRepository.delete({gigs:data[0].milestone_suggetions[0].gig_id});
                    await bidsRepo.update({id:bidId},{status:1, action_by:"admin"});
                    var gig_data:any = await gigRepository.findOne({where:{id:data[0].milestone_suggetions[0].gig_id} , relations:["gigs_skills", "gigs_attachments","projects"]});
                    //zoho code
                    var projectData :any= await projectRepository.find({id:data[0].gigs.project_id});
                    var zohoMileStoneStatus = "Pending";
                    var zohoMileStonesEndDate = "";
                    var Payment_done_by_admin = false;
                    var Payment_done_to_FL = false;
                    ////////////
                    var time = Date.now()/1000;
                    var budget_used = 0;
                    var duration_used = 0;
                    var flZohoId:any = 0;
                    try{
                        const json = JSON.stringify({"id": [data[0].fl_id]});
                        const flData = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': `${token.authorization}`
                            }
                        });
                        flZohoId = flData.data.freelancerData[0].user.zoho_user_id
                    }catch(error){
                        console.log(error);
                    }
                    async function createMilestone(index:number){
                        var zoho_milestones_id = 0;
                        try{
                            var zoho_milestones_duration = "";
                            if(data[0].milestone_suggetions[index].duration_unit = 0){
                                zoho_milestones_duration = data[0].milestone_suggetions[index].estimated_duration + ' hours';
                            }else if(data[0].milestone_suggetions[index].duration_unit = 1){
                                zoho_milestones_duration = data[0].milestone_suggetions[index].estimated_duration + ' days';
                            }else if(data[0].milestone_suggetions[index].duration_unit = 2){
                                zoho_milestones_duration = data[0].milestone_suggetions[index].estimated_duration + ' weeks';
                            }else if(data[0].milestone_suggetions[index].duration_unit = 3){
                                zoho_milestones_duration = data[0].milestone_suggetions[index].estimated_duration + ' months';
                            }else{
                                zoho_milestones_duration = data[0].milestone_suggetions[index].estimated_duration + ' years';
                            }

                            var createMilestoneOnZoho :any = await createMilestonesOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,gig_data.zoho_gigs_id,data[0].milestone_suggetions[index].description,data[0].milestone_suggetions[index].title, zohoMileStoneStatus,zohoMileStonesEndDate,Payment_done_by_admin,Payment_done_to_FL, zoho_milestones_duration,data[0].milestone_suggetions[index].estimated_budget,flZohoId);
                            zoho_milestones_id = createMilestoneOnZoho.data[0].details.id;
                        }catch(error){
                            console.log(error);
                        }
                        let gigsMilestones = new GigsMilestones();
                        gigsMilestones.created_at = time;
                        gigsMilestones.updated_at = time;
                        gigsMilestones.created_by = admin_id;
                        gigsMilestones.updated_by = admin_id;
                        gigsMilestones.description = data[0].milestone_suggetions[index].description;
                        gigsMilestones.title = data[0].milestone_suggetions[index].title;
                        gigsMilestones.gigs = data[0].milestone_suggetions[index].gig_id;
                        gigsMilestones.estimated_duration = data[0].milestone_suggetions[index].estimated_duration;
                        gigsMilestones.duration_unit = data[0].milestone_suggetions[index].duration_unit;
                        gigsMilestones.estimated_budget = data[0].milestone_suggetions[index].estimated_budget;
                        gigsMilestones.zoho_milestones_id = zoho_milestones_id;
                        gigsMilestones.status = 0;
                        let saveMilestone = await gigsMilestoneRepository.save(gigsMilestones);

                    }
                    for(let i = 0; i<data[0].milestone_suggetions.length; i++){

                        budget_used = budget_used + parseInt(data[0].milestone_suggetions[i].estimated_budget);
                        duration_used = duration_used + parseInt(data[0].milestone_suggetions[i].duration_unit);
                        createMilestone(i);
                    }


                    if(gig_data.no_fl_required == 1){
                        await gigRepository.update({id:data[0].milestone_suggetions[0].gig_id}, {status:2,fl_id:data[0].fl_id,estimated_duration:data[0].estimated_duration,duration_unit:data[0].duration_unit,estimated_budget:data[0].estimated_budget,hours_per_week:data[0].hours_per_week,rate_per_hour:data[0].rate_per_hour,total_budget:data[0].estimated_budget});
                        //Update gig status on zoho // change into In Progress
                        var zoho_gig_duration = "";
                        if(data[0].duration_unit = 0){
                            zoho_gig_duration = data[0].estimated_duration + ' hours';
                        }else if(data[0].duration_unit = 1){
                            zoho_gig_duration = data[0].estimated_duration + ' days';
                        }else if(data[0].duration_unit = 2){
                            zoho_gig_duration = data[0].estimated_duration + ' weeks';
                        }else if(data[0].duration_unit = 3){
                            zoho_gig_duration = data[0].estimated_duration + ' months';
                        }else{
                            zoho_gig_duration = data[0].estimated_duration + ' years';
                        }
                        try{
                            var updateGigData =  {
                                Gig_Status: "In Progress",
                                Gig_duration:zoho_gig_duration,
                                Gig_budget:data[0].estimated_budget,
                                Free_Lancer: {
                                    id: flZohoId
                                }
                            }
                            updateGigOnZoho(zohoToken.accesstoken,gig_data.zoho_gigs_id,updateGigData);
                        }catch(error){
                            console.log(error);
                        }
                        //////////////////////////////
                        await projectRepository.update({id:gig_data.project_id}, {status:1});
                        //update project stastus - inprogress
                        try{
                            var updateData = {
                                Stage: "In Progress"
                            }
                            updateProjectOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,updateData);
                        }catch(error){
                            console.log(error);
                        }
                        /////////////////////////////
                    }else{
                        await gigRepository.update({id:data[0].milestone_suggetions[0].gig_id}, {status:2,fl_id:data[0].fl_id,no_fl_required:1,estimated_duration:data[0].estimated_duration,duration_unit:data[0].duration_unit,estimated_budget:data[0].estimated_budget,hours_per_week:data[0].hours_per_week,rate_per_hour:data[0].rate_per_hour,total_budget:data[0].estimated_budget,fl_payment_meta:JSON.stringify([{estimated_duration:data[0].estimated_duration,duration_unit:data[0].duration_unit,estimated_budget:data[0].estimated_budget,rate_per_hour:data[0].rate_per_hour,hours_per_week:data[0].hours_per_week}])});
                        //Update gig status on zoho // change into In Progress
                        var zoho_gig_duration = "";
                        if(data[0].duration_unit = 0){
                            zoho_gig_duration = data[0].estimated_duration + ' hours';
                        }else if(data[0].duration_unit = 1){
                            zoho_gig_duration = data[0].estimated_duration + ' days';
                        }else if(data[0].duration_unit = 2){
                            zoho_gig_duration = data[0].estimated_duration + ' weeks';
                        }else if(data[0].duration_unit = 3){
                            zoho_gig_duration = data[0].estimated_duration + ' months';
                        }else{
                            zoho_gig_duration = data[0].estimated_duration + ' years';
                        }
                        try{
                            var updateGigsData =  {
                                Gig_Status: "In Progress",
                                Gig_duration:zoho_gig_duration,
                                Gig_budget:data[0].estimated_budget,
                                Free_Lancer: {
                                id: flZohoId
                                }
                            }
                            updateGigOnZoho(zohoToken.accesstoken,gig_data.zoho_gigs_id,updateGigsData);
                        }catch(error){
                            console.log(error);
                        }
                        //////////////////////////////
                        await projectRepository.update({id:gig_data.project_id}, {status:1});
                        //update project stastus - inprogress
                        try{
                            var updateData = {
                                Stage: "In Progress"
                            }
                            updateProjectOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,updateData);
                        }catch(error){
                            console.log(error);
                        }
                        let fl_required_for_new_gigs = parseInt(gig_data.no_fl_required) - 1;
                        let gigs = new Gigs()
                        gigs.created_by = gig_data.created_by;
                        gigs.updated_by = gig_data.updated_by;
                        gigs.created_at = gig_data.created_at;
                        gigs.updated_at = gig_data.updated_at;
                        gigs.status = gig_data.status;
                        gigs.project_id = gig_data.project_id;
                        gigs.projects = gig_data.projects;
                        gigs.type = gig_data.type; //(0 = fl_pm_required_for_breakdown_only , 1 =fl_pm_required_for_e2e_delivery , 2 =no_assistance_required , 4 = contract_hiring)
                        gigs.title = gig_data.title;
                        gigs.description = gig_data.description;
                        gigs.designation = gig_data.designation;
                        gigs.education_id = gig_data.education_id;
                        gigs.fl_hired = 0;
                        let tempArr = [];
                        let meta_obj;
                        if(data[0].gigs.fl_payment_meta != ""){
                          meta_obj = JSON.parse(data[0].gigs.fl_payment_meta);
                        }else{
                          meta_obj = [{rate_per_hour:data[0].gigs.rate_per_hour,hours_per_week:data[0].gigs.hours_per_week}];
                        }
                        for(let i =0 ;i < fl_required_for_new_gigs; i++){
                            let obj = {estimated_duration:gig_data.estimated_duration, duration_unit:gig_data.duration_unit,estimated_budget:Math.trunc((parseInt(gig_data.estimated_budget) - budget_used) / fl_required_for_new_gigs),rate_per_hour:meta_obj[0].rate_per_hour,hours_per_week:meta_obj[0].hours_per_week}
                            tempArr.push(obj);
                        }
                        gigs.fl_payment_meta = JSON.stringify(tempArr);
                        gigs.required_exerience = gig_data.required_exerience;
                        gigs.payment_type = gig_data.payment_type; //(0 = fixed , 1 = time_and_material , 2=open_for_discussion)
                        gigs.is_created_by_pm = gig_data.is_created_by_pm;
                        console.log("estimated budget = "+gig_data.estimated_budget);
                        console.log("budget used = "+budget_used);
                        if(fl_required_for_new_gigs == 1){
                            gigs.no_fl_required = fl_required_for_new_gigs;
                            gigs.estimated_duration = gig_data.estimated_duration;
                            gigs.duration_unit = gig_data.duration_unit;
                            gigs.estimated_budget = Math.trunc(gig_data.estimated_budget - budget_used);
                            gigs.hours_per_week = gig_data.hours_per_week;
                            gigs.rate_per_hour = gig_data.rate_per_hour;
                            gigs.total_budget = Math.trunc(gig_data.estimated_budget - budget_used);
                        }else{
                            gigs.no_fl_required = fl_required_for_new_gigs;
                            gigs.estimated_duration = gig_data.estimated_duration;
                            gigs.duration_unit = gig_data.duration_unit;
                            gigs.estimated_budget = Math.trunc(gig_data.estimated_budget - budget_used);
                            gigs.hours_per_week = gig_data.hours_per_week;
                            gigs.rate_per_hour = gig_data.rate_per_hour;
                            gigs.total_budget = Math.trunc(gig_data.total_budget - budget_used);
                        }
                        let savedGigs = await gigRepository.save(gigs);

                        for(let z = 0 ; z< gig_data.gigs_skills.length; z++){
                            let gigsSkills = new GigsSkills()
                            gigsSkills.gigs = savedGigs;
                            gigsSkills.skills = gig_data.gigs_skills[z].skills;
                            gigsSkilsRepository.save(gigsSkills);
                        }

                        for(let z = 0 ; z< gig_data.gigs_attachments.length; z++){
                            let gigsAttach = new GigsAttachments()
                            gigsAttach.created_by = gig_data.gigs_attachments[z].created_by;
                            gigsAttach.gigs = savedGigs;
                            gigsAttach.attachment_url =  gig_data.gigs_attachments[z].attachment_url;
                            gigsAttach.created_at = gig_data.gigs_attachments[z].created_at;
                            gigsGigsAttachmentsRepository.save(gigsAttach);
                        }
                        try{
                            //create gig on zoho
                            var zoho_gig_duration = "";
                            if(gigs.duration_unit = 0){
                                zoho_gig_duration = gig_data.estimated_duration + ' hours';
                            }else if(gigs.duration_unit = 1){
                                zoho_gig_duration = gig_data.estimated_duration + ' days';
                            }else if(gigs.duration_unit = 2){
                                zoho_gig_duration = gig_data.estimated_duration + ' weeks';
                            }else if(gigs.duration_unit = 3){
                                zoho_gig_duration = gig_data.estimated_duration + ' months';
                            }else{
                                zoho_gig_duration = gig_data.estimated_duration + ' years';
                            }
                            var Deal = projectData[0].zoho_project_id;
                            var Description = gigs.description;
                            var Name = gigs.title;
                            var Gig_Status = "Pending";
                            var Gigs_Id = savedGigs.id.toString();
                            var Gig_duration = zoho_gig_duration;
                            var Gig_budget =  gigs.total_budget;
                            var zohoToken :any = await zohoInfoRepo.findOne();
                            var createGigsOnZoho :any = await createGigOnZoho(zohoToken.accesstoken,Deal,Description,Name,Gig_Status,Gigs_Id,Gig_duration,Gig_budget);

                            await gigRepository.update({ id:savedGigs.id}, {zoho_user_id:user.zoho_user_id, zoho_enterprise_id:user.zoho_enterprise_id, zoho_gigs_id:createGigsOnZoho.data[0].details.id});

                        }catch(error){
                            console.log(error);
                        }
                    }
                    try{
                    await gigRepository.update({id:data[0].milestone_suggetions[0].gig_id}, {status:2,fl_id:data[0].fl_id});
                    const jsn = JSON.stringify({"user_id": gig_data.created_by});
                    const re = await axios.post(process.env.Begig_user_url+'api/v1/user/superadmin/account', jsn, {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `${token.authorization}`
                        }
                    });
                    // 12% commision on gig amount
                    let amount = (data[0].estimated_budget / 100) * 12;
                    const json = JSON.stringify({"item_id": gig_data.id, "zoho_item_id":gig_data.zoho_gigs_id, "messages":"Invoice for charges on hiring freelancer on you gig: "+gig_data.title, "user_id":re.data.data.owner_id,"owner_account":re.data.data.owner_account,"amount":amount });
                    const res2 = axios.post(process.env.Begig_payment_url+'api/v1/payment/superadmin/commision/invoice', json, {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `${token.authorization}`
                        }
                    });
                    }catch(err){
                        console.log(err);
                        if(process.env.ENV != "development"){
                            rollbar.error(err);
                        } 
                    }
                    let ids : any = [data[0].fl_id];
                    const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications/fls';
                    let meta_data = {"project_id":null,"gig_id":gig_data.id,"redirect_on":"in_progress","view":"freelancer","fl_id":data[0].fl_id,created_by:gig_data.created_by,"notification_type":"admin_accept_fl_offer"}
                    const json = JSON.stringify({"ids": ids,"message":"Congratulations! You are finally on the board. {{company_name}}","meta_data":meta_data});
                    axios.post(bigigUserUrl, json, {
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    });
                    return {statuscode:200};
                }else{
                    return {statuscode:202};
                }
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

    async acceptBidFL(body: any, user: any,token:any): Promise<any>{
        try{
            const bidId =  body.bid_id;
            const bidsRepo = getRepository(Bids);
            const gigRepository = getRepository(Gigs);
            const gigsSkilsRepository = getRepository(GigsSkills);
            const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
            const projectRepository = getRepository(Projects);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var zohoToken :any = await zohoInfoRepo.findOne();
            let data : any = await bidsRepo.find({where:{id:bidId},relations:["gigs","final_offer"]});
            if(data.length>0){
                if(data[0].final_offer.length <=0){
                    return {statuscode:202};
                }else{
                    await bidsRepo.update({id:bidId},{status:1, action_by:"fl"});
                    var gig_data:any = await gigRepository.findOne({where:{id:data[0].gigs.id} , relations:["gigs_skills", "gigs_attachments","projects"]});
                    var budget_used = 0;
                    var milestones :any= [];
                    milestones = data[0].final_offer;
                    const gigsMilestoneRepository = getRepository(GigsMilestones);
                    let res:any = await gigsMilestoneRepository.delete({gigs:milestones[0].gig_id});
                    var time = Date.now()/1000;
                    var budget_used = 0;
                    var duration_used = 0;
                    // zoho paramenters
                    var projectData :any= await projectRepository.find({id:data[0].gigs.project_id});
                    var zohoMileStoneStatus = "Pending";
                    var zohoMileStonesEndDate = "";
                    var Payment_done_by_admin = false;
                    var Payment_done_to_FL = false;
                    /////////////////////////

                    async function createMilestone(index:number){
                        let gig_id = milestones[index].gig_id;
                        let zoho_milestones_id = 0;
                        try{
                            //Create milestone on zoho
                            var zoho_milestones_duration = "";
                            if(milestones[index].duration_unit = 0){
                                zoho_milestones_duration =milestones[index].estimated_duration + ' hours';
                            }else if(milestones[index].duration_unit = 1){
                                zoho_milestones_duration = milestones[index].estimated_duration + ' days';
                            }else if(milestones[index].duration_unit = 2){
                                zoho_milestones_duration = milestones[index].estimated_duration + ' weeks';
                            }else if(milestones[index].duration_unit = 3){
                                zoho_milestones_duration = milestones[index].estimated_duration + ' months';
                            }else{
                                zoho_milestones_duration = milestones[index].estimated_duration + ' years';
                            }
                            var createMilestoneOnZoho :any = await createMilestonesOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,gig_data.zoho_gigs_id,milestones[index].description,milestones[index].title, zohoMileStoneStatus,zohoMileStonesEndDate,Payment_done_by_admin,Payment_done_to_FL, zoho_milestones_duration, milestones[index].estimated_budget,user.zoho_user_id);
                            zoho_milestones_id = createMilestoneOnZoho.data[0].details.id;

                        }catch(error){
                            console.log(error);
                        }
                        let gigsMilestones = new GigsMilestones();
                        gigsMilestones.created_at = time;
                        gigsMilestones.updated_at = time;
                        gigsMilestones.created_by = gig_data.created_by;
                        gigsMilestones.updated_by = gig_data.updated_by;
                        gigsMilestones.description = milestones[index].description;
                        gigsMilestones.title = milestones[index].title;
                        gigsMilestones.gigs = milestones[index].gig_id;
                        gigsMilestones.estimated_duration = milestones[index].estimated_duration;
                        gigsMilestones.duration_unit = milestones[index].duration_unit;
                        gigsMilestones.estimated_budget = milestones[index].estimated_budget;
                        gigsMilestones.status = 0;
                        gigsMilestones.zoho_milestones_id = zoho_milestones_id;
                        let saveMilestone = await gigsMilestoneRepository.save(gigsMilestones);

                    }
                    for(let i = 0; i<milestones.length; i++){
                        budget_used = budget_used + parseInt(milestones[i].estimated_budget);
                        duration_used = duration_used + parseInt(milestones[i].duration_unit);
                        createMilestone(i);
                    }
                    if(gig_data.no_fl_required == 1){
                        await gigRepository.update({id:data[0].gigs.id}, {status:2, fl_id:data[0].fl_id,estimated_budget:budget_used,total_budget:budget_used});
                        //Update gig status on zoho (change into In Progress)
                        try{
                            var updateGigsData =  {
                                Gig_Status: "In Progress",
                                Gig_budget:budget_used,
                                Free_Lancer: {
                                id: user.zoho_user_id
                                }
                            }
                            updateGigOnZoho(zohoToken.accesstoken,gig_data.zoho_gigs_id,updateGigsData);
                        }catch(error){
                            console.log(error);
                        }
                        //////////////////////////////
                        await projectRepository.update({id:gig_data.project_id}, {status:1});
                        //update project status on zoho (change stage to In progress)
                        try{
                            var updateData = {
                                Stage: "In Progress"
                            }
                            updateProjectOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,updateData);
                        }catch(error){
                            console.log(error);
                        }
                        ///////////////////////
                    }else{
                        await gigRepository.update({id:data[0].gigs.id}, {status:2, fl_id:data[0].fl_id , no_fl_required:1,total_budget:budget_used,estimated_budget:budget_used,estimated_duration:data[0].estimated_duration,duration_unit:data[0].duration_unit,hours_per_week:data[0].hours_per_week,rate_per_hour:data[0].rate_per_hour,fl_payment_meta:JSON.stringify([{estimated_duration:data[0].estimated_duration,duration_unit:data[0].duration_unit,estimated_budget:data[0].estimated_budget,rate_per_hour:data[0].rate_per_hour,hours_per_week:data[0].hours_per_week}])});
                        //Update gig status on zoho (change into In Progress)
                        var zoho_gig_duration = "";
                        if(data[0].duration_unit = 0){
                            zoho_gig_duration = data[0].estimated_duration + ' hours';
                        }else if(data[0].duration_unit = 1){
                            zoho_gig_duration = data[0].estimated_duration + ' days';
                        }else if(data[0].duration_unit = 2){
                            zoho_gig_duration = data[0].estimated_duration + ' weeks';
                        }else if(data[0].duration_unit = 3){
                            zoho_gig_duration = data[0].estimated_duration + ' months';
                        }else{
                            zoho_gig_duration = data[0].estimated_duration + ' years';
                        }
                        try{
                            var updateGigData =  {
                                Gig_Status: "In Progress",
                                Gig_duration:zoho_gig_duration,
                                Gig_budget:data[0].estimated_budget,
                                Free_Lancer: {
                                id: user.zoho_user_id
                                }
                            }
                            updateGigOnZoho(zohoToken.accesstoken,gig_data.zoho_gigs_id,updateGigData);
                        }catch(error){
                            console.log(error);
                        }
                        //////////////////////////////
                        await projectRepository.update({id:gig_data.project_id}, {status:1});
                            //update project status on zoho (change stage to In progress)
                            try{
                                var updateData = {
                                    Stage: "In Progress"
                                }
                                updateProjectOnZoho(zohoToken.accesstoken,projectData[0].zoho_project_id,updateData);
                            }catch(error){
                                console.log(error);
                            }
                            ////////////////////////////
                        let fl_required_for_new_gigs = parseInt(gig_data.no_fl_required) - 1;
                        let gigs = new Gigs()
                        gigs.created_by = gig_data.created_by;
                        gigs.updated_by = gig_data.updated_by;
                        gigs.created_at = gig_data.created_at;
                        gigs.updated_at = gig_data.updated_at;
                        gigs.status = gig_data.status;
                        gigs.project_id = gig_data.project_id;
                        gigs.projects = gig_data.projects;
                        gigs.type = gig_data.type; //(0 = fl_pm_required_for_breakdown_only , 1 =fl_pm_required_for_e2e_delivery , 2 =no_assistance_required , 4 = contract_hiring)
                        gigs.title = gig_data.title;
                        gigs.description = gig_data.description;
                        gigs.designation = gig_data.designation;
                        gigs.education_id = gig_data.education_id;
                        gigs.fl_hired = 0;
                        let meta_obj;
                        if(data[0].gigs.fl_payment_meta != ""){
                          meta_obj = JSON.parse(data[0].gigs.fl_payment_meta);
                        }else{
                          meta_obj = [{rate_per_hour:data[0].gigs.rate_per_hour,hours_per_week:data[0].gigs.hours_per_week}];
                        }
                        let tempArr = [];
                        for(let i =0 ;i < fl_required_for_new_gigs; i++){
                            let obj = {estimated_duration:gig_data.estimated_duration, duration_unit:gig_data.duration_unit,estimated_budget:Math.trunc((parseInt(gig_data.estimated_budget) - budget_used) / fl_required_for_new_gigs),rate_per_hour:meta_obj[0].rate_per_hour,hours_per_week:meta_obj[0].hours_per_week}
                            tempArr.push(obj);
                        }
                        gigs.fl_payment_meta = JSON.stringify(tempArr);
                        gigs.required_exerience = gig_data.required_exerience;
                        gigs.payment_type = gig_data.payment_type; //(0 = fixed , 1 = time_and_material , 2=open_for_discussion)
                        gigs.is_created_by_pm = gig_data.is_created_by_pm;
                        if(fl_required_for_new_gigs == 1){
                            gigs.no_fl_required = fl_required_for_new_gigs;
                            gigs.estimated_duration = gig_data.estimated_duration;
                            gigs.duration_unit = gig_data.duration_unit;
                            gigs.estimated_budget = Math.trunc(gig_data.estimated_budget - budget_used);
                            gigs.hours_per_week = gig_data.hours_per_week;
                            gigs.rate_per_hour = gig_data.rate_per_hour;
                            gigs.total_budget = Math.trunc(gig_data.total_budget - budget_used);
                        }else{
                            gigs.no_fl_required = fl_required_for_new_gigs;
                            gigs.estimated_duration = gig_data.estimated_duration;
                            gigs.duration_unit = gig_data.duration_unit;
                            gigs.estimated_budget = Math.trunc(gig_data.estimated_budget - budget_used);
                            gigs.hours_per_week = gig_data.hours_per_week;
                            gigs.rate_per_hour = gig_data.rate_per_hour;
                            gigs.total_budget = Math.trunc(gig_data.total_budget - budget_used);
                        }
                        let savedGigs = await gigRepository.save(gigs);

                        for(let z = 0 ; z< gig_data.gigs_skills.length; z++){
                            let gigsSkills = new GigsSkills()
                            gigsSkills.gigs = savedGigs;
                            gigsSkills.skills = gig_data.gigs_skills[z].skills;
                            gigsSkilsRepository.save(gigsSkills);
                        }

                        for(let z = 0 ; z< gig_data.gigs_attachments.length; z++){
                            let gigsAttach = new GigsAttachments()
                            gigsAttach.created_by = gig_data.gigs_attachments[z].created_by;
                            gigsAttach.gigs = savedGigs;
                            gigsAttach.attachment_url =  gig_data.gigs_attachments[z].attachment_url;
                            gigsAttach.created_at = gig_data.gigs_attachments[z].created_at;
                            gigsGigsAttachmentsRepository.save(gigsAttach);
                        }
                        try{
                            //create gig on zoho
                            var zoho_gig_duration = "";
                            if(gigs.duration_unit = 0){
                                zoho_gig_duration = gig_data.estimated_duration + ' hours';
                            }else if(gigs.duration_unit = 1){
                                zoho_gig_duration = gig_data.estimated_duration + ' days';
                            }else if(gigs.duration_unit = 2){
                                zoho_gig_duration = gig_data.estimated_duration + ' weeks';
                            }else if(gigs.duration_unit = 3){
                                zoho_gig_duration = gig_data.estimated_duration + ' months';
                            }else{
                                zoho_gig_duration = gig_data.estimated_duration + ' years';
                            }
                            var Deal = projectData[0].zoho_project_id;
                            var Description = gigs.description;
                            var Name = gigs.title;
                            var Gig_Status = "Pending";
                            var Gigs_Id = savedGigs.id.toString();
                            var Gig_duration = zoho_gig_duration;
                            var Gig_budget =  gigs.total_budget;
                            var zohoToken :any = await zohoInfoRepo.findOne();
                            var createGigsOnZoho :any = await createGigOnZoho(zohoToken.accesstoken,Deal,Description,Name,Gig_Status,Gigs_Id,Gig_duration,Gig_budget);

                            await gigRepository.update({ id:savedGigs.id}, {zoho_user_id:gig_data.zoho_user_id, zoho_enterprise_id:gig_data.zoho_enterprise_id, zoho_gigs_id:createGigsOnZoho.data[0].details.id});
                        }catch(error){
                            console.log(error);
                        }
                    }
                    try{
                    const jsn = JSON.stringify({"user_id": gig_data.created_by});
                    const re = await axios.post(process.env.Begig_user_url+'api/v1/user/superadmin/account', jsn, {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `${token.authorization}`
                        }
                    });
                    // 12% commission on gig amount
                    let amount = (budget_used / 100) * 12;
                    const json = JSON.stringify({"item_id": gig_data.id, "zoho_item_id":gig_data.zoho_gigs_id, "messages":"Invoice for charges on hiring freelancer on you gig: "+gig_data.title, "user_id":re.data.data.owner_id,"owner_account":re.data.data.owner_account,"amount":amount });
                    const res2 = axios.post(process.env.Begig_payment_url+'api/v1/payment/superadmin/commision/invoice', json, {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `${token.authorization}`
                        }
                    });
                    }catch(err){
                        if(process.env.ENV != "development"){
                            rollbar.error(err);
                        }
                    }
                    let ids : any = [gig_data.created_by];
                    const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications';
                    let meta_data = {"project_id":gig_data.project_id,"gig_id":gig_data.id,"redirect_on":"in_progress","view":"admin","fl_id":data[0].fl_id,"created_by":gig_data.created_by,"notification_type":"fl_accept_offer"}
                    const json = JSON.stringify({"ids": ids,"message":"Offer Accepted  {{fl_name}}","meta_data":meta_data});
                    axios.post(bigigUserUrl, json, {
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    });
                    return {statuscode:200};
                }

            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

    async sendFinalOffer(body: any, user: any): Promise<any>{
        try{
            const bidId = body.bid_id;
            const finalOfferBidsRepo = getRepository(FinalOfferBids);
            const bidsRepo = getRepository(Bids);
            const gigsRepo = getRepository(Gigs);
            var time = Date.now()/1000;
            var check = await bidsRepo.find({where:{id:bidId},relations:["gigs"]});
            if(check.length > 0){
            if(check[0].is_final_offer_send == 0){
                for(let i=0;i<body.milestones.length;i++){
                let finalOffer = new FinalOfferBids();
                finalOffer.created_at = time;
                finalOffer.description = body.milestones[i].description;
                finalOffer.title = body.milestones[i].title;
                finalOffer.gig_id = body.milestones[i].gigs_id;
                finalOffer.bids = bidId;
                finalOffer.estimated_duration = body.milestones[i].estimated_duration;
                finalOffer.duration_unit = body.milestones[i].duration_unit;
                finalOffer.payment_type = body.milestones[i].payment_type;
                finalOffer.estimated_budget = body.milestones[i].estimated_budget;
                let saveMilestone = await finalOfferBidsRepo.save(finalOffer);
                }
                await bidsRepo.update({id:bidId},{is_final_offer_send:1});
                let ids : any = [check[0].fl_id];
                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications/fls';
                let meta_data = {"project_id":null,"gig_id":check[0].gigs.id,"redirect_on":"hire_freelancer","view":"freelancer","fl_id":check[0].fl_id,"created_by":check[0].gigs.created_by,"notification_type":"admin_send_final_offer"}
                const json = JSON.stringify({"ids": ids,"message":"Final offer quoted. for "+check[0].gigs.title+". Kindly acknowledge the same.","meta_data":meta_data});
                axios.post(bigigUserUrl, json, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
            }else{
                return {statuscode:202};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

    async rejectBidFL(body: any, user: any): Promise<any>{
        try{
            const bidId = body.bid_id;
            const freelancer_id = user.freelancer_id;
            const bidsRepo = getRepository(Bids);
            let data : any = await bidsRepo.update({fl_id:freelancer_id, id:bidId},{status:2, action_by:"fl"});
            if(data.affected > 0){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

    async rejectBidAdmin(body: any, user: any): Promise<any>{
        try{
            const bidId = body.bid_id;
            const bidsRepo = getRepository(Bids);
            let data : any = await bidsRepo.update({id:bidId},{status:2, action_by:"admin"});

            if(data.affected > 0){
            let d : any = await bidsRepo.findOne({where:{id:bidId},relations:["gigs"]});
            let ids : any = [d.fl_id];
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications/fls';
            let meta_data = {"project_id":null,"gig_id":null,"redirect_on":"find_gigs","view":"freelancer","fl_id":null,created_by:null,"notification_type":"bid_rejected"}
            const json = JSON.stringify({"ids": ids,"message":"We regret to inform you that the bid you quoted for "+d.gigs.title+" has not been approved. We look for further collaboration on some other project. Keep hunting.","meta_data":meta_data});
            axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            }
            return {statuscode:500};
        }
    }

}
