import { Brackets, getRepository } from 'typeorm';
import { Bids } from '../models/Bids';
import { DraftedGigs } from '../models/DraftedGigs';
import { Gigs } from "../models/Gigs";
const axios = require('axios');
require('dotenv').config()
const {rollbar} = require('../helper/rollbar');

export class SiteAdminService {

    async getAllOpenGigCount(): Promise<any>{
        try{
            const gigCount = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.status = 1")
            .getCount();
            return {statuscode:200,data:gigCount};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async GetTotalHiredFreelancerCount(): Promise<any>{
        try{
            const hiredFreeLancerCount = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.fl_id != 0")
            .getCount();
            return {statuscode:200,data:hiredFreeLancerCount};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async GetAllOverDueGigs(skip:any , take:any): Promise<any>{
        try{
            var time = Date.now()/1000;
            const overDueGigs = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.status = 2")
            .andWhere("gigs.expected_closer <=:time",{time:time})
            .skip(skip*take)
            .take(take)
            .getMany();
            return {statuscode:200,data:overDueGigs};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async getAllApprovedGigs(skip:any , take:any): Promise<any>{
        try{
            const overDueGigs = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.status = 1")
            .skip(skip*take)
            .take(take)
            .getMany();
            return {statuscode:200,data:overDueGigs};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async hiredFreelancerList(body: any, token:any): Promise<any>{
        try{
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            var query_condition :any = "";
            var search_query_condition :any = "";
            var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var search_key = body.search_key;
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(search_key != ""&& search_key != undefined){
                search_query_condition = new Brackets( qb => {
                    qb.where("gigs.title like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("gigs.description like :search_key", { search_key: `%${search_key}%` })
                    }
                );
            }
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
            }
            if(query_condition != "" && search_query_condition !=""){
                var gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 2")
                .andWhere("gigs.fl_id != 0")
                .andWhere(query_condition)
                .andWhere(search_query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(query_condition != ""){
                var gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 2")
                .andWhere("gigs.fl_id != 0")
                .andWhere(query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else{
                var gigDetails : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 2")
                .andWhere("gigs.fl_id != 0")
                .orderBy('gigs.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

            }

            if(gigDetails.length>0){
                let id : any = [];
                for(let i=0;i<gigDetails.length;i++){
                    if(!id.includes(gigDetails[i].fl_id)){
                       id.push(gigDetails[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigDetails.length;i++){
                    let fl_id = gigDetails[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                email : res.data.freelancerData[j].user.email,
                                average_rating : res.data.freelancerData[j].user.average_rating,
                                freelancing_type : res.data.freelancerData[j].freelancing_type,
                                rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                                availibity : res.data.freelancerData[j].availibity
                            }
                            gigDetails[i].freelancer = freelancer
                            break;
                        }
                    }
                }

                return {statuscode:200,data:gigDetails};
            }else{
                return {statuscode:201};
            }
        }catch(err){
            console.log(err);
            if(process.env.ENV != "development"){
                rollbar.error(err);
            } 
            return {statuscode:500};
        }
    }

    async listOfOpenGigsForSiteAdmin(body: any, token:any): Promise<any>{
        try{
            const page_number = body.page_number || 0;
            const number_of_record = body.number_of_record || 10;
            var query_condition :any = "";
            var search_query_condition :any = "";
            var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var search_key = body.search_key;
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(search_key != ""&& search_key != undefined){
                search_query_condition = new Brackets( qb => {
                    qb.where("gigs.title like :search_key", { search_key: `%${search_key}%` })
                      .orWhere("gigs.description like :search_key", { search_key: `%${search_key}%` })
                    }
                );
            }
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
            }

            if(query_condition != "" && search_query_condition !=""){
                var gigsDetail : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .andWhere(query_condition)
                .andWhere(search_query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else if(query_condition != ""){
                var gigsDetail : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .andWhere(query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();
            }else{
                var gigsDetail : any = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .orderBy('gigs.created_at', 'DESC')
                .limit(number_of_record)   // page number
                .offset(page_number * number_of_record)   // offset (from where we want to get record)
                .getMany();

            }
            if(gigsDetail.length>0){
                let id : any = [];
                for(let i=0;i<gigsDetail.length;i++){
                    if(!id.includes(gigsDetail[i].created_by)){
                    id.push(gigsDetail[i].created_by);
                    }
                }
                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
                const json = JSON.stringify({"id": id});
                const res = await axios.post(bigigUserUrl, json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });

                for(let i=0;i<gigsDetail.length;i++){
                    let gigId = gigsDetail[i].created_by;

                    for(let j=0;j< res.data.userData.length;j++){
                        if(gigId == res.data.userData[j].user.id){
                            var admin : any = {
                                first_name : res.data.userData[j].user.first_name,
                                last_name : res.data.userData[j].user.last_name,
                                email : res.data.userData[j].user.email,
                                profile_pic : res.data.userData[j].user.profile_pic,
                                company_name : res.data.userData[j].company.company_name,
                            }
                            gigsDetail[i].admin = admin
                            break;
                        }
                    }
                }
                return {statuscode:201,data:gigsDetail};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async arrayOfOpenGigCreatedBy(body: any): Promise<any>{
        try{
            if(body.user_id){
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }
                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < body.user_id.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,user_id:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :user_id, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }
                if(query_condition != ""){
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(Gigs)
                                                    .createQueryBuilder("gigs")
                                                    .where("gigs.status = 1")
                                                    .andWhere("gigs.created_by ="+body.user_id[i])
                                                    .andWhere(query_condition)
                                                    .getCount();
                        cb(i,body.user_id[i],countdata);
                    }
                }else{
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(Gigs)
                                                    .createQueryBuilder("gigs")
                                                    .where("gigs.status = 1")
                                                    .andWhere("gigs.created_by ="+body.user_id[i])
                                                    .getCount();
                        cb(i,body.user_id[i],countdata);
                    }
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }

            }else{
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }
                if(query_condition != ""){
                    gigsDetail = await getRepository(Gigs)
                    .createQueryBuilder("gigs")
                    .where("gigs.status = 1")
                    .andWhere(query_condition)
                    .select('DISTINCT gigs.created_by', 'created_by')
                    .skip(page_number*number_of_record)
                    .take(number_of_record)
                    .getRawMany();
                }else{
                    gigsDetail = await getRepository(Gigs)
                    .createQueryBuilder("gigs")
                    .where("gigs.status = 1")
                    .select('DISTINCT gigs.created_by', 'created_by')
                    .skip(page_number*number_of_record)
                    .take(number_of_record)
                    .getRawMany();
                }
                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < gigsDetail.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,created_by:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :created_by, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }
                if(gigsDetail.length > 0){
                    for(let i=0;i<gigsDetail.length;i++){
                        var countdata : any = await getRepository(Gigs)
                                                    .createQueryBuilder("gigs")
                                                    .where("gigs.status = 1")
                                                    .andWhere("gigs.created_by ="+gigsDetail[i].created_by)
                                                    .getCount();
                        cb(i,gigsDetail[i].created_by,countdata);
                    }
                }else{
                    return {statuscode:201};
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async arrayOfOngoingGigCreatedBy(body: any): Promise<any>{
        try{
            if(body.user_id){
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }
                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < body.user_id.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,user_id:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :user_id, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }
                if(query_condition != ""){
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(Gigs)
                                                    .createQueryBuilder("gigs")
                                                    .where("gigs.status = 2")
                                                    .andWhere("gigs.created_by ="+body.user_id[i])
                                                    .andWhere(query_condition)
                                                    .getCount();
                        cb(i,body.user_id[i],countdata);
                    }
                }else{
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(Gigs)
                                                    .createQueryBuilder("gigs")
                                                    .where("gigs.status = 2")
                                                    .andWhere("gigs.created_by ="+body.user_id[i])
                                                    .getCount();
                        cb(i,body.user_id[i],countdata);
                    }
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }else{
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }
                if(query_condition != ""){
                    gigsDetail = await getRepository(Gigs)
                    .createQueryBuilder("gigs")
                    .where("gigs.status = 2")
                    .andWhere(query_condition)
                    .select('DISTINCT gigs.created_by', 'created_by')
                    .skip(page_number*number_of_record)
                    .take(number_of_record)
                    .getRawMany();
                }else{
                    gigsDetail = await getRepository(Gigs)
                    .createQueryBuilder("gigs")
                    .where("gigs.status = 2")
                    .select('DISTINCT gigs.created_by', 'created_by')
                    .skip(page_number*number_of_record)
                    .take(number_of_record)
                    .getRawMany();
                }
                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < gigsDetail.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,created_by:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :created_by, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }
                if(gigsDetail.length > 0){
                    for(let i=0;i<gigsDetail.length;i++){
                        var countdata : any = await getRepository(Gigs)
                                                    .createQueryBuilder("gigs")
                                                    .where("gigs.created_by ="+gigsDetail[i].created_by)
                                                    .andWhere("gigs.status = 2")
                                                    .getCount();
                        cb(i,gigsDetail[i].created_by,countdata);
                    }
                }else{
                    return {statuscode:201};
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async arrayOfDratedGigCreatedBy(body: any): Promise<any>{
        try{
            if(body.user_id){
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+to+"";
                }
                if(query_condition != ""){
                    var ids : any = [];
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(DraftedGigs)
                                                    .createQueryBuilder("drafted_gigs")
                                                    .where("drafted_gigs.created_by ="+body.user_id[i])
                                                    .andWhere(query_condition)
                                                    .getCount();
                        ids.push({ created_by :body.user_id[i], count:countdata});
                    }
                }else{
                    var ids : any = [];
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(DraftedGigs)
                                                    .createQueryBuilder("drafted_gigs")
                                                    .where("drafted_gigs.created_by ="+body.user_id[i])
                                                    .getCount();
                        ids.push({ created_by :body.user_id[i], count:countdata});
                    }
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }else{
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+to+"";
                }
                if(query_condition != ""){
                    gigsDetail = await getRepository(DraftedGigs)
                    .createQueryBuilder("drafted_gigs")
                    .andWhere(query_condition)
                    .select('DISTINCT drafted_gigs.created_by', 'created_by')
                    .skip(page_number*number_of_record)
                    .take(number_of_record)
                    .getRawMany();
                }else{
                    gigsDetail = await getRepository(DraftedGigs)
                    .createQueryBuilder("drafted_gigs")
                    .select('DISTINCT drafted_gigs.created_by', 'created_by')
                    .skip(page_number*number_of_record)
                    .take(number_of_record)
                    .getRawMany();
                }
                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < gigsDetail.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,created_by:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :created_by, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }
                if(gigsDetail.length > 0){
                    for(let i=0;i<gigsDetail.length;i++){
                        var countdata : any = await getRepository(DraftedGigs)
                                                    .createQueryBuilder("drafted_gigs")
                                                    .where("drafted_gigs.created_by ="+gigsDetail[i].created_by)
                                                    .getCount();
                        cb(i,gigsDetail[i].created_by,countdata);
                    }
                }else{
                    return {statuscode:201};
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async freelancer_bid_View(body: any): Promise<any>{
        try{
            if(body.user_id){
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+to+"";
                }

                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < body.user_id.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,fl_id:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :fl_id, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }

                if(query_condition != ""){
                    var ids : any = [];
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(Bids)
                                                    .createQueryBuilder("bids")
                                                    .where("bids.fl_id ="+body.user_id[i])
                                                    .andWhere(query_condition)
                                                    .getCount();
                        cb(i,body.user_id[i],countdata);
                    }
                }else{
                    var ids : any = [];
                    for(let i=0;i<body.user_id.length;i++){
                        var countdata : any = await getRepository(Bids)
                                                    .createQueryBuilder("bids")
                                                    .where("bids.fl_id ="+body.user_id[i])
                                                    .getCount();
                        cb(i,body.user_id[i],countdata);
                    }
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }else{
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigsDetail:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+to+"";
                }
                if(query_condition != ""){
                    gigsDetail = await getRepository(Bids)
                    .createQueryBuilder("bids")
                    .andWhere(query_condition)
                    .limit(number_of_record)   // page number
                    .offset(page_number*number_of_record)
                    .select('DISTINCT bids.fl_id', 'fl_id')
                    .getRawMany();
                }else{
                    console.log('test');
                    gigsDetail = await getRepository(Bids)
                    .createQueryBuilder("bids")
                    .limit(number_of_record)   // page number
                    .offset(page_number*number_of_record)
                    .select('DISTINCT bids.fl_id', 'fl_id')
                    .getRawMany();

                }
                var ids: any = [];
                var index_Arr: number[] = [];
                for(let i=0;i < gigsDetail.length; i++){
                    index_Arr.push(i);
                }
                function cb(index:number,fl_id:any,countdata:any){
                    index_Arr.pop()
                    ids.push({ created_by :fl_id, count:countdata});
                    if(index_Arr.length <= 0){
                        return ids;
                    }
                }
                if(gigsDetail.length > 0){
                    for(let i=0;i<gigsDetail.length;i++){
                        var countdata : any = await getRepository(Bids)
                                                    .createQueryBuilder("bids")
                                                    .where("bids.fl_id ="+gigsDetail[i].fl_id)
                                                    .getCount();
                        cb(i,gigsDetail[i].fl_id,countdata);
                    }
                }else{
                    return {statuscode:200};
                }
                if(ids.length > 0){
                    return {statuscode:200,data:ids};
                }else{
                    return {statuscode:201};
                }
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async opneOrOngoingGigsView(body: any,token:any): Promise<any>{
        try{
            var query_condition :any = "";
            var gigsDetail:any = "";
            var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var gig_type = body.gig_type;  //1 - open gig //2 - onging gig
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
            }
            if(query_condition != ""){
                gigsDetail  = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = "+gig_type)
                .andWhere("gigs.created_by ="+body.user_id)
                .andWhere(query_condition)
                .getMany();
            }else{
                gigsDetail  = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = "+gig_type)
                .andWhere("gigs.created_by ="+body.user_id)
                .getMany();
            }
            if(gigsDetail.length > 0 && gig_type == 1){
                return {statuscode:200,data:gigsDetail};
            }
            if(gigsDetail.length > 0){
                let id : any = [];
                for(let i=0;i<gigsDetail.length;i++){
                    if(!id.includes(gigsDetail[i].fl_id)){
                        id.push(gigsDetail[i].fl_id);
                    }
                }
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigsDetail.length;i++){
                    let fl_id = gigsDetail[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic
                            }
                            gigsDetail[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigsDetail};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async draftedGigsView(body: any): Promise<any>{
        try{
            var query_condition :any = "";
            var gigsDetail:any = "";
            var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "drafted_gigs.created_at >="+from+"  AND drafted_gigs.created_at < "+to+"";
            }
            if(query_condition != ""){
                gigsDetail  = await getRepository(DraftedGigs)
                .createQueryBuilder("drafted_gigs")
                .leftJoinAndSelect("drafted_gigs.projects", "projects")
                .where("drafted_gigs.created_by ="+body.user_id)
                .andWhere(query_condition)
                .getMany();
            }else{
                gigsDetail  = await getRepository(DraftedGigs)
                .createQueryBuilder("drafted_gigs")
                .leftJoinAndSelect("drafted_gigs.projects", "projects")
                .where("drafted_gigs.created_by ="+body.user_id)
                .getMany();
            }
            var obj = [];
            for(let i =0; i< gigsDetail.length; i++){
                obj[i] = JSON.parse(gigsDetail[i].gigs_details_json);
                obj[i].projects = gigsDetail[i].projects;
                obj[i].id = gigsDetail[i].id;
                obj[i].created_at = gigsDetail[i].created_at;
            }
            if(obj.length > 0){
                return {statuscode:200,data:obj};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async freelancerBidedViews(body: any, token:any): Promise<any>{
        try{
            var query_condition :any = "";
            var gigsDetail:any = "";
            var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+to+"";
            }
            if(query_condition != ""){
                gigsDetail  = await getRepository(Bids)
                .createQueryBuilder("bids")
                .leftJoinAndSelect("bids.gigs", "gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .leftJoinAndSelect("bids.milestone_suggetions", "milestone_suggetions")
                .where("bids.fl_id ="+body.fl_id)
                .andWhere(query_condition)
                .getMany();
            }else{
                gigsDetail = await getRepository(Bids)
                .createQueryBuilder("bids")
                .leftJoinAndSelect("bids.gigs", "gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .leftJoinAndSelect("gigs.gigs_milestones", "gigs_milestones")
                .leftJoinAndSelect("bids.milestone_suggetions", "milestone_suggetions")
                .where("bids.fl_id ="+body.fl_id)
                .getMany();
            }
            if(gigsDetail.length > 0){
                let created_by_arr:any = [];
                for(let i=0;i<gigsDetail.length;i++){
                    created_by_arr.push(gigsDetail[i].gigs.created_by);
                }
                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
                const json = JSON.stringify({"id": created_by_arr});
                const res = await axios.post(bigigUserUrl, json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigsDetail.length;i++){
                    let created_by = gigsDetail[i].gigs.created_by;
                    for(let j=0;j< res.data.userData.length;j++){
                    if(created_by == res.data.userData[j].user.id){
                        var admin : any = {
                            first_name : res.data.userData[j].user.first_name,
                            last_name : res.data.userData[j].user.last_name,
                            profile_pic : res.data.userData[j].user.profile_pic,
                            average_rating : res.data.userData[j].user.average_rating,
                            company_name : res.data.userData[j].company.company_name,
                        }
                        gigsDetail[i].gigs.admin = admin
                        break;
                    }
                    }
                }
                return {statuscode:200,data:gigsDetail};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async openGiglistForSiteAdmin(body: any, token:any): Promise<any>{     
        try{
            var page_number = body.page_number || 0;
            var number_of_record = body.number_of_record || 10;
            var query_condition :any = "";
            var search_query_condition :any = "";
            var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
            var search_key = body.search_key;
            var gigsDetail:any="";
            var from :any = "";
            var to :any = "";
            var todayDate = Date.now()/1000;
            if(search_key != ""&& search_key != undefined){
                search_query_condition = new Brackets( qb => {
                    qb.where("gigs.id like :search_key", { search_key: `%${search_key}%` })
                        .orWhere("gigs.title like :search_key", { search_key: `%${search_key}%` })
                    }
                );
            }
            if(filter_type == "today"){
                let today = new Date().toISOString().slice(0, 10);
                from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "7_days"){
                var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                from = beforeSevenDate /1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "30_days"){
                from = new Date().setDate(new Date().getDate()-30)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "3_months"){
                from = new Date().setDate(new Date().getDate()-90)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "12_months"){
                from = new Date().setDate(new Date().getDate()-365)/1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
            }else if(filter_type == "custom"){
                from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                to = new Date(body.to).getTime() / 1000;
                query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
            }         
            if(query_condition != "" && search_query_condition !=""){
                gigsDetail = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .andWhere(query_condition)
                .andWhere(search_query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .skip(page_number*number_of_record)
                .take(number_of_record)
                .getMany();
            }else if(search_query_condition != ""){
                gigsDetail = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .andWhere(search_query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .skip(page_number*number_of_record)
                .take(number_of_record)
                .getMany();
            }else if(query_condition != ""){      
                gigsDetail = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .andWhere(query_condition)
                .orderBy('gigs.created_at', 'DESC')
                .skip(page_number*number_of_record)
                .take(number_of_record)
                .getMany();
            }else{                     
                gigsDetail = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .leftJoinAndSelect("gigs.projects", "projects")
                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                .where("gigs.status = 1")
                .orderBy('gigs.created_at', 'DESC')
                .skip(page_number*number_of_record)
                .take(number_of_record)
                .getMany();
            }

            if(gigsDetail.length>0){  
                let id : any = [];
                for(let i=0;i<gigsDetail.length;i++){
                    if(!id.includes(gigsDetail[i].created_by)){
                       id.push(gigsDetail[i].created_by);
                    }
                }      

                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
                const json = JSON.stringify({"id": id});
                const res = await axios.post(bigigUserUrl, json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<gigsDetail.length;i++){
                    let gigId = gigsDetail[i].created_by;

                    for(let j=0;j< res.data.userData.length;j++){
                        if(gigId == res.data.userData[j].user.id){
                            var admin : any = {
                                first_name : res.data.userData[j].user.first_name,
                                last_name : res.data.userData[j].user.last_name,
                                email : res.data.userData[j].user.email,
                                profile_pic : res.data.userData[j].user.profile_pic,
                                company_name : res.data.userData[j].company.company_name,
                            }
                            let gigsBidCount : any = await getRepository(Bids)
                            .createQueryBuilder("bids")
                            .where("bids.gigs =" + gigsDetail[i].id)
                            .getCount();   
                            gigsDetail[i].admin = admin
                            gigsDetail[i].count = gigsBidCount
                            break;
                        }
                    }
                }
                return {statuscode:200,data:gigsDetail};
            }else{
                return {statuscode:201};
            }   
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async openGiglistBidCountView(body: any,token:any): Promise<any>{     
        try{    
            var page_number = body.page_number || 0;
            var number_of_record = body.number_of_record || 10;
            let bidsData : any = await getRepository(Bids)
            .createQueryBuilder("bids")
            .leftJoinAndSelect("bids.gigs", "gigs")
            .leftJoinAndSelect("bids.milestone_suggetions", "milestone_suggetions")
            .leftJoinAndSelect("bids.final_offer", "final_offer")
            .where("bids.gigs =" + body.gig_id)
            .skip(page_number*number_of_record)
            .take(number_of_record)
            .getMany(); 
            if(bidsData.length > 0){
                let id:any = [];
                for(let i=0;i<bidsData.length;i++){
                    id.push(bidsData[i].fl_id);
                }
  
                const json = JSON.stringify({"id": id});
                const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
                for(let i=0;i<bidsData.length;i++){
                    let fl_id = bidsData[i].fl_id;
                    for(let j=0;j< res.data.freelancerData.length;j++){
                        if(fl_id == res.data.freelancerData[j].id){
                            var freelancer : any = {
                                first_name : res.data.freelancerData[j].user.first_name,
                                last_name : res.data.freelancerData[j].user.last_name,
                                profile_pic : res.data.freelancerData[j].user.profile_pic,
                                email : res.data.freelancerData[j].user.email
                            }
                            bidsData[i].freelancer = freelancer
                            break;
                        }
                    }
                }
                return {statuscode:200,data:bidsData};
            }else{
                return {statuscode:201};
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async hiredFeelancerList(body: any): Promise<any>{console.log(body);
        try{
            if(body.fl_id){
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }
                var gigsData :any =""
                if(query_condition != ""){
                    gigsData = await getRepository(Gigs)
                                .createQueryBuilder("gigs")
                                .leftJoinAndSelect("gigs.projects", "projects")
                                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                                .where("gigs.status = 2")
                                .andWhere("gigs.fl_id IN (:...ids)",{ ids: body.fl_id })
                                .andWhere(query_condition)
                                .skip(body.page_number*body.number_of_record)
                                .take(body.number_of_record)
                                .getMany();
                }else{
                    gigsData = await getRepository(Gigs)
                                .createQueryBuilder("gigs")
                                .leftJoinAndSelect("gigs.projects", "projects")
                                .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                                .where("gigs.status = 2")
                                .andWhere("gigs.fl_id IN (:...ids)",{ ids: body.fl_id })
                                .skip(body.page_number*body.number_of_record)
                                .take(body.number_of_record)
                                .getMany();
                    }
                if(gigsData.length > 0){
                    return {statuscode:200,data:gigsData};
                }else{
                    return {statuscode:201};
                }
            }else{
                const page_number = body.page_number || 0;
                const number_of_record = body.number_of_record || 10;
                var query_condition :any = "";
                var filter_type = body.filter_type;  //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var gigDetails:any="";
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }

                if(query_condition != ""){
                    gigDetails = await getRepository(Gigs)
                    .createQueryBuilder("gigs")
                    .leftJoinAndSelect("gigs.projects", "projects")
                    .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                    .where("gigs.status = 2")
                    .andWhere("gigs.fl_id != 0")
                    .andWhere(query_condition)
                    .limit(number_of_record)   // page number
                    .offset(page_number * number_of_record)   // offset (from where we want to get record)
                    .getMany();
                }else{
                    gigDetails = await getRepository(Gigs)
                    .createQueryBuilder("gigs")
                    .leftJoinAndSelect("gigs.projects", "projects")
                    .leftJoinAndSelect("gigs.gigs_skills", "gigs_skills")
                    .where("gigs.status = 2")
                    .andWhere("gigs.fl_id != 0")
                    .limit(number_of_record)   // page number
                    .offset(page_number * number_of_record)   // offset (from where we want to get record)
                    .getMany();
                }
                if(gigDetails.length > 0){
                    return {statuscode:200,data:gigDetails};
                }else{
                    return {statuscode:201};
                }
            }
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async siteAdminGigsPostedCount(): Promise<any> {
        try {

            var openGigCount = await getRepository(Gigs)
            .createQueryBuilder("gigs")
            .where("gigs.status = 1")
            .getCount();

            var flHiredCount = await getRepository(Bids)
            .createQueryBuilder("gigs")
            .where("gigs.status = 2")
            .getCount();         

            return {statuscode:200,data:{flHiredCount:flHiredCount, openGigCount:openGigCount}};

        }catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async clientCreatedGigsCount(body: any): Promise<any> {
        try {
            var clientCreatedGigs :any =""  
            if(body.filter_type){
                var query_condition :any = "";
                var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "gigs.created_at >="+from+"  AND gigs.created_at < "+to+"";
                }                
               
                clientCreatedGigs = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .where("gigs.status != 5")
                .andWhere(query_condition)
                .getCount();
        
            }else{

                clientCreatedGigs = await getRepository(Gigs)
                .createQueryBuilder("gigs")
                .where("gigs.status != 5")
                .getCount();

            }
            return {statuscode:200,data:clientCreatedGigs};                
        }catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async freelancerBiddedCount(body: any): Promise<any> {
        try {
            var clientCreatedGigs :any =""  
            if(body.filter_type){
                var query_condition :any = "";
                var filter_type = body.filter_type; //"today" / "7_days" / "30_days" / "3_months" / "12_months" /"custom"
                var from :any = "";
                var to :any = "";
                var todayDate = Date.now()/1000;
                if(filter_type == "today"){
                    let today = new Date().toISOString().slice(0, 10);
                    from = new Date(today+ ' ' +'12:00:00 AM').getTime() / 1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "7_days"){
                    var beforeSevenDate:any = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                    from = beforeSevenDate /1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "30_days"){
                    from = new Date().setDate(new Date().getDate()-30)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "3_months"){
                    from = new Date().setDate(new Date().getDate()-90)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+todayDate+"";
                }else if(filter_type == "12_months"){
                    from = new Date().setDate(new Date().getDate()-365)/1000;
                    query_condition = "bids.bidded_on >="+from+"  AND gigs.bidded_on < "+todayDate+"";
                }else if(filter_type == "custom"){
                    from = new Date(body.from+ ' ' +'12:00:00').getTime() / 1000;
                    to = new Date(body.to).getTime() / 1000;
                    query_condition = "bids.bidded_on >="+from+"  AND bids.bidded_on < "+to+"";
                }                
               
                clientCreatedGigs = await getRepository(Bids)
                .createQueryBuilder("bids")
                .where(query_condition)
                .getCount();   
            }else{
                clientCreatedGigs = await getRepository(Gigs)
                .createQueryBuilder("bids")
                .getCount();
            }
            return {statuscode:200,data:clientCreatedGigs};                
        }catch (error) {console.log(error);
            if(process.env.ENV != "development"){
                rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }


    


}
