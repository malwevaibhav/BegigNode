import { Gigs } from "../models/Gigs";
import { Projects } from "../models/Projects";
import { getManager } from 'typeorm';
import { getRepository, LessThan, MoreThan, MoreThanOrEqual, Not } from 'typeorm';
import { GigsSkills } from "../models/GigsSkills";
import { GigsMilestones } from "../models/GigsMilestones";
import { GigsAttachments } from "../models/GigsAttachments";
import { MilestoneAttachments } from "../models/MilestoneAttachments";
import { time } from "console";
import { ZohoInfo } from "../models/ZohoInfo";
const {createGigOnZoho,createMilestonesOnZoho,updateGigOnZoho,updateMilestoneOnZoho} = require('../helper/zohoApi');
const axios = require('axios');
var bcrypt = require('bcryptjs');
require('dotenv').config()
const jwt = require('jsonwebtoken')
const {rollbar} = require('../helper/rollbar');

export class MilestoneService {

    async saveMilestones(body:any,user:any):Promise<any>{
      try{
          var new_gigs_id = 0;
          const gigsMilestoneRepository = getRepository(GigsMilestones);
          const gigsRepository = getRepository(Gigs);
          const gigsSkilsRepository = getRepository(GigsSkills);
          const gigsGigsAttachmentsRepository = getRepository(GigsAttachments);
          const projectRepository = getRepository(Projects);
          const zohoInfoRepo = getRepository(ZohoInfo);
          var time = Date.now()/1000;
          var no_of_users = parseInt(body.no_of_users);
          var gig_data:any = await gigsRepository.findOne({where:{id:body.milestones[0].gigs_id} , relations:["gigs_skills", "gigs_attachments","projects"]});
          var obj = JSON.parse(gig_data.fl_payment_meta);
          var budget_used = 0;
          if(gig_data.no_fl_required == no_of_users){
              for(let i=0;i<body.milestones.length;i++){
                  let gigsMilestones = new GigsMilestones();
                  gigsMilestones.created_at = time;
                  gigsMilestones.updated_at = time;
                  gigsMilestones.created_by = user.id;
                  gigsMilestones.updated_by = user.id;
                  gigsMilestones.description = body.milestones[i].description;
                  gigsMilestones.title = body.milestones[i].title;
                  gigsMilestones.gigs = body.milestones[i].gigs_id;
                  gigsMilestones.estimated_duration = body.milestones[i].estimated_duration;
                  gigsMilestones.duration_unit = body.milestones[i].duration_unit;
                  gigsMilestones.estimated_budget = body.milestones[i].estimated_budget;
                  gigsMilestones.status = 0;
                  budget_used = budget_used + parseInt(body.milestones[i].estimated_budget);
                  let saveMilestone = await gigsMilestoneRepository.save(gigsMilestones);
              }
              return {statuscode:200,new_gig_id:0};
          }else if(gig_data.no_fl_required > no_of_users){
              for(let i=0;i<body.milestones.length;i++){
                  let gigsMilestones = new GigsMilestones();
                  gigsMilestones.created_at = time;
                  gigsMilestones.updated_at = time;
                  gigsMilestones.created_by = user.id;
                  gigsMilestones.updated_by = user.id;
                  gigsMilestones.description = body.milestones[i].description;
                  gigsMilestones.title = body.milestones[i].title;
                  gigsMilestones.gigs = body.milestones[i].gigs_id;
                  gigsMilestones.estimated_duration = body.milestones[i].estimated_duration;
                  gigsMilestones.duration_unit = body.milestones[i].duration_unit;
                  gigsMilestones.estimated_budget = body.milestones[i].estimated_budget;
                  gigsMilestones.status = 0;
                  budget_used = budget_used + parseInt(body.milestones[i].estimated_budget);
                  let saveMilestone = await gigsMilestoneRepository.save(gigsMilestones);
              }
              budget_used = budget_used * no_of_users;

              let newObj = [];
              for(let i=0;i<no_of_users;i++){
                newObj.push({estimated_budget:Math.trunc((budget_used)/no_of_users),estimated_duration:obj[0].estimated_duration,duration_unit:obj[0].duration_unit,rate_per_hour:obj[0].rate_per_hour,hours_per_week:obj[0].hours_per_week});
              }

              await gigsRepository.update({id:body.milestones[0].gigs_id}, {no_fl_required:no_of_users,estimated_budget:budget_used,total_budget:budget_used,fl_payment_meta:JSON.stringify(newObj)});

              try{
                var zohoGigId = gig_data.zoho_gigs_id;
                var updateData = {
                    Gig_budget : budget_used
                }
                var zohoToken :any = await zohoInfoRepo.findOne();
                updateGigOnZoho(zohoToken.accesstoken,zohoGigId,updateData);

              }catch(error){
                console.log(error);
              }

              let fl_required_for_new_gigs = parseInt(gig_data.no_fl_required) - no_of_users;
              let gigs = new Gigs()
              gigs.created_by = gig_data.created_by;
              gigs.updated_by = gig_data.updated_by;
              gigs.created_at = gig_data.created_at;
              gigs.updated_at = gig_data.updated_at;
              gigs.status = gig_data.status;
              gigs.project_id = gig_data.project_id;
              gigs.projects = gig_data.projects;
              gigs.type = gig_data.type; //(0 = fl_pm_required_for_breakdown_only , 1 =fl_pm_required_for_e2e_delivery , 2 =no_assistance_required , 4 = contract_hiring)
              gigs.title = gig_data.title;
              gigs.description = gig_data.description;
              gigs.designation = gig_data.designation;
              gigs.education_id = gig_data.education_id;
              gigs.fl_hired = 0;
              gigs.required_exerience = gig_data.required_exerience;
              gigs.payment_type = gig_data.payment_type; //(0 = fixed , 1 = time_and_material , 2=open_for_discussion)
              gigs.is_created_by_pm = gig_data.is_created_by_pm;
              if(fl_required_for_new_gigs == 1){
                gigs.no_fl_required = fl_required_for_new_gigs;
                gigs.fl_payment_meta = JSON.stringify([{estimated_duration:gig_data.estimated_duration,duration_unit:gig_data.duration_unit,estimated_budget:Math.trunc((parseInt(gig_data.estimated_budget) - budget_used)/fl_required_for_new_gigs),rate_per_hour:obj[0].rate_per_hour,hours_per_week:obj[0].hours_per_week}]);
                gigs.estimated_duration = gig_data.estimated_duration;
                gigs.duration_unit = gig_data.duration_unit;
                gigs.estimated_budget = Math.trunc(parseInt(gig_data.estimated_budget) - budget_used);
                gigs.hours_per_week = obj[0].hours_per_week;
                gigs.rate_per_hour = obj[0].rate_per_hour;
                gigs.total_budget = Math.trunc(parseInt(gig_data.total_budget) - budget_used);
              }else{
                let newObj = [];
                for(let i=0;i<fl_required_for_new_gigs;i++){
                  newObj.push({estimated_budget:Math.trunc((parseInt(gig_data.estimated_budget) - budget_used)/fl_required_for_new_gigs),estimated_duration:obj[0].estimated_duration,duration_unit:obj[0].duration_unit,rate_per_hour:obj[0].rate_per_hour,hours_per_week:obj[0].hours_per_week});
                }
                gigs.fl_payment_meta = JSON.stringify(newObj);
                gigs.no_fl_required = fl_required_for_new_gigs;
                gigs.estimated_duration = gig_data.estimated_duration;
                gigs.duration_unit = gig_data.duration_unit;
                gigs.estimated_budget = Math.trunc(parseInt(gig_data.estimated_budget) - budget_used);
                gigs.hours_per_week = obj[0].hours_per_week;
                gigs.rate_per_hour = obj[0].rate_per_hour;
                gigs.total_budget = Math.trunc(parseInt(gig_data.total_budget) - budget_used);
              }

              let savedGigs = await gigsRepository.save(gigs);

              new_gigs_id = savedGigs.id;
              for(let z = 0 ; z< gig_data.gigs_skills.length; z++){
                  let gigsSkills = new GigsSkills()
                  gigsSkills.gigs = savedGigs;
                  gigsSkills.skills = gig_data.gigs_skills[z].skills;
                  gigsSkilsRepository.save(gigsSkills);
              }

              for(let z = 0 ; z< gig_data.gigs_attachments.length; z++){
                  let gigsAttach = new GigsAttachments()
                  gigsAttach.created_by = gig_data.gigs_attachments[z].created_by;
                  gigsAttach.gigs = savedGigs;
                  gigsAttach.attachment_url =  gig_data.gigs_attachments[z].attachment_url;
                  gigsAttach.created_at = gig_data.gigs_attachments[z].created_at;
                  gigsGigsAttachmentsRepository.save(gigsAttach);
              }


                var zohoToken :any = await zohoInfoRepo.findOne();
                var projectData :any= await projectRepository.find({id:gig_data.project_id,created_by:user.id});

                //create gig on zoho
                try{
                  var zoho_gig_duration = "";
                  if(gigs.duration_unit = 0){
                    zoho_gig_duration = gig_data.estimated_duration + ' hours';
                  }else if(gigs.duration_unit = 1){
                    zoho_gig_duration = gig_data.estimated_duration + ' days';
                  }else if(gigs.duration_unit = 2){
                    zoho_gig_duration = gig_data.estimated_duration + ' weeks';
                  }else if(gigs.duration_unit = 3){
                    zoho_gig_duration = gig_data.estimated_duration + ' months';
                  }else{
                    zoho_gig_duration = gig_data.estimated_duration + ' years';
                  }

                  var Deal = projectData[0].zoho_project_id;
                  var Description = gigs.description;
                  var Name = gigs.title;
                  var Gig_Status = "Pending";
                  var Gigs_Id = savedGigs.id.toString();
                  var Gig_duration = zoho_gig_duration;
                  var Gig_budget =  gigs.total_budget;
                  var createGigsOnZoho :any = await createGigOnZoho(zohoToken.accesstoken,Deal,Description,Name,Gig_Status,Gigs_Id,Gig_duration,Gig_budget);

                  await gigsRepository.update({ created_by:user.id,project_id:body.project_id}, {zoho_user_id:user.zoho_user_id, zoho_enterprise_id:user.zoho_enterprise_id, zoho_gigs_id:createGigsOnZoho.data[0].details.id});

                }catch(error){
                  if(process.env.ENV != "development"){
                    rollbar.error(error);
                  }
                  console.log(error);
                }
                ////////////////////////////////////////////////////////////////////

              return {statuscode:200,new_gigs_id:new_gigs_id};
          }else{
            return {statuscode:201};
          }
      }catch(error){
          console.log(error);
          if(process.env.ENV != "development"){
            rollbar.error(error);
          } 
          return {statuscode:500};
      }
    }

    async editMilestones(body:any,user:any):Promise<any>{
        try{
            const gigsMilestoneRepository = getRepository(GigsMilestones);
            const gigsRepository = getRepository(Gigs);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var gig_id = body.gig_id;
            var chk = await gigsRepository.findOne({where:{id:gig_id}});
            if(chk){
              if(chk.status == 0 || chk.status == 1){
                var time = Date.now()/1000;
                for(let i=0;i<body.milestones.length;i++){
                    var gigsMilestones :any= {
                        updated_at : time,
                        updated_by : user.id,
                        description : body.milestones[i].description,
                        title : body.milestones[i].title,
                        estimated_duration : body.milestones[i].estimated_duration,
                        duration_unit : body.milestones[i].duration_unit,
                        estimated_budget : body.milestones[i].estimated_budget
                    }
                    if(body.milestones[i].id){
                      let saveMilestone = await gigsMilestoneRepository.update({id: body.milestones[i].id},gigsMilestones);
                    }else{
                      gigsMilestones.created_at = time;
                      gigsMilestones.created_by = user.id;
                      gigsMilestones.gigs = gig_id;
                      let saveMilestones = await gigsMilestoneRepository.save(gigsMilestones);
                    }
                }
                return {statuscode:200};
              }else{
                return {statuscode:202};
              }
            }else{
              return {statuscode:201};
            }
        }catch(error){
            console.log(error);
            if(process.env.ENV != "development"){
              rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async deleteMilestones(body:any,id:any,user:any):Promise<any> {
        try{
            const gigsMilestoneRepository = getRepository(GigsMilestones);
            let res:any = await gigsMilestoneRepository.delete(
                {
                    id:id,
                    created_by:user.id
                });
            if(res.affected > 0){
                return {statuscode:200};
            }else{
                return {statuscode:201};
            }
        }catch(error){
          if(process.env.ENV != "development"){
            rollbar.error(error);
          } 
          return {statuscode:500};
        }
    }

    async startMilestoneFl(body:any):Promise<any>{
        try{
            var ms_id = body.milestone_id;
            var gig_id = body.gig_id;
            const gigsMilestoneRepository = getRepository(GigsMilestones);
            const gigRep = getRepository(Gigs);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var time = Date.now()/1000;
            var endDateForThisMilestone = 0;
            var endDateForThisGig = 0;
            var allMilstone :any = await gigsMilestoneRepository.find({where:{gigs:gig_id}});
            for(let i=0;i<allMilstone.length;i++){
                let estimated_duration = allMilstone[i].estimated_duration;
                let duration_unit = allMilstone[i].duration_unit;
                let hours = 0;
                if(duration_unit == 0){
                    hours = estimated_duration
                }else if(duration_unit == 1){
                    hours = estimated_duration * 24;
                }else if(duration_unit == 2){
                    hours = estimated_duration * 7 * 24;
                }else if(duration_unit == 3){
                    hours = estimated_duration * 30 * 24;
                }else{
                    hours = estimated_duration * 365 * 24;
                }
                if(allMilstone[i].id == ms_id){
                    endDateForThisMilestone = time + (hours*60*60);
                }
                endDateForThisGig =  endDateForThisGig +  ((hours*60*60));
            }
            var zohoToken :any = await zohoInfoRepo.findOne();

            gigRep.update({id:gig_id}, {expected_closer:endDateForThisGig + time});
            gigsMilestoneRepository.update({id:ms_id}, {status:1, end_date:endDateForThisMilestone});
            var gigMilestone:any = await gigsMilestoneRepository.findOne({ where: { id: ms_id}});
            try{
              var updateData = {
                Status: "In Progress"
              }
              var zohoToken :any = await zohoInfoRepo.findOne();
              updateMilestoneOnZoho(zohoToken.accesstoken,gigMilestone.zoho_milestones_id,updateData);
            }catch(error){
              console.log(error);
            }
            return {statuscode:200};
        }catch(error){
          if(process.env.ENV != "development"){
            rollbar.error(error);
          } 
          return {statuscode:500};
        }
    }

    async submitWorkOnMilestoneFl(body:any, user:any):Promise<any>{
        try{
            var ms_id = body.attachment[0].milestone_id;
            const gigsMilestoneRepository = getRepository(GigsMilestones);
            const gigsRepository = getRepository(Gigs);
            const milestoneAttachmentsRepo = getRepository(MilestoneAttachments);
            var time = Date.now()/1000;
            for(let i = 0 ; i< body.attachment.length; i++){
                let gigsAttach = new MilestoneAttachments()
                    gigsAttach.created_by = user.freelancer_id;
                    gigsAttach.milestones = ms_id;
                    gigsAttach.attachment_url =  body.attachment[i].attachment_url;
                    gigsAttach.fileType =  body.attachment[i].fileType;
                    gigsAttach.created_at = time;
                let savedAttachment = await milestoneAttachmentsRepo.save(gigsAttach);
            }
            await gigsMilestoneRepository.update({id:ms_id}, {status:2});
            let ml_data:any = await gigsMilestoneRepository.findOne({where:{id:ms_id},relations:["gigs"]});
            let gigs_data:any = await gigsRepository.findOne({where:{id:ml_data.gigs.id}});
            let ids : any = [ml_data.gigs.created_by];
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications';
            let meta_data = {"project_id":gigs_data.project_id,"gig_id":ml_data.gigs.id,"redirect_on":"in_progress_work_submited","view":"admin","fl_id":null,"created_by":null,"notification_type":"fl_submit_milestone"}
            const json = JSON.stringify({"ids": ids,"message":"Milestones submitted successfully.","meta_data":meta_data});
            axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            return {statuscode:200};
        }catch(error){console.log(error);
            if(process.env.ENV != "development"){
              rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async reworkMilestoneAdmin(body:any):Promise<any>{
        try{
            var ms_id = body.milestone_id;
            const gigsMilestoneRepository = getRepository(GigsMilestones);
            await gigsMilestoneRepository.update({id:ms_id}, {status:4});
            let ml_data:any = await gigsMilestoneRepository.findOne({where:{id:ms_id},relations:["gigs"]});
            let ids : any = [ml_data.gigs.fl_id];
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications/fls';
            let meta_data = {"project_id":null,"gig_id":ml_data.gigs.id,"redirect_on":"in_progress","view":"freelancer","fl_id":null,"created_by":null,"notification_type":"admin_mark_milestone_rework"}
            const json = JSON.stringify({"ids": ids,"message":"Milestones rework is asked by admin for gig "+ml_data.gigs.title,"meta_data":meta_data});
            axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            return {statuscode:200};
        }catch(error){
            if(process.env.ENV != "development"){
              rollbar.error(error);
            } 
            return {statuscode:500};
        }
    }

    async completeMilestoneAdmin(body:any, token:any):Promise<any>{
        try{
            var ms_id = body.milestone_id;
            var gig_id = body.gig_id;
            var project_id = body.project_id;
            var fl_id = body.fl_id;
            const gigsMilestoneRepository = getRepository(GigsMilestones);
            const gigsRepository = getRepository(Gigs);
            const projectsRepository = getRepository(Projects);
            const zohoInfoRepo = getRepository(ZohoInfo);
            var zohoToken :any = await zohoInfoRepo.findOne();
            await gigsMilestoneRepository.update({id:ms_id}, {status:3});
             //Update milestone status complete on zoho
             var gig_milestone:any = await gigsMilestoneRepository.findOne({ where: { id: body.milestone_id}, relations:["gigs"]});
             try{
               let updateGig = {
                 Status: "Completed"
               }
               updateMilestoneOnZoho(zohoToken.accesstoken,gig_milestone.zoho_milestones_id,updateGig);
               const jsn = JSON.stringify({"user_id": gig_milestone.gigs.created_by});
               const re = await axios.post(process.env.Begig_user_url+'api/v1/user/superadmin/account', jsn, {
                   headers: {
                       'Content-Type': 'application/json',
                       'Authorization': `${token.authorization}`
                   }
               });

               let amount = gig_milestone.estimated_budget;
               const json = JSON.stringify({"item_id": gig_milestone.id, "zoho_item_id":gig_milestone.zoho_milestones_id, "messages":"Invoice for charges on hiring freelancer on you gig: "+gig_milestone.gigs.title, "user_id":re.data.data.owner_id,"owner_account":re.data.data.owner_account,"amount":amount });
               axios.post(process.env.Begig_payment_url+'api/v1/payment/superadmin/milestone/invoice', json, {
                   headers: {
                       'Content-Type': 'application/json',
                       'Authorization': `${token.authorization}`
                   }
               });
             }catch(error){
               console.log(error);
             }
             ///////////////////////////////////////////
            var ml_data:any = await gigsMilestoneRepository.findOne({where:{id:ms_id},relations:["gigs"]});
            let ids : any = [ml_data.gigs.fl_id];
            const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications/fls';
            let meta_data = {"project_id":null,"gig_id":ml_data.gigs.id,"redirect_on":"in_progress","view":"freelancer","fl_id":null,"created_by":ml_data.gigs.created_by,"notification_type":"admin_approve_milestone"}
            const json = JSON.stringify({"ids": ids,"message":"Milestones Approved! {{company_name}}","meta_data":meta_data});
            axios.post(bigigUserUrl, json, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            var allMilstone :any = await gigsMilestoneRepository.find({where:{gigs:gig_id,status:Not(3)}});
            if(allMilstone.length <= 0){
                await gigsRepository.update({id:gig_id},{status:3,completed_on:Date.now()/1000});
                //gig update on zoho
                try{
                  let updateGig = {
                    Gig_Status: "Completed"
                  }
                  updateGigOnZoho(zohoToken.accesstoken,gig_milestone.gigs.zoho_gigs_id,updateGig);
                }catch(error){
                  console.log(error);
                }
                let ids : any = [ml_data.gigs.fl_id];
                const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/send/notifications/fls';
                let meta_data = {"project_id":null,"gig_id":ml_data.gigs.id,"redirect_on":"completed_gigs","view":"freelancer","fl_id":null,"created_by":null,"notification_type":"gig_completed_show_to_fl"}
                const json2 = JSON.stringify({"ids": ids,"message":"Congratulations! You have successfully achieved your milestones of "+ml_data.gigs.title,"meta_data":meta_data});
                axios.post(bigigUserUrl, json2, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                let ids2 : any = [ml_data.gigs.created_by];
                const bigigUserUrl2 = process.env.Begig_user_url+'api/v1/user/send/notifications';
                meta_data = {"project_id":project_id,"gig_id":ml_data.gigs.id,"redirect_on":"completed_gigs","view":"admin","fl_id":ml_data.gigs.fl_id,"created_by":null,"notification_type":"gig_completed_show_to_admin"}
                const json3 = JSON.stringify({"ids": ids2,"message":"The gig has been closed by {{fl_name}}. Kindly review and respond accordingly.","meta_data":meta_data});
                axios.post(bigigUserUrl2, json3, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                let allGig :any = await gigsRepository.find({where:{projects:project_id,status:Not(3)}});
                if(allGig.length <= 0){
                    await projectsRepository.update({id:project_id}, {status:2});
                     // udpate project api update status completed
                    try{
                      var projectData:any = await projectsRepository.findOne({ where: { id: body.project_id}});
                      let updateProject = {
                        Stage: "Completed"
                      }
                      updateProjectOnZoho(zohoToken.accesstoken,projectData.zoho_project_id,updateProject);
                    }catch(error){
                      console.log(error);
                    }

                }
                const json = JSON.stringify({"fl_id": fl_id});
                axios.post(process.env.Begig_user_url+'api/v1/user/freelancers/add/completed/gig', json, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `${token.authorization}`
                    }
                });
            }
            return {statuscode:200};
        }catch(error){
          if(process.env.ENV != "development"){
            rollbar.error(error);
          }
          return {statuscode:500};
        }
    }

    async getMilestoneAttachments(milestone_id:any):Promise<any>{
        try{
            const milestoneAttachmentsRepo = getRepository(MilestoneAttachments);
            var allMilstone :any = await milestoneAttachmentsRepo.find({  where:{milestones:milestone_id}});
            if(allMilstone.length > 0){
                return {statuscode:200,data:allMilstone};
            } else {
                return {statuscode:201};
            }
        }catch(error){
            if(process.env.ENV != "development"){
              rollbar.error(error);
            }
            return {statuscode:500};
        }
    }

    async getAllMilestonesBySuperAdmin(body:any, user:any,token:any): Promise<any>{
      try{
        var time = Date.now()/1000;
        const page_number = body.page_number || 0
        const number_of_record = body.number_of_record || 5
        var milestone_type = body.milestone_type; // all, upcoming, ontrack, overdue, submitted , closed
        var query_condition = "";
        if(milestone_type == "upcoming"){
          query_condition = "gigs_milestones.status = 0";
        }else if(milestone_type == "ontrack"){
          query_condition = "gigs_milestones.status in (1,4) and gigs_milestones.end_date > "+time;
        }else if(milestone_type == "overdue"){
          query_condition = "gigs_milestones.status != 3 and gigs_milestones.status != 2 and gigs_milestones.status != 0 and gigs_milestones.end_date < "+time;
        }else if(milestone_type == "submitted"){
          query_condition = "gigs_milestones.status = 2";
        }else if(milestone_type == "closed"){
          query_condition = "gigs_milestones.status = 3";
        }

        if(query_condition != ""){
          var gigs : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .innerJoinAndSelect("gigs.projects","projects")
          .innerJoinAndSelect("gigs.gigs_milestones","gigs_milestones")
          .where("projects.company_id = "+user.company_id)
          .andWhere("gigs.fl_id != 0")
          .andWhere(query_condition)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)
          .getMany();
        }else{
          var gigs : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .innerJoinAndSelect("gigs.projects","projects")
          .innerJoinAndSelect("gigs.gigs_milestones","gigs_milestones")
          .where("projects.company_id = "+user.company_id)
          .andWhere("gigs.fl_id != 0")
          .getMany();
        }

        if(gigs.length > 0){
          let id : any = [];
          for(let i=0;i<gigs.length;i++){
              if(!id.includes(gigs[i].fl_id)){
                  id.push(gigs[i].fl_id);
              }
          }
          const json = JSON.stringify({"id": id});
          const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
              headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `${token.authorization}`
              }
          });
          for(let i=0;i<gigs.length;i++){
            let fl_id = gigs[i].fl_id;
            for(let j=0;j< res.data.freelancerData.length;j++){
                if(fl_id == res.data.freelancerData[j].id){
                    var freelancer : any = {
                        first_name : res.data.freelancerData[j].user.first_name,
                        last_name : res.data.freelancerData[j].user.last_name,
                        profile_pic : res.data.freelancerData[j].user.profile_pic,
                        average_rating : res.data.freelancerData[j].user.average_rating,
                        freelancing_type : res.data.freelancerData[j].freelancing_type,
                        rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                        availibity : res.data.freelancerData[j].availibity
                    }
                    gigs[i].freelancer = freelancer
                    break;
                }
            }
          }
          return {statuscode:200,data:gigs};
        }else{
          return {statuscode:201};
        }
      }catch(err){console.log(err);
        if(process.env.ENV != "development"){
          rollbar.error(err);
        }
        return {statuscode:500};
      }
    }

    async getAllMilestonesByEmployerId(body:any, user:any,token:any): Promise<any>{
      try{
        var time = Date.now()/1000;
        const page_number = body.page_number || 0
        const number_of_record = body.number_of_record || 5
        var milestone_type = body.milestone_type; // all, upcoming, ontrack, overdue, submitted , closed
        var query_condition = "";
        if(milestone_type == "upcoming"){
          query_condition = "gigs_milestones.status = 0";
        }else if(milestone_type == "ontrack"){
          query_condition = "gigs_milestones.status in (1,4) and gigs_milestones.end_date > "+time;
        }else if(milestone_type == "overdue"){
          query_condition = "gigs_milestones.status != 3 and gigs_milestones.status != 2 and gigs_milestones.status != 0 and gigs_milestones.end_date < "+time;
        }else if(milestone_type == "submitted"){
          query_condition = "gigs_milestones.status = 2";
        }else if(milestone_type == "closed"){
          query_condition = "gigs_milestones.status = 3";
        }

        if(query_condition != ""){
          var gigs : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .innerJoinAndSelect("gigs.projects","projects")
          .innerJoinAndSelect("gigs.gigs_milestones","gigs_milestones")
          .innerJoinAndSelect("gigs.gigs_attachments","gigs_attachments")
          .where("gigs.created_by = "+user.id)
          .andWhere("gigs.fl_id != 0")
          .andWhere(query_condition)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)
          .getMany();
        }else{
          var gigs : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .innerJoinAndSelect("gigs.projects","projects")
          .innerJoinAndSelect("gigs.gigs_milestones","gigs_milestones")
          .innerJoinAndSelect("gigs.gigs_attachments","gigs_attachments")
          .where("gigs.created_by = "+user.id)
          .andWhere("gigs.fl_id != 0")
          .getMany();
        }

        if(gigs.length > 0){
          let id : any = [];
          for(let i=0;i<gigs.length;i++){
              if(!id.includes(gigs[i].fl_id)){
                  id.push(gigs[i].fl_id);
              }
          }
          const json = JSON.stringify({"id": id});
          const res = await axios.post(process.env.Begig_user_url+'api/v1/user/get/freelancers', json, {
              headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `${token.authorization}`
              }
          });
          for(let i=0;i<gigs.length;i++){
            let fl_id = gigs[i].fl_id;
            for(let j=0;j< res.data.freelancerData.length;j++){
                if(fl_id == res.data.freelancerData[j].id){
                    var freelancer : any = {
                        first_name : res.data.freelancerData[j].user.first_name,
                        last_name : res.data.freelancerData[j].user.last_name,
                        profile_pic : res.data.freelancerData[j].user.profile_pic,
                        average_rating : res.data.freelancerData[j].user.average_rating,
                        freelancing_type : res.data.freelancerData[j].freelancing_type,
                        rate_per_hour : res.data.freelancerData[j].rate_per_hour,
                        availibity : res.data.freelancerData[j].availibity
                    }
                    gigs[i].freelancer = freelancer
                    break;
                }
            }
          }
          return {statuscode:200,data:gigs};
        }else{
          return {statuscode:201};
        }
      }catch(err){console.log(err);
        if(process.env.ENV != "development"){
          rollbar.error(err);
        }
        return {statuscode:500};
      }
    }

    async getAllMilestonesByFlId(body:any, user:any,token:any): Promise<any>{
      try{
        var time = Date.now()/1000;
        const page_number = body.page_number || 0
        const number_of_record = body.number_of_record || 5
        var milestone_type = body.milestone_type; // all, upcoming, ontrack, overdue, submitted , closed
        var query_condition = "";
        if(milestone_type == "upcoming"){
          query_condition = "gigs_milestones.status = 0";
        }else if(milestone_type == "ontrack"){
          query_condition = "gigs_milestones.status in (1,4) and gigs_milestones.end_date > "+time;
        }else if(milestone_type == "overdue"){
          query_condition = "gigs_milestones.status != 3 and gigs_milestones.status != 0 and gigs_milestones.status != 2 and gigs_milestones.end_date < "+time;
        }else if(milestone_type == "submitted"){
          query_condition = "gigs_milestones.status = 2";
        }else if(milestone_type == "closed"){
          query_condition = "gigs_milestones.status = 3";
        }

        if(query_condition != ""){
          var gigs : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .innerJoinAndSelect("gigs.projects","projects")
          .innerJoinAndSelect("gigs.gigs_milestones","gigs_milestones")
          .where("gigs.fl_id = "+user.freelancer_id)
          .andWhere(query_condition)
          .limit(number_of_record)   // page number
          .offset(page_number * number_of_record)
          .getMany();
        }else{
          var gigs : any = await getRepository(Gigs)
          .createQueryBuilder("gigs")
          .innerJoinAndSelect("gigs.projects","projects")
          .innerJoinAndSelect("gigs.gigs_milestones","gigs_milestones")
          .where("gigs.fl_id = "+user.freelancer_id)
          .getMany();
        }

        if(gigs.length > 0){
          let id : any = [];
          for(let i=0;i<gigs.length;i++){
              if(!id.includes(gigs[i].created_by)){
                  id.push(gigs[i].created_by);
              }
          }
          const json = JSON.stringify({"id": id});
          const bigigUserUrl = process.env.Begig_user_url+'api/v1/user/get/users';
          const res = await axios.post(bigigUserUrl, json, {
              headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `${token.authorization}`
              }
          });
          for(let i=0;i<gigs.length;i++){
            let gigId = gigs[i].created_by;
            for(let j=0;j< res.data.userData.length;j++){
                if(gigId == res.data.userData[j].user.id){
                    var admin : any = {
                        first_name : res.data.userData[j].user.first_name,
                        last_name : res.data.userData[j].user.last_name,
                        profile_pic : res.data.userData[j].user.profile_pic,
                        average_rating : res.data.userData[j].user.average_rating,
                        company_name : res.data.userData[j].company.company_name,
                    }
                    gigs[i].admin = admin
                    break;
                }
            }
          }
          return {statuscode:200,data:gigs};
        }else{
          return {statuscode:201};
        }
      }catch(err){console.log(err);
        if(process.env.ENV != "development"){
          rollbar.error(err);
        }
        return {statuscode:500};
      }
    }

}
