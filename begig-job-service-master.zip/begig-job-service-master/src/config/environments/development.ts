const config: any = {};

config.logLevel = 'info';

export { config };
