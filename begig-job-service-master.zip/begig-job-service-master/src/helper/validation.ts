const {check,body} = require('express-validator')

const addGigValidation = () => {    
    return [  
        check('project_id', "Project id is required").notEmpty().isNumeric().withMessage('Project id must be number'),
        check('type', 'Type is required').notEmpty().isIn(['0','1','2','3','4']).withMessage('Status must be 0,1,2,4'),
        check('title', "Title is required").notEmpty().trim(),
        check('description', "Description is required").notEmpty().trim(),
        check('gigs_skills', "Gigs skills is required").notEmpty(),
        check('designation', "Designation is required").notEmpty().trim(),
        check('education_id', "Education id is required").notEmpty().trim(),
        check('required_exerience', "Required exerience is required").notEmpty().trim(),
        check('payment_type', "Payment type is required").notEmpty().isIn(['0','1','2']).withMessage('Payment_type must be 0,1,2'),
        check('is_created_by_pm', "is_created_by_pm is required").notEmpty().trim()
    ]           
}

const addDraftGigValidation = () => {    
    return [  
        check('project_id', "Project id is required").notEmpty().isNumeric().withMessage('Project id must be number'),
        check('project_id').isNumeric().withMessage('Project id must be number'),
        check('title', "Title is required").notEmpty().trim()
    ]           
}
 
const editGigValidation = () => {    
    return [  
        check('project_id', "Project id is required").notEmpty().isNumeric().withMessage('Project id must be number'),
        check('title', "Title is required").notEmpty().trim(),
        check('description', "Description is required").notEmpty().trim(),
        check('gigs_skills', "Gigs skills is required").notEmpty(),
        check('designation', "Designation is required").notEmpty().trim(),
        check('education_id', "Education id is required").notEmpty().trim(),
        check('required_exerience', "Required exerience is required").notEmpty().trim(),
        check('payment_type', "Payment type is required").notEmpty().isIn(['0','1','2']).withMessage('Payment_type must be 0,1,2')
    ]           
}

const addMilestonesValidation = () => {    
  
    return [                   
        body('milestones.*.gigs_id','Gig id is required').notEmpty().isNumeric().withMessage('Gig id must be number'),
        body('milestones.*.title','Title required').not().isEmpty(),
        body('milestones.*.description','Description is required').notEmpty(),
        body('milestones.*.estimated_duration','Estimated duration is required').notEmpty(),
        body('milestones.*.duration_unit','Duration unit is required').notEmpty().isIn(['0','1','2','3','4']).withMessage('Duration unit must be 0,1,2,3,4'),
        body('milestones.*.estimated_budget','Estimated budget is required').notEmpty()
    ] 
        
           
}


const editMilestonesValidation = () => {    
    return [ 
        body('milestones.*.id','Id is required').notEmpty().isNumeric().withMessage('Id must be number'),
        body('milestones.*.title','Title required').not().isEmpty(),
        body('milestones.*.description','Description is required').notEmpty(),
        body('milestones.*.estimated_duration','Estimated duration is required').notEmpty(),
        body('milestones.*.duration_unit','Duration unit is required').notEmpty().isIn(['0','1','2','3','4']).withMessage('Duration unit must be 0,1,2,3,4'),
        body('milestones.*.estimated_budget','Estimated budget is required').notEmpty() 
      
    ]           
}


module.exports = {
    addGigValidation,
    editGigValidation,
    addMilestonesValidation,
    addDraftGigValidation,
    editMilestonesValidation
}