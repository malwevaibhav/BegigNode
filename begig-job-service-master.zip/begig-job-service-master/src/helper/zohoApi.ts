var axios = require('axios');
var FormData = require('form-data');
var {rollbar} = require('./rollbar');

async function zohoCreateAccessToekn(){

	var data = new FormData();
	data.append('client_id', process.env.ZOHO_CLIENT_ID);
	data.append('client_secret', process.env.ZOHO_CLIENT_SECRET);
	data.append('refresh_token', process.env.ZOHO_REFRESH_TOEKN);
	data.append('grant_type', process.env.ZOHO_GRANT_TYPE);

	var config = {
        method: 'post',
        url: 'https://accounts.zoho.in/oauth/v2/token',
		timeout:50000,
        headers: {
            ...data.getHeaders()
        },
        data : data
	};
	let res = await axios(config);
	return res.data;
}

const createProjectOnZoho = (token:any,account_id:any,contact_id:any,Type:any,Description:any,Deal_Name:any,Amount:any,Stage:any,Lead_Source:any,Closing_Date:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                {
                "Account_Name": {
                    "id": account_id
                },
                "Contact_Name": {
                    "id": contact_id
                },
                "Type": Type,
                "Description": Description,
                "Deal_Name": Deal_Name,
                "Amount": Amount,
                "Stage": Stage,
                "Lead_Source": Lead_Source,
                "Closing_Date": Closing_Date
                }
            ]
        });

        var config = {
        method: 'post',
        url: 'https://www.zohoapis.in/crm/v2/Deals',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json'
        },
           data : data
        };

        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
		    console.log(error);
            let err = {"error_msg": "Error in create project on zoho", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const updateProjectOnZoho = (token:any,project_id:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });
        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Deals/'+project_id,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            console.log(error);
            let err = {"error_msg": "Error in update project on zoho", project_id:project_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const createGigOnZoho = (token:any,project_id:any,Description:any,Name:any,Gig_Status:any,Gigs_Id:any,Gig_duration:any,Gig_budget:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                {
                  "Deal": {
                    "id": project_id
                  },
                  "Description": Description,
                  "Name": Name,
                  "Gig_Status": Gig_Status,
                  "Gigs_Id": Gigs_Id,
                  "Gig_duration": Gig_duration,
                  "Gig_budget": Gig_budget
                }
              ]
        });

        var config = {
        method: 'post',
        url: 'https://www.zohoapis.in/crm/v2/Gigs',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json'
        },
           data : data
        };

        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            console.log(error);
            let err = {"error_msg": "Error in create gig on zoho", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const updateGigOnZoho = (token:any,gig_id:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });
        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Gigs/'+gig_id,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
		    console.log(error);
            let err = {"error_msg": "Error in update gig on zoho", gig_id:gig_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const createMilestonesOnZoho = (token:any,project_id:any,gig_id:any,Description:any,Milestone_Name:any,Status:any,End_Date:any,Payment_done_by_admin:any,Payment_done_to_FL:any,Milestone_Duration:any,Amount:any, flZohoId:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                {
                    "Deal": {
                        "id": project_id
                    },
                    "Freelancer": {
                        "id": flZohoId
                    },
                    "Gig_Name": {
                        "id": gig_id
                    },
                    "Description": Description,
                    "Name": Milestone_Name,
                    "Status": Status,
                    "End_Date": End_Date,
                    "Payment_done_by_admin": Payment_done_by_admin,
                    "Payment_done_to_FL": Payment_done_to_FL,
                    "Milestone_Duration": Milestone_Duration,
                    "Amount": Amount
                }
            ]
        });
        var config = {
        method: 'post',
        url: 'https://www.zohoapis.in/crm/v2/Milestones',
        headers: {
            'Authorization': 'Zoho-oauthtoken '+token,
            'Content-Type': 'application/json'
        },
           data : data
        };

        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            console.log(error);
            let err = {"error_msg": "Error in create milestone on zoho", data:data,error:error}
            rollbar.error(err);
            reject(error);
        });
});

const updateMilestoneOnZoho = (token:any,milestone_id:any,updateData:any) =>
    new Promise(function (resolve, reject) {
        var data = JSON.stringify({
            "data": [
                updateData
            ]
        });

        var config = {
            method: 'put',
            url: 'https://www.zohoapis.in/crm/v2/Milestones/'+milestone_id,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            },
            data : data
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            console.log(error);
            let err = {"error_msg": "Error in update milestone on zoho", milestone_id:milestone_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});

//Commission Invoices
const commissionInvoices = (token:any,account_id:any) =>
    new Promise(function (resolve, reject) {
        var config = {
            method: 'get',
            url: 'https://books.zoho.in/api/v3/invoices?organization_id=60011259151&zcrm_account_id='+account_id,
            headers: {
                'Authorization': 'Zoho-oauthtoken '+token,
                'Content-Type': 'application/json'
            }
        };
        axios(config).then(function (response:any) {
            resolve(response.data);
        })
        .catch(function (error:any) {
            let err = {"error_msg": "Error in Commission Invoices", account_id:account_id,error:error}
            rollbar.error(err);
            reject(error);
        });
});


module.exports = {
    zohoCreateAccessToekn,
    createProjectOnZoho,
    updateProjectOnZoho,
    createGigOnZoho,
    updateGigOnZoho,
    createMilestonesOnZoho,
    updateMilestoneOnZoho,
    commissionInvoices
}
