if (!process.env.ALREADY_SET) { require('dotenv').config(); }

import * as http from 'http';
import { app } from './app';
import { DatabaseService } from './services/databaseService';
import { Logger } from './lib/logger';
import { JobsService } from './services/JobsService';
var cron = require('node-cron');
// Composition root

const logger: any = new Logger();

DatabaseService.getConnection().then(() => {
  const server = http.createServer(app).listen(parseInt(process.env.PORT || '3000', 10));
  server.on('listening', async () => {
    logger.log('info', `Sample app listening on ${JSON.stringify(server.address())}`);
    const service = new JobsService();
    setTimeout(function(){
      service.testCron();
    }, 10000);
    cron.schedule('* */55 * * * *', () => {
      service.testCron();
    });   
  });
  logger.log('info', `Sample app listening on ${JSON.stringify(server.address())}`);
})